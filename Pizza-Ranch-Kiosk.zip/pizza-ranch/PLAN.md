# Pizza Ranch Raspberry Pi display manager — proposed scope

Application and installer implemented in this workspace. See README.md for the delivered behavior and VALIDATION.md for tests and remaining on-device checks. Nothing has been installed on a physical Pi from this computer.

## Experience

- Power on the Pi: automatically start its desktop session and Firefox kiosk, restoring the last applied content.
- Open the Pi management address in a phone or computer browser. Local address: https://pizza-ranch.local:8443 (substitute the configured hostname); a fixed LAN IP is the fallback. Hostname discovery and Wi-Fi client isolation must be checked on site.
- Initial application login: admin / pranch. Require a new password before management access; retain admin as the username. These credentials are separate from the Pi operating-system account. Never restore the default password during upgrades or reboots.
- Dropdown: Menu, Ads, Funzone Ads, Uploaded Media. Apply explicitly to avoid accidental switches. Show requested content separately from the content acknowledged by the local browser controller.
- Media: drag/drop or file picker on desktop, file picker on phones; local library; select/order/remove playlist entries; image duration; videos play to completion; repeat; mute by default. Looping playlist confirmed and implemented.

## Exact destinations

- Menu: https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only
- Ads: https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only
- Funzone Ads: https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads

The research browser could not open these URLs. Their rendering, login requirements, and video behavior need testing on the target Pi. The mockup is not a screenshot of them.

## Proposed architecture

Python web service (Flask with a production WSGI server), responsive browser UI, SQLite settings and password hashes, local media directory. Python display controller runs in the desktop user's graphical session. systemd supervises the backend; desktop autostart brings up the display controller after the graphical session is ready. Setup targets Raspberry Pi OS 32-bit Desktop with labwc on the Pi 3 B+; 64-bit Desktop remains accepted. Architecture detection uses dpkg, so a 64-bit kernel with a 32-bit userland is handled correctly.

Navigate Firefox directly to each external website, avoiding iframe embedding dependencies. Use a local-only browser control channel, never exposed to the LAN. The local media player is another kiosk destination. Control continues even while an external site is displayed. A watchdog restarts a crashed browser with bounded retries and logs failures.

Remote access: local network by default; if access from outside the restaurant is needed, use an authenticated private VPN and encrypted access rather than public port forwarding. Provider and setup remain to be selected. No subscription or cloud service is assumed in this plan.

Authentication: hashed passwords, login throttling, protected sessions, CSRF protection, logout, and session invalidation after password changes. The deployment should provide encrypted transport; certificate/access details depend on the network option. Initial default credentials are bootstrap-only. Include a local administrator recovery procedure.

Uploads: initially JPG/PNG/WebP and MP4 with compatible H.264 video; validate actual content and codecs, sanitize display names, assign internal filenames, enforce configurable size/free-space limits, write atomically, and reject unsupported files with clear feedback. Uploaded files cannot execute. Do not delete files used by the active playlist without updating it safely.

Reliability: persist the last applied selection and playlist; disable display sleep; retry unavailable websites; offer a configured local-media fallback during outages. Uploaded media works offline. External websites are not guaranteed to work offline. Distinguish browser health from physical TV power state.

## Delivery stages and acceptance

1. Agree on management concept, device model, screen count, network access, and playback behavior.
2. Build authenticated management service and persistent configuration. Verify default-password replacement, access restrictions, and session handling.
3. Build display controller and media player. Verify all three exact URLs, switching, uploads, image timing, video completion, and invalid-file handling.
4. Build repeatable installer and uninstall/recovery instructions. Preserve existing desktop autostart entries and existing data on upgrades.
5. Test on real Pi: cold boot, power recovery, browser crash, network loss/reconnection, disk limits, phone/desktop layouts, and password persistence. Windows-only validation cannot certify Pi boot or video playback.

## Confirmed choices and first setup

- Hardware: Raspberry Pi 3 B+.
- Access: both local Wi-Fi and from away.
- Uploaded content: looping image/video playlist.
- Initial setup: show a QR code plus readable management URL on the TV until the first password change completes. Generate the real QR from the Pi's actual reachable address at runtime; never embed the password or a login-bypass token. Phone must be on the same reachable LAN for this initial local QR. After setup, close the QR endpoint and transition to the selected kiosk source.
- Away access uses Tailscale Serve after one-time account setup on the Pi and each managing phone/computer. The QR does not itself provide off-site connectivity. Application login is retained over the VPN.
- Pi 3 B+ resource budget: one active Firefox page, lightweight management UI, no continuous live screenshot feed or on-device video transcoding. Begin with compatible 1080p-or-lower H.264 MP4 files and verify playback on the actual hardware. Site performance is still unverified.

## Open decisions

- Current OS and screen count. Assume one independently controlled HDMI TV per Pi unless requested otherwise.
- Sound and screen orientation. Default: muted, landscape.

Reference: https://www.raspberrypi.com/tutorials/how-to-use-a-raspberry-pi-in-kiosk-mode/
