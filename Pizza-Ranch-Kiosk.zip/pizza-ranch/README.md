# Pizza Ranch display manager

A Python application for a **Raspberry Pi 3 B+ and one HDMI TV**, managed from a phone or computer. Built for Raspberry Pi OS **64-bit Desktop with labwc** (Bookworm or newer). Raspberry Pi OS Lite and older X11/Wayfire installations are not supported by this installer.

## What it does

- Boots directly into Chromium kiosk mode, restores the last selection, and restarts a crashed browser.
- Offers Menu, Ads, Funzone Ads, and Uploaded Media for store 8300, using the exact URLs in `PLAN.md`.
- Initial login **admin / pranch**; requires changing the password before any management operations. Passwords are hashed; session cookies are secure/HTTP-only; forms use CSRF protection; login attempts are throttled.
- Shows an **address-only QR code** on the TV before registration. After a successful password change, the QR endpoint closes and the kiosk switches to its selected source. The QR carries no credentials or automatic login.
- Uploads images/videos using drag-and-drop or file selection; reorder a looping playlist; choose image duration and mute setting. Files upload sequentially to suit the Pi 3 B+.
- Validates and rewrites uploaded media, uses generated storage names, and stores files without execute permissions. The service additionally marks its entire data directory non-executable with systemd. Uploads are never imported, interpreted, or used as shell commands. No SVG, HTML, script, or executable uploads are allowed.
- Schedules security maintenance **daily at 04:00 America/Chicago**, plus up to 15 minutes of jitter. No automatic reboot. Updates missed while powered off wait for the next window.
- Supports HTTPS on the restaurant LAN and optional private HTTPS access through Tailscale when away.

## 1. Prepare the Pi

### Try the management page on Windows first

Install Python 3.11+ if it is not already available. Extract the ZIP, open PowerShell in its `pizza-ranch` folder, and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Demo.ps1
```

The launcher automatically installs Python dependencies on first use and opens the management page. The execution-policy setting applies only to that PowerShell process. Sign in with `admin` / `pranch`, then change the password. Press Ctrl+C to stop. Use `-Port 8085` if port 8080 is occupied.

This example runs only on your computer's loopback address and stores separate settings/uploads in `demo-data`. It demonstrates login, image uploads, content selection, and playlist editing. It does not drive a TV, configure auto-boot, or schedule Windows updates. MP4 upload validation requires `ffmpeg` and `ffprobe` installed on your Windows PATH; image demos need neither. Demo cookies use local HTTP; the Pi installation retains HTTPS and secure cookies.

1. Back up any existing Pi installation. This installer is for a dedicated signage Pi; it enables desktop auto-login, disables screen blanking, and changes the unattended-update policy.
2. In Raspberry Pi Imager, install Raspberry Pi OS **64-bit Desktop**. Set a normal OS username/password, hostname such as `pizza-ranch`, Wi-Fi, and timezone. The OS password is separate from the management login.
3. Connect the TV and network. Ethernet is preferable where available. Boot and complete the desktop setup. Use a reliable Pi power supply and a quality microSD card; 32 GB or larger leaves room for media.
4. Copy and extract this release folder onto the Pi, for example `~/pizza-ranch`.

## 2. Install and register

From a terminal logged into the Pi's normal desktop account:

```bash
cd ~/pizza-ranch
sudo bash install.sh
sudo reboot
```

The installer uses Raspberry Pi OS/Debian packages for Python dependencies so scheduled OS security updates can update them. It does not run `pip` as root or expose Flask's development server. It preserves existing data/passwords and existing labwc autostart contents when rerun. Keep the extracted release folder for updates and removal.

To use a different timezone during installation:

```bash
sudo env RANCH_TIMEZONE=America/Denver bash install.sh
```

After reboot:

1. Scan the TV's QR code with a phone on the same reachable network. Or open `https://pizza-ranch.local:8443` (substitute your actual hostname). If `.local` discovery fails, use the Pi's IP shown on the TV.
2. **Local HTTPS uses a self-signed certificate**, so the first visit displays a certificate warning. Verify the address belongs to your Pi and compare the certificate's SHA-256 fingerprint with the installer output before accepting it. For a browser-trusted HTTPS address, configure Tailscale below. The LAN certificate expires after one year; renewal instructions are below.
3. Sign in with **admin / pranch** and choose a new password of at least 12 characters. Do this during installation on a trusted network: anyone who can reach an unregistered Pi knows its initial password.
4. The setup screen disappears. Choose a source and press **Show on screen**.

The QR assumes the Pi has already joined your network; it does not configure Wi-Fi. Guest Wi-Fi client isolation may prevent the phone from reaching the Pi. Reserve the Pi's IP in the router to keep the LAN address stable.

## 3. Enable access from away

No router port forwarding is needed. Do **not** publish the management service with Tailscale Funnel.

1. Install Tailscale on the Pi using its [official Linux instructions](https://tailscale.com/docs/install/linux). Review its business licensing for your use.
2. Run:

```bash
sudo bash setup-remote.sh
```

3. Follow the Tailscale sign-in link and enable HTTPS when prompted. The script configures private **Tailscale Serve** and prints the resulting HTTPS address.
4. Install Tailscale on your phone/computer, sign in to the same approved network, and open that HTTPS address. Use your changed `admin` password in the management app.
5. Restrict the Pi's access policy to your approved users/devices and HTTPS port 443. Enable MFA with your Tailscale identity provider. Tailscale's account/network policy is configured in its console, not this application.

Use this address both at the restaurant and when away. Tailscale must remain connected on your phone/computer. The application also continues to offer local LAN HTTPS. See [Tailscale Serve](https://tailscale.com/docs/features/tailscale-serve).

## Media workflow

1. Choose files or drop them onto **Media library**. Keep the page open until validation finishes.
2. Click **Add to playlist** for each file. Use Up/Down to order it and Remove to exclude it.
3. Set seconds per image (3–300) and video sound. Click **Save playlist**.
4. Select **Uploaded Media** and click **Show on screen**.

Supported images: JPEG, PNG, WebP, at most 20 MB and 16 million pixels. Images are resized to fit 1920×1080 and converted to JPEG, removing metadata and active payloads. Transparency becomes RGB; use an opaque background in artwork. Animated images become a single image.

Supported video: MP4 with one H.264 video stream, at most 1920×1080 and 256 MB; optional AAC audio. Use 1080p/30 fps or lower for this hardware and test your files. Upload processing remuxes the video without expensive transcoding. Portrait videos exceeding 1080 pixels in height are not supported in this landscape release. Other formats should be converted on a computer before upload. A 512 MB free-space floor is retained, with additional temporary processing space required.

Videos play to completion, then advance. Failed media is skipped with a retry delay. Remove a file from the saved playlist before deleting it from storage. The player contains media within the TV frame rather than cropping it.

When a selected website fails two consecutive reachability checks, the kiosk shows the saved local playlist, or a reconnecting screen if none is configured. It retries about every 30 seconds. This is an HTTP reachability check: a site returning HTTP 200 with broken JavaScript cannot be automatically diagnosed. The app does not cache the external sites for offline use.

## Scheduled maintenance

The installer enables `pizza-ranch-updates.timer`. It installs Debian security updates from the current OS release and updates installed Chromium-family packages from the configured trusted repositories. Raspberry Pi's browser repository does not distinguish security-only releases, so these browser updates can also contain ordinary fixes. No OS release upgrade is performed.

Python libraries are OS-managed on the Pi and follow Debian/Raspberry Pi package security support, rather than automatic PyPI upgrades. Keep the underlying OS on a supported release.

A successful run restarts the management service and refreshes Chromium, briefly interrupting management/playback during the maintenance window. **System reboots remain manual.** The dashboard reports the last update outcome and `/var/run/reboot-required` when present; that marker is not a guarantee that no restart is needed. Review updates periodically. Application source-code updates are installed separately by copying a new release and rerunning the installer.

```bash
systemctl list-timers pizza-ranch-updates.timer
journalctl -u pizza-ranch-updates --since yesterday
sudo systemctl start pizza-ranch-updates.service  # run now, outside service hours
```

To change the scheduled time:

```bash
sudo systemctl edit pizza-ranch-updates.timer
```

Enter:

```ini
[Timer]
OnCalendar=
OnCalendar=*-*-* 03:00:00
```

Then run `sudo systemctl daemon-reload` and `sudo systemctl restart pizza-ranch-updates.timer`.

## Recovery and service checks

```bash
systemctl status pizza-ranch
systemctl --user status pizza-ranch-kiosk
journalctl -u pizza-ranch -n 100
journalctl --user -u pizza-ranch-kiosk -n 100
sudo systemctl restart pizza-ranch
systemctl --user restart pizza-ranch-kiosk
```

Run user-service commands while logged into the Pi's desktop account. After a first install, reboot so the new group membership takes effect. If the TV stays black, check HDMI, the graphical login session, controller logs, and available memory. Dashboard status reports the browser controller; it cannot verify that the physical TV is powered on or that a webpage rendered correctly.

Reset a forgotten application password from a local terminal/SSH session with OS administrator access:

```bash
cd /opt/pizza-ranch
sudo -u ranch env RANCH_DATA=/var/lib/pizza-ranch \
  RANCH_DEVICE_TOKEN_FILE=/etc/pizza-ranch/device-token python3 -m ranch.app --reset-password
```

This prompts for a new password, invalidates existing sessions, and does not restore `pranch`.

Back up data with the service stopped to keep SQLite consistent:

```bash
sudo systemctl stop pizza-ranch
sudo tar -czf "$HOME/pizza-ranch-backup.tar.gz" /var/lib/pizza-ranch /etc/pizza-ranch
sudo chmod 600 "$HOME/pizza-ranch-backup.tar.gz"
sudo systemctl start pizza-ranch
```

The backup contains password hashes, session secrets, TLS keys, and media. Store it securely. The controller keeps the current webpage open while the management service is stopped.

To renew the local certificate (also use this after an IP change if using IP access):

```bash
sudo openssl req -x509 -newkey rsa:2048 -nodes -days 365 \
  -keyout /etc/pizza-ranch/tls/server.key -out /etc/pizza-ranch/tls/server.crt \
  -subj "/CN=$(hostname).local" \
  -addext "subjectAltName=DNS:$(hostname).local,IP:$(hostname -I | awk '{print $1}')"
sudo chmod 600 /etc/pizza-ranch/tls/server.key
sudo nginx -t && sudo systemctl reload nginx
sudo openssl x509 -in /etc/pizza-ranch/tls/server.crt -noout -fingerprint -sha256
```

Verify the new fingerprint on your phone/computer. Tailscale's HTTPS certificate is managed separately.

## Architecture and security boundaries

- `ranch/app.py`: Flask application, SQLite settings, authentication, media ingestion, QR, and local display endpoints. Waitress listens only on `127.0.0.1:8080`.
- Nginx: LAN TLS on 8443 and a private loopback proxy on 8081 for Tailscale Serve. Both proxy listeners deny `/device` paths. No uploaded file is mapped to a script handler.
- `ranch/controller.py`: desktop-user service launches one Chromium instance with its sandbox enabled and no remote-debugging port. Switching sources restarts that instance, so expect a brief transition.
- Internal state/heartbeat uses a per-device token. Player/setup endpoints require direct loopback access and reject forwarded requests. The kiosk browser never signs into management.
- Backend runs as unprivileged `ranch`, with a private temp directory, read-only system paths, non-executable data path, and a memory limit. Root owns program files and the security-update runner.
- Keep the device physically secured; Chromium kiosk mode is not an OS lock screen. Keep it separated from payment systems. Do not forward ports 8080, 8081, or 8443 to the public internet.

## Remove the application

Run `sudo bash uninstall.sh` from your retained release folder. It stops/disables the services and removes only this application's startup/proxy/update-policy configuration. It **keeps application files, media, credentials, and certificates** for recovery. Desktop auto-login, timezone, installed OS packages, and any Tailscale connection remain; adjust these in the OS separately if retiring the device. A reboot ends the current kiosk user service.

## Development and verification

The cross-platform development environment uses `requirements.txt`; the Pi installer uses OS packages. Python 3.11+ is required.

```bash
python -m venv .venv
# Activate the environment for your OS, then:
python -m pip install -r requirements.txt pytest
python -m pytest -q
```

See `VALIDATION.md` for completed checks and the on-device acceptance checklist. Real Pi boot, GPU/video decoding, the restaurant network, and the three external sites must still be checked on your hardware before unattended use.
