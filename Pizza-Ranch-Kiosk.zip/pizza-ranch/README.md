# Pizza Ranch display manager

A Python application for **Raspberry Pi 3 B+ multi-TV signage**, managed from one phone or computer. One Pi is the server and can also drive its own HDMI TV; every other Pi is installed as a paired display node for one TV. All units require Raspberry Pi OS **32-bit Desktop with labwc** (Bookworm or newer); 64-bit Desktop is also accepted. Raspberry Pi OS Lite, Pi Zero models, and older X11/Wayfire installations are not supported by this installer. This installer does not install or convert the operating system.

## What it does

- Boots every Pi directly into Firefox kiosk mode, restores each TV’s last selection, and restarts a crashed browser.
- Discovers display nodes on the same LAN, pairs them with a six-digit code shown on the TV, and provides an independent content selector and status for every TV.
- Offers Menu, Ads, Funzone Ads, and Uploaded Media for store 8300, using the exact URLs in `PLAN.md`.
- Initial login **admin / pranch**; requires changing the password before any management operations. Passwords are hashed; session cookies are secure/HTTP-only; forms use CSRF protection; login attempts are throttled.
- Shows an **address-only QR code** on the TV before registration. After a successful password change, the QR endpoint closes and the kiosk switches to its selected source. The QR carries no credentials or automatic login.
- Uploads images/videos using drag-and-drop or file selection; reorder a looping playlist; choose image duration and mute setting. Files upload sequentially to suit the Pi 3 B+.
- Validates and rewrites uploaded media, uses generated storage names, and stores files without execute permissions. The service additionally marks its entire data directory non-executable with systemd. Uploads are never imported, interpreted, or used as shell commands. No SVG, HTML, script, or executable uploads are allowed.
- Schedules Pi security maintenance and GitHub application checks **daily at 09:00 America/Chicago**. Also checks GitHub two minutes after boot. Missed Pi maintenance runs on next startup. No automatic reboot.
- Supports HTTPS on the restaurant LAN and optional private HTTPS access through Tailscale when away.

## 1. Prepare the Pi

### Try the management page on Windows first

Install Python 3.11+ if it is not already available. Extract the ZIP, open PowerShell in its `pizza-ranch` folder, and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Demo.ps1
```

The launcher automatically installs Python dependencies on first use and opens the management page. The execution-policy setting applies only to that PowerShell process. Sign in with `admin` / `pranch`, then change the password. Press Ctrl+C to stop. Use `-Port 8085` if port 8080 is occupied.

This example runs only on your computer's loopback address and stores separate settings/uploads in `demo-data`. It demonstrates login, image uploads, content selection, and playlist editing. It does not drive a TV, configure auto-boot, or schedule Windows updates. MP4 upload validation requires `ffmpeg` and `ffprobe` installed on your Windows PATH; image demos need neither. Demo cookies use local HTTP; the Pi installation retains HTTPS and secure cookies.

1. Back up any existing Pi installation. This installer is for a dedicated signage Pi; it enables desktop auto-login, disables screen blanking, and changes the unattended-update policy.
2. In Raspberry Pi Imager, install Raspberry Pi OS **32-bit Desktop** with labwc. Set a normal OS username/password, hostname such as `pizza-ranch`, Wi-Fi, and timezone. The OS password is separate from the management login. The installer checks `dpkg --print-architecture`: `armhf` is 32-bit, `arm64` is 64-bit. The kernel reported by `uname` can be 64-bit even with a 32-bit OS, so it is not used for this check.
3. Connect the TV and network. Ethernet is preferable where available. Boot and complete the desktop setup. Use a reliable Pi power supply and a quality microSD card; 32 GB or larger leaves room for media.
4. Copy and extract this release folder onto the Pi, for example `~/pizza-ranch`.

## 2. Install and register

### Updating an existing Chromium-based kiosk to Firefox

Extract this updated release into a new folder on the server Pi, run `sudo bash install.sh server` from that folder, then `sudo reboot`. Existing application passwords, selected content, pairing records, and uploaded media are retained. The installer selects the `firefox` package when available and otherwise `firefox-esr`.

Firefox runs with `--kiosk --no-remote --profile` and a dedicated profile under `~/.local/share/pizza-ranch/firefox`. This profile uses private browsing, disables password saving/autofill, and allows media autoplay. It does not use the old Chromium profile or its password store. Website cookies/logins are not retained between browser restarts, so this mode expects public signage pages. Check all three websites and media playback after updating.

This switches the application's browser; it does not disable the operating system's keyring. If an unrelated startup application requests keyring access, that prompt must be diagnosed separately. Any manually added Chromium autostart commands outside this application's managed startup entry also need to be removed separately.

From a terminal logged into the Pi's normal desktop account:

```bash
cd ~/pizza-ranch
sudo bash install.sh server
sudo reboot
```

The installer uses Raspberry Pi OS/Debian packages for Python dependencies so scheduled OS security updates can update them. It does not run `pip` as root or expose Flask's development server. It preserves existing data/passwords and existing labwc autostart contents when rerun. Keep the extracted release folder for updates and removal.

To use a different timezone during installation:

```bash
sudo env RANCH_TIMEZONE=America/Denver bash install.sh server
```

After reboot:

1. Scan the TV's QR code with a phone on the same reachable network. Or open `https://pizza-ranch.local:8443` (substitute your actual hostname). If `.local` discovery fails, use the Pi's IP shown on the TV.
2. The setup QR opens `http://<server-hostname>.local:8083/trust`, a restricted same-LAN page used only to download the Pizza Ranch local certificate authority. Compare the page’s SHA-256 fingerprint with the fingerprint printed by the installer before installing it. Follow the page’s iPhone/iPad, Android, or Windows trust instructions, close and reopen the browser, then open its secure management link. This one-time trust step removes the local HTTPS certificate warning. Public certificate authorities cannot issue certificates for private `.local` names. Tailscale HTTPS remains an alternative that needs no local CA installation.
3. Sign in with **admin / pranch** and choose a new password of at least 12 characters. Do this during installation on a trusted network: anyone who can reach an unregistered Pi knows its initial password.
4. The setup screen disappears. Choose a source and press **Show on screen**.

The QR assumes the Pi has already joined your network; it does not configure Wi-Fi. Guest Wi-Fi client isolation may prevent the phone from reaching the Pi. Reserve the Pi's IP in the router to keep the LAN address stable.

### Add more Pi 3 B+ displays

Install the same ZIP and Raspberry Pi OS Desktop on each additional Pi. Give each Pi a distinct hostname in Raspberry Pi Imager, such as `dining-tv` or `funzone-tv`. On each additional display run:

```bash
cd ~/pizza-ranch
sudo bash install.sh display
sudo reboot
```

The display discovers the server through Avahi/mDNS after boot and shows a six-digit pairing code. In the server admin page, open **Connected TV displays**, select **Pair display**, and enter that code. The node pins the server certificate during this exchange and stores its random device credential with mode 0600. After pairing it reconnects automatically on every boot. A display only accepts fleet traffic from the same IPv4 subnet, and the server never exposes display control through its Tailscale proxy.

Each paired TV has its own Menu, Ads, Funzone Ads, or Uploaded Media selection. Uploaded media stays authoritative on the server. A display validates the size and SHA-256 hash, stores only data files without execute permission, and caches the active shared playlist locally up to 2 GB. Playback can continue from the cache during a temporary server/Wi-Fi interruption. Changing the shared playlist updates display nodes currently assigned to Uploaded Media.

All devices must be on the same normal LAN/VLAN with peer-to-peer traffic and multicast DNS allowed. Guest Wi-Fi client isolation prevents discovery and control. The server and displays should have DHCP reservations. Display nodes trust the server’s local CA, so a renewed server certificate continues working. If the local CA itself is replaced, forget each display in the admin page, remove `/var/lib/pizza-ranch-node/server-token`, `/var/lib/pizza-ranch-node/server-certificate-sha256`, and `/var/lib/pizza-ranch-node/server-certificate.pem` on that display, then pair again.

To convert an installed role, rerun the installer explicitly with `server` or `display` and reboot. The automatic updater records the role and preserves it during future GitHub updates.

## 3. Enable access from away

No router port forwarding is needed. Do **not** publish the management service with Tailscale Funnel.

1. Install Tailscale on the Pi using its [official Linux instructions](https://tailscale.com/docs/install/linux). Review its business licensing for your use.
2. Run:

```bash
sudo bash setup-remote.sh
```

3. Follow the Tailscale sign-in link and enable HTTPS when prompted. The script configures private **Tailscale Serve** and prints the resulting HTTPS address.
4. Install Tailscale on your phone/computer, sign in to the same approved network, and open that HTTPS address. Use your changed `admin` password in the management app.
5. Restrict the Pi's access policy to your approved users/devices and HTTPS port 443. Enable MFA with your Tailscale identity provider. Tailscale's account/network policy is configured in its console, not this application.

Use this address both at the restaurant and when away. Tailscale must remain connected on your phone/computer. The application also continues to offer local LAN HTTPS. See [Tailscale Serve](https://tailscale.com/docs/features/tailscale-serve).

## Media workflow

1. Choose files or drop them onto **Media library**. On iPhone, choose photos from the photo library or Files. Keep the page open until each file says **saved on Pi**.
2. **Add uploads to my saved playlist** is on by default. Uncheck it if you only want to store files; those files can be added with **Add to playlist** later. The result for each rejected file appears next to the upload controls, and the summary distinguishes saved versus failed uploads.
3. Use Up/Down to arrange the playlist, set seconds per image (3–300), and choose video sound.
4. Tap **Save & show playlist** to save changes and select Uploaded Media for the TV in one step. The existing source dropdown still works.

Supported images: JPEG, PNG, WebP, HEIC/HEIF, at most 20 MB. JPEG photos up to 64 million pixels use reduced-resolution decoding; PNG/WebP remain limited to 16 million pixels. Images are resized to fit 1920×1080 and converted to JPEG, removing metadata and active payloads. Transparency becomes RGB; use an opaque background in artwork. Animated images become a single image. The updated installer installs `libheif-examples` to convert iPhone HEIC photos. HEIC conversion has memory/time limits to protect the Pi; unusually large images may need exporting as a smaller JPEG first. For HEIF collections the first decoded photo is used. Temporary conversion files are removed.

Supported video: MP4 or MOV with one H.264 video stream, at most 1920×1080 and 256 MB; optional AAC audio. Both containers are remuxed to MP4 without expensive transcoding. iPhone HEVC videos are rejected with an explicit conversion message. Export existing videos as H.264; for new recordings, Apple's Camera > Formats > Most Compatible setting selects JPEG/H.264 where supported. Use 1080p/30 fps or lower for this hardware and test your files. Portrait videos exceeding 1080 pixels in height are not supported in this landscape release. A 512 MB free-space floor is retained, with additional temporary processing space required.

For existing installations with phone-upload trouble, install this updated ZIP again with `sudo bash install.sh server` and reboot, then refresh the management page on your phone. This installs the HEIC decoder and updates the upload controls without resetting your password or deleting media. If a JPEG still fails, copy the exact error beside the file and inspect `journalctl -u pizza-ranch -n 80 --no-pager`. Unsupported formats, expired sessions, full storage, and missing write permission have specific feedback.

Videos play to completion, then advance. Failed media is skipped with a retry delay. Remove a file from the saved playlist before deleting it from storage. The player contains media within the TV frame rather than cropping it.

When a selected website fails two consecutive reachability checks, the kiosk shows the saved local playlist, or a reconnecting screen if none is configured. It retries about every 30 seconds. This is an HTTP reachability check: a site returning HTTP 200 with broken JavaScript cannot be automatically diagnosed. The app does not cache the external sites for offline use.

## Scheduled maintenance

JPEG compatibility release `2026.09.17-jpeg-fix` accepts JPEG files identified as MPO (multipicture JPEG), saves the primary picture as a standard JPEG, and discards auxiliary pictures. This fixes a reproduced cause of “file contents do not match a supported image.” Other unsupported formats now report their detected type. See [Pillow's MPO documentation](https://pillow.readthedocs.io/en/stable/reference/plugins.html#module-PIL.MpoImagePlugin).

The installer enables `pizza-ranch-updates.timer`. On 64-bit Debian-based installations it installs Debian security updates from the current OS release. On 32-bit Raspbian-based installations it installs updates from the current Raspbian release, including routine fixes, because that repository does not separate security updates. Both architectures also update installed Firefox / Firefox ESR packages from the configured trusted repositories. Raspberry Pi's browser repository does not distinguish security-only releases, so these browser updates can also contain ordinary fixes. No OS release upgrade is performed.

Python libraries are OS-managed on the Pi and follow Debian/Raspberry Pi package security support, rather than automatic PyPI upgrades. Keep the underlying OS on a supported release.

A successful run restarts the management service, briefly interrupting management during the maintenance window. **System reboots remain manual.** The dashboard reports both Pi maintenance and GitHub update outcomes and `/var/run/reboot-required` when present; that marker is not a guarantee that no restart is needed.

The application updater checks `https://raw.githubusercontent.com/rinkerforever/pranch/main/Pizza-Ranch-Kiosk.zip` two minutes after every boot and daily at 09:00 in the Pi's configured timezone (installer default: America/Chicago). It compares the installer/application/deployment file contents with the installed release, so unchanged packages do not reinstall. Upload a rebuilt ZIP to that exact GitHub location to publish changes; editing loose GitHub source files alone does not update the ZIP. Install this updater release manually once to enable it. Older ZIPs without the updater are rejected.

Both jobs share a lock: at 09:00 one waits until the other finishes. Missed OS maintenance runs after startup; GitHub checks retry at the next boot or 09:00 if offline. Neither timer can power on a switched-off Pi. GitHub downloads use HTTPS, size limits, archive path/type validation and Python/shell syntax checks. **The GitHub repository is a trusted software source, and its installer runs as root.** These checks are not a release signature; protect write access to the repository.

Application updates preserve `/var/lib/pizza-ranch` (password, settings and media) and `/etc/pizza-ranch` credentials. They restart the backend and active kiosk controller without rebooting. The previous application files are kept in `/var/lib/pizza-ranch-maintenance/previous-release`, and the updater attempts to reinstall them if installation or the local login-page health check fails. This does not undo OS package changes or database migrations, and cannot recover every power-loss failure. Physical playback still needs verification on your Pi. A changed GitHub ZIP is installed even if it contains an older version; publish only the release you want running.

```bash
systemctl list-timers 'pizza-ranch*'
journalctl -u pizza-ranch-app-updates -n 80 --no-pager
sudo systemctl start pizza-ranch-app-updates.service  # check GitHub now
```

Administrators can also select **Check for updates now** in the Maintenance section. The logged-in web service writes a fixed, data-only request file; a root-owned systemd path unit starts the fixed updater. The web process cannot choose a command, URL, service, or package. The button is disabled while the updater is running and the dashboard reconnects if an installed release restarts the service.

Timer semantics follow the [systemd timer documentation](https://manpages.debian.org/bookworm/systemd/systemd.timer.5.en.html).

```bash
systemctl list-timers pizza-ranch-updates.timer
journalctl -u pizza-ranch-updates --since yesterday
sudo systemctl start pizza-ranch-updates.service  # run now, outside service hours
```

To change the scheduled time:

```bash
sudo systemctl edit pizza-ranch-updates.timer
```

Enter:

```ini
[Timer]
OnCalendar=
OnCalendar=*-*-* 03:00:00
```

Then run `sudo systemctl daemon-reload` and `sudo systemctl restart pizza-ranch-updates.timer`.

## Recovery and service checks

### Reset admin from the login page using the TV

1. Connect your phone to the same directly connected Ethernet/Wi-Fi **IPv4 subnet** as the Pi. Open its local HTTPS address, such as `https://192.168.1.50:8443`. This reset flow does not work through Tailscale Serve, cellular data, a different VLAN, or the Windows example launcher.
2. Tap **Forgot password? Reset using the TV**, then **Show reset QR on TV**.
3. The TV temporarily shows a one-time QR instead of the selected website/media. Scan it with your phone camera while remaining on that local network.
4. Enter and confirm a new password (12–128 characters). Sign in as `admin` with it. All existing admin sessions are invalidated.

The recovery QR expires five minutes after it is requested and can be used only once. The display resumes its selected content after completion or expiry; media/settings are retained. New reset windows are limited to one per ten minutes to limit repeated display interruptions. Repeated requests within an active window do not replace the code. A backend restart or a normal password change invalidates a pending reset.

The initial setup QR remains address-only. The separate recovery QR contains an unpredictable, short-lived reset token in a URL fragment, which is not sent in URL/access logs and is removed from the phone's address bar by the reset page. The requesting management page never receives that token or the QR image; the image is available only to the Pi's local kiosk browser.

Recovery checks the actual client IP against active Ethernet/Wi-Fi interface subnets, plus the HTTPS proxy entry point. VPN/loopback client addresses and forwarded requests through the remote-access listener are rejected. Anyone who can see the recovery QR and reach that local subnet can reset admin, so use your staff/signage network rather than a shared guest network. Install the local CA on the scanning phone first.

Upgrade the server by rerunning `sudo bash install.sh server` from this release and rebooting; the updated proxy configuration and netlink permission are required. If the TV cannot render the QR, use the terminal password reset below instead.

```bash
systemctl status pizza-ranch
systemctl --user status pizza-ranch-kiosk
journalctl -u pizza-ranch -n 100
journalctl --user -u pizza-ranch-kiosk -n 100
sudo systemctl restart pizza-ranch
systemctl --user restart pizza-ranch-kiosk
```

Run user-service commands while logged into the Pi's desktop account. After a first install, reboot so the new group membership takes effect. If the TV stays black, check HDMI, the graphical login session, controller logs, and available memory. Dashboard status reports the browser controller; it cannot verify that the physical TV is powered on or that a webpage rendered correctly.

Reset a forgotten application password from a local terminal/SSH session with OS administrator access:

```bash
cd /opt/pizza-ranch
sudo -u ranch env RANCH_DATA=/var/lib/pizza-ranch \
  RANCH_DEVICE_TOKEN_FILE=/etc/pizza-ranch/device-token python3 -m ranch.app --reset-password
```

This prompts for a new password, invalidates existing sessions, and does not restore `pranch`.

Back up data with the service stopped to keep SQLite consistent:

```bash
sudo systemctl stop pizza-ranch
sudo tar -czf "$HOME/pizza-ranch-backup.tar.gz" /var/lib/pizza-ranch /etc/pizza-ranch
sudo chmod 600 "$HOME/pizza-ranch-backup.tar.gz"
sudo systemctl start pizza-ranch
```

The backup contains password hashes, session secrets, TLS keys, and media. Store it securely. The controller keeps the current webpage open while the management service is stopped.

To renew the server certificate while retaining the trusted local CA, remove only the server certificate and key, then rerun the server installer:

```bash
sudo rm /etc/pizza-ranch/tls/server.crt /etc/pizza-ranch/tls/server.key
cd ~/pizza-ranch
sudo bash install.sh server
sudo reboot
```

The regenerated certificate is signed by the same local CA, so already configured phones, computers, and display nodes continue trusting it. Use the stable `https://<hostname>.local:8443` address. IP access can fail certificate name validation after a DHCP address change. Tailscale's HTTPS certificate is managed separately.

## Architecture and security boundaries

- `ranch/app.py`: Flask application, SQLite settings, authentication, media ingestion, QR, and local display endpoints. Waitress listens only on `127.0.0.1:8080`.
- Nginx: LAN TLS on 8443 and a private loopback proxy on 8081 for Tailscale Serve. Both proxy listeners deny `/device` paths. No uploaded file is mapped to a script handler.
- `ranch/controller.py`: desktop-user service launches one Firefox instance with its sandbox enabled and no remote-debugging port. Switching sources restarts that instance, so expect a brief transition.
- Internal state/heartbeat uses a per-device token. Player/setup endpoints require direct loopback access and reject forwarded requests. The kiosk browser never signs into management.
- Backend runs as unprivileged `ranch`, with a private temp directory, read-only system paths, non-executable data path, and a memory limit. Root owns program files and the security-update runner.
- Keep the device physically secured; Firefox kiosk mode is not an OS lock screen. Keep it separated from payment systems. Do not forward ports 8080, 8081, or 8443 to the public internet.

## Remove the application

Run `sudo bash uninstall.sh` from your retained release folder. It stops/disables the services and removes only this application's startup/proxy/update-policy configuration. It **keeps application files, media, credentials, and certificates** for recovery. Desktop auto-login, timezone, installed OS packages, and any Tailscale connection remain; adjust these in the OS separately if retiring the device. A reboot ends the current kiosk user service.

## Development and verification

The cross-platform development environment uses `requirements.txt`; the Pi installer uses OS packages. Python 3.11+ is required.

```bash
python -m venv .venv
# Activate the environment for your OS, then:
python -m pip install -r requirements.txt pytest
python -m pytest -q
```

See `VALIDATION.md` for completed checks and the on-device acceptance checklist. Real Pi boot, GPU/video decoding, the restaurant network, and the three external sites must still be checked on your hardware before unattended use.
