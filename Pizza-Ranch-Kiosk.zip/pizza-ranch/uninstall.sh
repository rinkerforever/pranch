#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 || -z "${SUDO_USER:-}" || "$SUDO_USER" == root ]]; then
  echo 'Run from the original Pi desktop account: sudo bash uninstall.sh'; exit 1
fi
systemctl disable --now pizza-ranch.service pizza-ranch-updates.timer || true
systemctl stop pizza-ranch-updates.service || true
systemctl disable --now pizza-ranch-app-updates.timer || true
systemctl stop pizza-ranch-app-updates.service || true
desktop_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
if [[ "$desktop_home" == /home/* && -f "$desktop_home/.config/labwc/autostart" ]]; then
  sed -i '\|^# Pizza Ranch kiosk$|d;\|^/bin/sh /opt/pizza-ranch/deploy/start-kiosk.sh &$|d' "$desktop_home/.config/labwc/autostart"
fi
rm -f /etc/systemd/system/pizza-ranch.service \
      /etc/systemd/system/pizza-ranch-updates.service \
      /etc/systemd/system/pizza-ranch-updates.timer \
      /etc/systemd/system/pizza-ranch-app-updates.service \
      /etc/systemd/system/pizza-ranch-app-updates.timer \
      /etc/systemd/user/pizza-ranch-kiosk.service \
      /etc/nginx/conf.d/pizza-ranch.conf \
      /etc/apt/apt.conf.d/52pizza-ranch-unattended
systemctl daemon-reload
nginx -t && systemctl reload nginx
echo 'Startup/services removed. Data, credentials, installed packages and OS settings retained.'
echo 'If retiring remote access, run: sudo tailscale serve reset; sudo tailscale logout'
echo 'Reboot to end the current desktop kiosk session.'
