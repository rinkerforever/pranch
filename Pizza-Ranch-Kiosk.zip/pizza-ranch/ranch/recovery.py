"""Identify directly connected Ethernet/Wi-Fi subnets, excluding VPN devices."""
import ipaddress
import json
import subprocess


def lan_interfaces():
    try:
        result = subprocess.run(['ip', '-j', '-4', 'addr', 'show', 'up'],
                                capture_output=True, text=True, timeout=3, check=True)
        interfaces = []
        for device in json.loads(result.stdout):
            if not device.get('ifname', '').startswith(('eth', 'en', 'wl')):
                continue
            for address in device.get('addr_info', []):
                if address.get('family') == 'inet' and address.get('scope') == 'global':
                    interfaces.append(ipaddress.ip_interface(f"{address['local']}/{address['prefixlen']}"))
        return interfaces
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError):
        return []  # Fail closed when interface discovery fails.


def matching_lan(client, interfaces):
    try:
        address = ipaddress.ip_address(client)
    except ValueError:
        return None
    if address.is_loopback or address.is_unspecified or address.is_multicast:
        return None
    for interface in interfaces:
        if (address in interface.network and address != interface.ip and
                address not in {interface.network.network_address, interface.network.broadcast_address}):
            return interface
    return None
