"""Accept data only. Never execute uploads or interpolate names into commands."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid
import warnings
import tempfile
import errno
import logging

from PIL import Image, ImageOps, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 64_000_000
ALLOWED = {'.jpg', '.jpeg', '.png', '.webp', '.heic', '.heif', '.mp4', '.mov'}
VIDEO = {'.mp4', '.mov'}


class MediaError(ValueError):
    pass


def convert_heif(incoming, temporary):
    decoder = shutil.which('heif-dec') or shutil.which('heif-convert')
    if not decoder:
        raise MediaError('HEIC support is not installed on this Pi. Rerun the updated installer, or upload a JPEG photo.')
    destination = Path(temporary) / 'photo.jpg'
    command = [decoder, '-q', '85', str(incoming), str(destination)]
    if os.name == 'posix':
        limiter = shutil.which('prlimit')
        if not limiter:
            raise MediaError('HEIC processing support is incomplete. Rerun the updated installer.')
        command = [limiter, '--as=268435456', '--fsize=33554432', '--cpu=60', '--', *command]
    try:
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=90, check=True)
    except (OSError, subprocess.SubprocessError) as error:
        logging.getLogger(__name__).warning('HEIC conversion failed: %s', type(error).__name__)
        raise MediaError('This HEIC photo could not be converted within the Pi’s limits. Export it as a smaller JPEG and retry.') from error
    # HEIF collections can produce photo-1.jpg, photo-2.jpg, etc. Use the first
    # rendered photo; TemporaryDirectory removes auxiliary output on every exit.
    photos = sorted(Path(temporary).glob('*.jpg'))
    if not photos:
        raise MediaError('The HEIC file did not contain a usable photo.')
    return destination if destination.exists() else photos[0]


def ingest(upload, directory, max_bytes, reserve_bytes):
    directory = Path(directory)
    suffix = Path(upload.filename or '').suffix.lower()
    if not suffix:
        suffix = {'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp',
                  'image/heic': '.heic', 'image/heif': '.heif',
                  'video/mp4': '.mp4', 'video/quicktime': '.mov'}.get(upload.mimetype, '')
    if suffix not in ALLOWED:
        raise MediaError('Choose a JPEG, PNG, WebP, HEIC photo, or H.264 MP4/MOV video.')
    identifier = uuid.uuid4().hex
    incoming = directory / (identifier + '.part')
    output = directory / (identifier + ('.mp4' if suffix in VIDEO else '.jpg'))
    written = 0
    try:
        # Exclusive creation plus private directory prevents symlink substitution.
        with incoming.open('xb') as target:
            os.chmod(incoming, 0o600)
            while chunk := upload.stream.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise MediaError('File exceeds the upload size limit.')
                if suffix not in VIDEO and written > 20 * 1024**2:
                    raise MediaError('Images must be 20 MB or smaller. Export a smaller copy from your phone.')
                if shutil.disk_usage(directory).free < reserve_bytes + len(chunk):
                    raise MediaError('Not enough storage. Remove unused media first.')
                target.write(chunk)
        # Reserve space for a sanitized copy as well as the original.
        if shutil.disk_usage(directory).free < reserve_bytes + max(written * 2, 64 * 1024**2):
            raise MediaError('Not enough storage to safely process this file.')
        if suffix in VIDEO:
            if not shutil.which('ffprobe') or not shutil.which('ffmpeg'):
                raise MediaError('Video support is not installed. Rerun the installer to install FFmpeg and ffprobe.')
            probe = subprocess.run(
                ['ffprobe', '-v', 'error', '-protocol_whitelist', 'file',
                 '-show_entries', 'format=format_name,duration:stream=codec_type,codec_name,width,height',
                 '-of', 'json', str(incoming)],
                capture_output=True, timeout=30, check=True)
            info = json.loads(probe.stdout)
            streams = info.get('streams', [])
            videos = [s for s in streams if s.get('codec_type') == 'video']
            audios = [s for s in streams if s.get('codec_type') == 'audio']
            if any(s.get('codec_name') == 'hevc' for s in videos):
                raise MediaError('This iPhone video uses HEVC. Export an H.264 video at 1080p or below. Camera > Formats > Most Compatible applies to new recordings.')
            if ('mp4' not in info.get('format', {}).get('format_name', '').split(',') or
                    len(videos) != 1 or videos[0].get('codec_name') != 'h264' or
                    videos[0].get('width', 0) > 1920 or videos[0].get('height', 0) > 1080 or
                    any(s.get('codec_name') != 'aac' for s in audios)):
                raise MediaError('Use H.264 MP4/MOV video up to 1920 × 1080, with optional AAC audio. Export a compatible copy before uploading.')
            # Re-mux explicit video/audio streams; strip metadata/attachments, no transcoding.
            subprocess.run(
                ['ffmpeg', '-nostdin', '-v', 'error', '-protocol_whitelist', 'file',
                 '-i', str(incoming), '-map', '0:v:0', '-map', '0:a:0?', '-c', 'copy',
                 '-map_metadata', '-1', '-map_chapters', '-1', '-movflags', '+faststart',
                 '-fs', str(max_bytes), str(output)],
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=180, check=True)
            kind = 'video'
        else:
            if written > 20 * 1024**2:
                raise MediaError('Images must be 20 MB or smaller.')
            with tempfile.TemporaryDirectory(prefix=identifier + '-', dir=directory) as temporary, warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                image_path = convert_heif(incoming, temporary) if suffix in {'.heic', '.heif'} else incoming
                with Image.open(image_path) as source:
                    if source.format not in {'JPEG', 'PNG', 'WEBP'}:
                        raise MediaError('The file contents do not match a supported image.')
                    if source.format != 'JPEG' and source.width * source.height > 16_000_000:
                        raise MediaError('PNG/WebP images must be at most 16 megapixels. Export a smaller JPEG.')
                    # JPEG draft decoding avoids loading a full 24/48 MP iPhone
                    # photo into RAM before scaling it down for the TV.
                    source.draft('RGB', (1920, 1920))
                    source.load()
                    picture = ImageOps.exif_transpose(source)
                    picture.thumbnail((1920, 1080))
                    picture.convert('RGB').save(output, 'JPEG', quality=90)
            kind = 'image'
        os.chmod(output, 0o600)  # Data-only files; no execute bit.
        if not output.stat().st_size or output.stat().st_size >= max_bytes:
            raise MediaError('The processed file is empty or too large.')
        name = (upload.filename or 'Media').replace('\\', '/').split('/')[-1]
        name = ''.join(c for c in name if c.isprintable())[:150] or 'Media'
        return {'id': identifier, 'name': name, 'filename': output.name,
                'kind': kind, 'size': output.stat().st_size}
    except MediaError:
        output.unlink(missing_ok=True)
        raise
    except PermissionError as error:
        output.unlink(missing_ok=True)
        raise MediaError('The Pi cannot write to its media folder. Rerun the installer to repair permissions.') from error
    except OSError as error:
        output.unlink(missing_ok=True)
        if error.errno == errno.ENOSPC:
            raise MediaError('The Pi is out of storage. Remove unused media and retry.') from error
        raise MediaError('The Pi could not read or save this file. Try a JPEG photo or check the service logs.') from error
    except (UnidentifiedImageError, Image.DecompressionBombError,
            Image.DecompressionBombWarning, ValueError,
            subprocess.SubprocessError, KeyError) as error:
        output.unlink(missing_ok=True)
        raise MediaError('This media could not be validated. Check its format and try again.') from error
    finally:
        incoming.unlink(missing_ok=True)
