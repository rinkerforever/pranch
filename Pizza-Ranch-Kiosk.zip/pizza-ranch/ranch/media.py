"""Accept data only. Never execute uploads or interpolate names into commands."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid
import warnings

from PIL import Image, ImageOps, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 16_000_000
ALLOWED = {'.jpg', '.jpeg', '.png', '.webp', '.mp4'}


class MediaError(ValueError):
    pass


def ingest(upload, directory, max_bytes, reserve_bytes):
    directory = Path(directory)
    suffix = Path(upload.filename or '').suffix.lower()
    if suffix not in ALLOWED:
        raise MediaError('Choose a JPG, PNG, WebP, or H.264 MP4 file.')
    identifier = uuid.uuid4().hex
    incoming = directory / (identifier + '.part')
    output = directory / (identifier + ('.mp4' if suffix == '.mp4' else '.jpg'))
    written = 0
    try:
        # Exclusive creation plus private directory prevents symlink substitution.
        with incoming.open('xb') as target:
            os.chmod(incoming, 0o600)
            while chunk := upload.stream.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise MediaError('File exceeds the upload size limit.')
                if shutil.disk_usage(directory).free < reserve_bytes + len(chunk):
                    raise MediaError('Not enough storage. Remove unused media first.')
                target.write(chunk)
        # Reserve space for a sanitized copy as well as the original.
        if shutil.disk_usage(directory).free < reserve_bytes + max(written * 2, 64 * 1024**2):
            raise MediaError('Not enough storage to safely process this file.')
        if suffix == '.mp4':
            probe = subprocess.run(
                ['ffprobe', '-v', 'error', '-protocol_whitelist', 'file',
                 '-show_entries', 'format=format_name,duration:stream=codec_type,codec_name,width,height',
                 '-of', 'json', str(incoming)],
                capture_output=True, timeout=30, check=True)
            info = json.loads(probe.stdout)
            streams = info.get('streams', [])
            videos = [s for s in streams if s.get('codec_type') == 'video']
            audios = [s for s in streams if s.get('codec_type') == 'audio']
            if ('mp4' not in info.get('format', {}).get('format_name', '').split(',') or
                    len(videos) != 1 or videos[0].get('codec_name') != 'h264' or
                    videos[0].get('width', 0) > 1920 or videos[0].get('height', 0) > 1080 or
                    any(s.get('codec_name') != 'aac' for s in audios)):
                raise MediaError('Use an H.264 MP4, up to 1920 × 1080, with optional AAC audio.')
            # Re-mux explicit video/audio streams; strip metadata/attachments, no transcoding.
            subprocess.run(
                ['ffmpeg', '-nostdin', '-v', 'error', '-protocol_whitelist', 'file',
                 '-i', str(incoming), '-map', '0:v:0', '-map', '0:a:0?', '-c', 'copy',
                 '-map_metadata', '-1', '-map_chapters', '-1', '-movflags', '+faststart',
                 '-fs', str(max_bytes), str(output)],
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=180, check=True)
            kind = 'video'
        else:
            if written > 20 * 1024**2:
                raise MediaError('Images must be 20 MB or smaller.')
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                with Image.open(incoming) as source:
                    if source.format not in {'JPEG', 'PNG', 'WEBP'}:
                        raise MediaError('The file contents do not match a supported image.')
                    source.load()
                    picture = ImageOps.exif_transpose(source)
                    picture.thumbnail((1920, 1080))
                    picture.convert('RGB').save(output, 'JPEG', quality=90)
            kind = 'image'
        os.chmod(output, 0o600)  # Data-only files; no execute bit.
        if not output.stat().st_size or output.stat().st_size >= max_bytes:
            raise MediaError('The processed file is empty or too large.')
        name = (upload.filename or 'Media').replace('\\', '/').split('/')[-1]
        name = ''.join(c for c in name if c.isprintable())[:150] or 'Media'
        return {'id': identifier, 'name': name, 'filename': output.name,
                'kind': kind, 'size': output.stat().st_size}
    except MediaError:
        output.unlink(missing_ok=True)
        raise
    except (UnidentifiedImageError, Image.DecompressionBombError,
            Image.DecompressionBombWarning, OSError, ValueError,
            subprocess.SubprocessError, KeyError) as error:
        output.unlink(missing_ok=True)
        raise MediaError('This media could not be validated. Check its format and try again.') from error
    finally:
        incoming.unlink(missing_ok=True)
