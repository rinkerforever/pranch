"""Local management demo. Never installs Pi services or opens LAN listeners."""
import argparse
from pathlib import Path
import shutil
import threading
import webbrowser

from waitress import create_server
from ranch.app import create_app


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error('Choose a port from 1024 to 65535.')
    directory = Path(__file__).resolve().parents[1] / 'demo-data'
    app = create_app({'DATA_DIR': str(directory), 'DEVICE_TOKEN_FILE': '',
                      'SESSION_COOKIE_SECURE': False, 'DEMO': True,
                      'DEMO_VIDEO_AVAILABLE': bool(shutil.which('ffmpeg') and shutil.which('ffprobe'))})
    try:
        server = create_server(app, host='127.0.0.1', port=args.port, threads=4,
                               max_request_body_size=app.config['MAX_CONTENT_LENGTH'])
    except OSError as error:
        raise SystemExit(f'Could not open demo port {args.port}: {error}. Try -Port 8085.') from error
    url = f'http://localhost:{args.port}'
    print(f'\nPizza Ranch management demo: {url}', flush=True)
    print('First login: admin / pranch. Keep using your new password after changing it.', flush=True)
    print('Local demo only: no TV control, Pi startup changes, or scheduled updates.', flush=True)
    print(f'Demo uploads/settings are stored separately in: {directory}', flush=True)
    print('Press Ctrl+C in this terminal to stop.\n', flush=True)
    if not args.no_browser:
        threading.Thread(target=webbrowser.open, args=(url,), daemon=True).start()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.close()


if __name__ == '__main__':
    main()
