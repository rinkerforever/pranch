"""Lightweight paired display service for additional Raspberry Pi 3 B+ TVs."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import ssl
import subprocess
import threading
import time
import urllib.error
import urllib.request
import urllib.parse

from flask import Flask, abort, jsonify, render_template, request, send_file
from waitress import serve

DATA = Path(os.environ.get('RANCH_NODE_DATA', '/var/lib/pizza-ranch-node'))
TOKEN_FILE = DATA / 'server-token'
CODE_FILE = DATA / 'pairing-code'
SERVER_FILE = DATA / 'server-url'
CERT_FILE = DATA / 'server-certificate-sha256'
CERT_PEM_FILE = DATA / 'server-certificate.pem'
MEDIA = DATA / 'media'
LOCAL_TOKEN = Path(os.environ.get('RANCH_DEVICE_TOKEN_FILE', '/etc/pizza-ranch/device-token'))
SOURCES = {
    'menu': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only',
    'ads': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only',
    'funzone': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads',
}


def identity():
    machine = Path('/etc/machine-id').read_text().strip()
    return hashlib.sha256(('pizza-ranch:' + machine).encode()).hexdigest()[:32]


def pairing_code(force=False):
    if force or not CODE_FILE.exists() or time.time() - CODE_FILE.stat().st_mtime >= 900:
        CODE_FILE.write_text(f'{secrets.randbelow(900000) + 100000:06d}')
        os.chmod(CODE_FILE, 0o600)
    return CODE_FILE.read_text().strip()


def discover_server():
    configured = os.environ.get('RANCH_SERVER', '').strip()
    if configured:
        return configured.rstrip('/')
    try:
        result = subprocess.run(['avahi-browse', '-rtp', '_pizza-ranch-controller._tcp'],
                                capture_output=True, text=True, timeout=12, check=True)
        for line in result.stdout.splitlines():
            fields = line.split(';')
            if len(fields) >= 9 and fields[0] == '=' and fields[2] == 'IPv4':
                address = ipaddress.ip_address(fields[7])
                if address.is_private and not address.is_loopback:
                    return f'https://{address}:{int(fields[8])}'
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    return None


def remote(base, path, payload=None, token=None, timeout=20, certificate_pem=None):
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['X-Display-Token'] = token
    call = urllib.request.Request(base + path,
        data=json.dumps(payload).encode() if payload is not None else None, headers=headers)
    # The controller uses its locally generated certificate. Pairing is confirmed
    # using the code physically displayed on this TV.
    certificate_pem = certificate_pem or (CERT_PEM_FILE.read_text() if CERT_PEM_FILE.exists() else None)
    context = ssl.create_default_context(cadata=certificate_pem) if certificate_pem else ssl._create_unverified_context()
    context.check_hostname = False
    with urllib.request.urlopen(call, timeout=timeout, context=context) as response:
        return json.load(response)


def server_certificate(base):
    parsed = urllib.parse.urlsplit(base)
    if parsed.scheme != 'https' or not parsed.hostname:
        raise ValueError('Display controller must use HTTPS')
    pem = ssl.get_server_certificate((parsed.hostname, parsed.port or 443), timeout=10)
    return pem, hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest()


def download(base, node_id, token, item):
    if not CERT_FILE.exists() or not CERT_PEM_FILE.exists():
        raise ssl.SSLError('The display is not securely paired.')
    destination = MEDIA / (item['id'] + ('.mp4' if item['kind'] == 'video' else '.jpg'))
    if destination.exists() and destination.stat().st_size == item['size']:
        digest = hashlib.sha256()
        with destination.open('rb') as cached:
            while chunk := cached.read(1024 * 1024):
                digest.update(chunk)
        if digest.hexdigest() == item['sha256']:
            return destination
    temporary = MEDIA / (item['id'] + '.part')
    call = urllib.request.Request(base + '/fleet/media/' + item['id'],
        headers={'X-Display-ID': node_id, 'X-Display-Token': token})
    digest, size = hashlib.sha256(), 0
    try:
        context = ssl.create_default_context(cadata=CERT_PEM_FILE.read_text())
        context.check_hostname = False
        with urllib.request.urlopen(call, timeout=180, context=context) as response, \
                temporary.open('xb') as output:
            os.chmod(temporary, 0o600)
            while chunk := response.read(1024 * 1024):
                size += len(chunk)
                if size > 256 * 1024**2:
                    raise ValueError('Media exceeds node cache limit')
                digest.update(chunk)
                output.write(chunk)
        if size != item['size'] or not secrets.compare_digest(digest.hexdigest(), item['sha256']):
            raise ValueError('Media hash or size mismatch')
        temporary.replace(destination)
        os.chmod(destination, 0o600)
        return destination
    finally:
        temporary.unlink(missing_ok=True)


def create_node_app():
    DATA.mkdir(parents=True, exist_ok=True)
    MEDIA.mkdir(exist_ok=True)
    os.chmod(DATA, 0o700)
    os.chmod(MEDIA, 0o700)
    node_id = identity()
    name = socket.gethostname()
    local_token = LOCAL_TOKEN.read_text().strip()
    pairing_code()
    state = dict(source='setup', url='http://127.0.0.1:8080/device/setup', revision=0,
                 playlist=[], seconds=10, muted=True, server='', status='Searching for the main server…')
    lock = threading.RLock()
    app = Flask(__name__)

    def local_device():
        if request.remote_addr not in {'127.0.0.1', '::1'}:
            abort(403)

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.get('/device/state')
    def device_state():
        local_device()
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), local_token):
            abort(403)
        with lock:
            result = dict(state)
        result.update(registered=True, recovery=False, maintenance={})
        return jsonify(result)

    @app.post('/device/heartbeat')
    def heartbeat():
        local_device()
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), local_token):
            abort(403)
        return jsonify(ok=True)

    @app.get('/device/setup')
    def setup():
        local_device()
        with lock:
            status = state['status']
        return render_template('node_setup.html', code=pairing_code(), name=name, status=status)

    @app.get('/device/player')
    def player():
        local_device()
        return render_template('player.html')

    @app.get('/device/offline')
    def offline():
        local_device()
        return render_template('offline.html')

    @app.get('/device/playlist')
    def playlist():
        local_device()
        with lock:
            return jsonify(items=[{'url': '/device/media/' + i['id'], 'kind': i['kind']}
                                  for i in state['playlist']],
                           seconds=state['seconds'], muted=state['muted'])

    @app.get('/device/media/<identifier>')
    def media(identifier):
        local_device()
        with lock:
            item = next((i for i in state['playlist'] if i['id'] == identifier), None)
        if not item:
            abort(404)
        path = MEDIA / (identifier + ('.mp4' if item['kind'] == 'video' else '.jpg'))
        return send_file(path, conditional=True,
                         mimetype='video/mp4' if item['kind'] == 'video' else 'image/jpeg')

    def synchronize():
        while True:
            try:
                base = SERVER_FILE.read_text().strip() if SERVER_FILE.exists() else discover_server()
                if not base:
                    raise OSError('Main server not found on this Wi-Fi network.')
                SERVER_FILE.write_text(base)
                os.chmod(SERVER_FILE, 0o600)
                token = TOKEN_FILE.read_text().strip() if TOKEN_FILE.exists() else ''
                if token and (not CERT_FILE.exists() or not CERT_PEM_FILE.exists()):
                    TOKEN_FILE.unlink(missing_ok=True)
                    token = ''
                if not token:
                    certificate_pem, observed = server_certificate(base)
                    answer = remote(base, '/fleet/hello', dict(id=node_id, name=name,
                                    code=pairing_code(), certificate=observed),
                                    certificate_pem=certificate_pem)
                    if answer.get('token'):
                        local_ca = answer.get('ca', '')
                        ssl.create_default_context(cadata=local_ca)
                        TOKEN_FILE.write_text(answer['token'])
                        os.chmod(TOKEN_FILE, 0o600)
                        CERT_FILE.write_text(observed)
                        os.chmod(CERT_FILE, 0o600)
                        CERT_PEM_FILE.write_text(local_ca)
                        os.chmod(CERT_PEM_FILE, 0o600)
                        token = answer['token']
                    else:
                        with lock:
                            state['status'] = 'Found the server. Waiting for pairing in its admin page.'
                        time.sleep(5)
                        continue
                with lock:
                    report = dict(id=node_id, source=state['source'], status=state['status'])
                desired = remote(base, '/fleet/state', report, token)
                if desired['source'] == 'media':
                    if sum(item['size'] for item in desired['playlist']) > 2 * 1024**3:
                        raise ValueError('Playlist is larger than the 2 GB display cache limit.')
                    if shutil.disk_usage(MEDIA).free < sum(item['size'] for item in desired['playlist']) + 256 * 1024**2:
                        raise ValueError('Display needs more free storage for this playlist.')
                    for item in desired['playlist']:
                        download(base, node_id, token, item)
                    keep = {i['id'] + ('.mp4' if i['kind'] == 'video' else '.jpg') for i in desired['playlist']}
                    for file in MEDIA.iterdir():
                        if file.is_file() and file.name not in keep:
                            file.unlink()
                    desired['url'] = 'http://127.0.0.1:8080/device/player'
                with lock:
                    state.update(desired, server=base, status='Connected to the main server.')
            except urllib.error.HTTPError as error:
                if error.code == 403:
                    TOKEN_FILE.unlink(missing_ok=True)
                    pairing_code(force=True)
                with lock:
                    state['status'] = f'Server rejected the connection (HTTP {error.code}).'
            except Exception as error:
                with lock:
                    state['status'] = str(error)[:160]
                if not TOKEN_FILE.exists():
                    SERVER_FILE.unlink(missing_ok=True)
            time.sleep(5)

    threading.Thread(target=synchronize, daemon=True).start()
    return app


def main():
    serve(create_node_app(), host='127.0.0.1', port=8080, threads=4)


if __name__ == '__main__':
    main()
