"""Pair the server Pi with the cloud control plane and apply assignments."""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
import urllib.error
import urllib.request

CLOUD = os.environ.get('RANCH_CLOUD_URL', 'https://display.projectaimnet.com').rstrip('/')
DATA = Path(os.environ.get('RANCH_DATA', '/var/lib/pizza-ranch'))
CREDS = DATA / 'cloud-device.json'
DB = DATA / 'ranch.sqlite3'


def request(path, payload=None, token=None):
    headers = {'Content-Type': 'application/json', 'User-Agent': 'PizzaRanchPi/1.0'}
    if token:
        headers['Authorization'] = 'Device ' + token
    body = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(CLOUD + path, data=body, headers=headers,
                                 method='POST' if payload is not None else 'GET')
    with urllib.request.urlopen(req, timeout=20) as response:
        return json.load(response)


def save_credentials(value):
    DATA.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.cloud-', dir=DATA)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream)
        os.chmod(name, 0o600)
        os.replace(name, CREDS)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def pair(code):
    digits = ''.join(character for character in code if character.isdigit())
    if len(digits) != 6:
        raise SystemExit('Enter the six-digit code shown by the cloud admin page.')
    result = request('/api/device/pair', {'code': digits})
    save_credentials({'device_id': result['device_id'], 'screen_id': result['screen_id'],
                      'location_id': result['location_id'], 'device_token': result['device_token']})
    print('Cloud pairing complete. The display will appear online shortly.')


def apply(state):
    pages = state.get('pages') or {}
    desired = state.get('desired_source', 'menu')
    source = desired if desired in {'menu', 'ads', 'funzone', 'media'} else 'menu'
    if desired.startswith('custom:'):
        custom = next((item for item in pages.get('custom_pages', [])
                       if 'custom:' + str(item.get('id')) == desired), None)
        if custom:
            pages = dict(pages, menu_url=custom.get('url'))
    with sqlite3.connect(DB, timeout=20) as db:
        row = db.execute("SELECT value FROM settings WHERE key='source'").fetchone()
        current = json.loads(row[0]) if row else 'menu'
        changed = current != source
        for column in ('menu_url', 'ads_url', 'funzone_url'):
            value = pages.get(column)
            if value:
                db.execute(f'UPDATE locations SET {column}=? WHERE id=\'tyler\'', (value,))
        if changed:
            revision = db.execute("SELECT value FROM settings WHERE key='revision'").fetchone()
            revision = int(json.loads(revision[0])) + 1 if revision else 1
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('source',?)", (json.dumps(source),))
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('revision',?)", (json.dumps(revision),))
            db.execute("UPDATE location_settings SET source=?,revision=? WHERE location_id='tyler'", (source, revision))
        db.commit()
    return source


def run():
    while True:
        try:
            credentials = json.loads(CREDS.read_text())
            state = request('/api/device/state', {}, credentials['device_token'])
            reported = apply(state)
            request('/api/device/state', {'reported_source': reported}, credentials['device_token'])
        except FileNotFoundError:
            print('Cloud device is not paired. Use: sudo -u ranch python3 -m ranch.cloud --pair CODE', flush=True)
            time.sleep(60)
        except (OSError, ValueError, KeyError, sqlite3.Error, urllib.error.URLError) as error:
            print('Cloud synchronization failed; keeping the last assignment:', error, flush=True)
            time.sleep(30)
        else:
            time.sleep(15)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pair')
    args = parser.parse_args()
    if args.pair:
        pair(args.pair)
    else:
        run()


if __name__ == '__main__':
    main()
