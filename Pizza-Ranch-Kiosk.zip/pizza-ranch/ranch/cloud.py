"""Pair a server Pi with the cloud control plane and cache assigned campaigns."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
from types import SimpleNamespace
import urllib.error
import urllib.request

from ranch.media import ingest, MediaError

CLOUD = os.environ.get('RANCH_CLOUD_URL', 'https://display.projectaimnet.com').rstrip('/')
DATA = Path(os.environ.get('RANCH_DATA', '/var/lib/pizza-ranch'))
CREDS = DATA / 'cloud-device.json'
DB = DATA / 'ranch.sqlite3'
MEDIA = DATA / 'media'
MAX_FILE = 100 * 1024**2
MAX_CAMPAIGN = 2 * 1024**3


def request(path, payload=None, token=None):
    headers = {'Content-Type': 'application/json', 'User-Agent': 'PizzaRanchPi/2.0'}
    if token:
        headers['Authorization'] = 'Device ' + token
    body = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(CLOUD + path, data=body, headers=headers,
                                 method='POST' if payload is not None else 'GET')
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.load(response)


def save_credentials(value):
    DATA.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.cloud-', dir=DATA)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream)
        os.chmod(name, 0o600)
        os.replace(name, CREDS)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def pair(code):
    digits = ''.join(character for character in code if character.isdigit())
    if len(digits) != 6:
        raise SystemExit('Enter the six-digit code shown by the cloud admin page.')
    result = request('/api/device/pair', {'code': digits})
    save_credentials({'device_id': result['device_id'], 'screen_id': result['screen_id'],
                      'location_id': result['location_id'], 'device_token': result['device_token']})
    print('Cloud pairing complete. The display will appear online shortly.')


def download_item(item, token):
    if not 0 < int(item['size']) <= MAX_FILE:
        raise ValueError('Campaign file is outside the permitted size.')
    web_request = urllib.request.Request(CLOUD + item['url'], headers={
        'Authorization': 'Device ' + token, 'User-Agent': 'PizzaRanchPi/2.0'})
    fd, temporary = tempfile.mkstemp(prefix='.campaign-', suffix=Path(item['filename']).suffix, dir=MEDIA)
    digest = hashlib.sha256(); written = 0
    try:
        with os.fdopen(fd, 'wb') as target, urllib.request.urlopen(web_request, timeout=120) as response:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > MAX_FILE or written > int(item['size']):
                    raise ValueError('Campaign download exceeded its declared size.')
                digest.update(chunk); target.write(chunk)
        if written != int(item['size']) or digest.hexdigest() != item['sha256']:
            raise ValueError('Campaign download did not pass its integrity check.')
        os.chmod(temporary, 0o600)
        with open(temporary, 'rb') as stream:
            upload = SimpleNamespace(filename=item['filename'], mimetype=item['mime_type'], stream=stream)
            return ingest(upload, MEDIA, MAX_FILE, 256 * 1024**2)
    finally:
        Path(temporary).unlink(missing_ok=True)


def sync_campaign(campaign, token):
    items = campaign.get('items') or []
    if not items:
        raise ValueError('The assigned campaign has no media.')
    if sum(int(item.get('size', 0)) for item in items) > MAX_CAMPAIGN:
        raise ValueError('The campaign exceeds the Pi storage limit.')
    MEDIA.mkdir(parents=True, exist_ok=True); os.chmod(MEDIA, 0o700)
    with sqlite3.connect(DB, timeout=30) as db:
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT value FROM settings WHERE key='cloud_campaign_cache'").fetchone()
        try: cache = json.loads(row['value']) if row else {}
        except (ValueError, TypeError): cache = {}
        wanted = []
        for item in items:
            local_id = 'cloud-' + str(item['id'])
            saved = db.execute('SELECT filename FROM media WHERE id=?', (local_id,)).fetchone()
            if not saved or not (MEDIA / saved['filename']).is_file() or cache.get(local_id) != item['sha256']:
                result = download_item(item, token)
                if saved:
                    (MEDIA / saved['filename']).unlink(missing_ok=True)
                db.execute('''INSERT OR REPLACE INTO media(id,name,filename,kind,size,created,sha256,location_id)
                              VALUES(?,?,?,?,?,?,?,?)''',
                           (local_id, str(item['filename'])[:150], result['filename'], result['kind'],
                            result['size'], time.time(), result['sha256'], 'tyler'))
                cache[local_id] = item['sha256']
            wanted.append(local_id)
        placeholders = ','.join('?' for _ in wanted)
        stale = db.execute(f"SELECT id,filename FROM media WHERE id LIKE 'cloud-%' AND id NOT IN ({placeholders})", wanted).fetchall()
        for row in stale:
            (MEDIA / row['filename']).unlink(missing_ok=True)
            db.execute('DELETE FROM media WHERE id=?', (row['id'],)); cache.pop(row['id'], None)
        db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('cloud_campaign_cache',?)", (json.dumps(cache),))
        db.commit()
    return wanted


def apply(state, token):
    pages = state.get('pages') or {}
    desired = state.get('desired_source', 'menu')
    playlist = None
    if desired.startswith('campaign:') and state.get('campaign'):
        playlist = sync_campaign(state['campaign'], token); source = 'media'
    else:
        source = desired if desired in {'menu', 'ads', 'funzone', 'media'} else 'menu'
    if desired.startswith('custom:'):
        custom = next((item for item in pages.get('custom_pages', [])
                       if 'custom:' + str(item.get('id')) == desired), None)
        if custom:
            pages = dict(pages, menu_url=custom.get('url')); source = 'menu'
    with sqlite3.connect(DB, timeout=20) as db:
        row = db.execute("SELECT value FROM settings WHERE key='source'").fetchone()
        current = json.loads(row[0]) if row else 'menu'; changed = current != source
        for column in ('menu_url', 'ads_url', 'funzone_url'):
            value = pages.get(column)
            if value:
                db.execute(f"UPDATE locations SET {column}=? WHERE id='tyler'", (value,))
        if playlist is not None:
            seconds = int(state['campaign'].get('seconds', 10)); muted = bool(state['campaign'].get('muted', True))
            saved_playlist = db.execute("SELECT value FROM settings WHERE key='playlist'").fetchone()
            saved_seconds = db.execute("SELECT value FROM settings WHERE key='seconds'").fetchone()
            saved_muted = db.execute("SELECT value FROM settings WHERE key='muted'").fetchone()
            campaign_changed = (not saved_playlist or json.loads(saved_playlist[0]) != playlist or
                                not saved_seconds or int(json.loads(saved_seconds[0])) != seconds or
                                not saved_muted or bool(json.loads(saved_muted[0])) != muted)
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('playlist',?)", (json.dumps(playlist),))
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('seconds',?)", (json.dumps(seconds),))
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('muted',?)", (json.dumps(muted),))
            db.execute("UPDATE location_settings SET playlist=?,seconds=?,muted=? WHERE location_id='tyler'",
                       (json.dumps(playlist), seconds, int(muted)))
        if changed or (playlist is not None and campaign_changed):
            revision = db.execute("SELECT value FROM settings WHERE key='revision'").fetchone()
            revision = int(json.loads(revision[0])) + 1 if revision else 1
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('source',?)", (json.dumps(source),))
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('revision',?)", (json.dumps(revision),))
            db.execute("UPDATE location_settings SET source=?,revision=? WHERE location_id='tyler'", (source, revision))
        db.commit()
    return source


def run():
    while True:
        try:
            credentials = json.loads(CREDS.read_text())
            state = request('/api/device/state', {}, credentials['device_token'])
            reported = apply(state, credentials['device_token'])
            request('/api/device/state', {'reported_source': reported}, credentials['device_token'])
        except FileNotFoundError:
            print('Cloud device is not paired. Use: sudo -u ranch python3 -m ranch.cloud --pair CODE', flush=True); time.sleep(60)
        except (OSError, ValueError, KeyError, MediaError, sqlite3.Error, urllib.error.URLError) as error:
            print('Cloud synchronization failed; keeping the last assignment:', error, flush=True); time.sleep(30)
        else:
            time.sleep(15)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--pair'); args = parser.parse_args()
    pair(args.pair) if args.pair else run()


if __name__ == '__main__':
    main()
