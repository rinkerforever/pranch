"""Request the fixed updater via systemd's path trigger, without root access."""
from pathlib import Path
import subprocess

REQUEST = Path('/var/lib/pizza-ranch-update-requests/check')


def update_state():
    try:
        result = subprocess.run(['systemctl', 'show', 'pizza-ranch-app-updates.service',
                                 '--property=ActiveState', '--value'],
                                capture_output=True, text=True, timeout=3, check=True)
        active = result.stdout.strip()
        return {'available': True, 'busy': REQUEST.exists() or active in {'activating', 'active', 'deactivating'}}
    except (OSError, subprocess.SubprocessError):
        return {'available': False, 'busy': False}


def request_update():
    try:
        with REQUEST.open('x') as request:
            request.write('check\n')
    except FileExistsError:
        pass  # A pending request is already sufficient.
