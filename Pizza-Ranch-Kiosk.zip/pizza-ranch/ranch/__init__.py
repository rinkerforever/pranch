"""Pizza Ranch display manager."""
