"""Desktop-session controller: one isolated Chromium process, no debug port."""
import json
import logging
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import urllib.error
import urllib.request

BASE = 'http://127.0.0.1:8080'


def api(path, token, payload=None):
    request = urllib.request.Request(BASE + path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={'X-Device-Token': token, 'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=8) as response:
        return json.load(response)


def reachable(url):
    try:
        request = urllib.request.Request(url, method='HEAD', headers={'User-Agent': 'PizzaRanchKiosk/1.0'})
        with urllib.request.urlopen(request, timeout=8) as response:
            return response.status < 400
    except urllib.error.HTTPError as error:
        # Some web servers reject HEAD but accept browser GET.
        return error.code == 405
    except (OSError, urllib.error.URLError):
        return False


def stop_browser(process):
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=8)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    except ProcessLookupError:
        pass


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    token_file = os.environ.get('RANCH_DEVICE_TOKEN_FILE', '/etc/pizza-ranch/device-token')
    token = Path(token_file).read_text().strip()
    binary = shutil.which('chromium') or shutil.which('chromium-browser')
    if not binary:
        raise SystemExit('Chromium is missing. Run the installer.')
    profile = Path.home() / '.local/share/pizza-ranch/chromium'
    profile.mkdir(parents=True, exist_ok=True)
    running = True

    def shutdown(*_):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    process = None
    applied = None
    next_probe = 0
    failure_count = 0
    unhealthy = False
    retry_at = 0
    crash_delay = 2
    launched = 0
    previous_source = None
    try:
        while running:
            try:
                state = api('/device/state', token)
                if state['source'] != previous_source:
                    next_probe, failure_count, unhealthy = 0, 0, False
                    previous_source = state['source']
                now = time.monotonic()
                if state['registered'] and state['source'] != 'media' and now >= next_probe:
                    failure_count = 0 if reachable(state['url']) else failure_count + 1
                    unhealthy = failure_count >= 2
                    next_probe = now + 30
                target = state['url']
                source = state['source'] if state['registered'] else 'setup'
                status = 'Browser running; TV power and website rendering are not verified.'
                if unhealthy and state['registered'] and state['source'] != 'media':
                    target = BASE + ('/device/player' if state['playlist'] else '/device/offline')
                    source = 'fallback'
                    status = 'Website unreachable. Retrying every 30 seconds.'
                maintenance_stamp = state.get('maintenance', {}).get('completed_at', '')
                desired = (target, state['revision'], maintenance_stamp)
                if process is not None and process.poll() is not None:
                    stop_browser(process)
                    process = None
                    applied = None
                    retry_at = now + crash_delay
                    crash_delay = min(60, crash_delay * 2)
                if desired != applied and now >= retry_at:
                    stop_browser(process)
                    flags = [binary, '--kiosk', '--no-first-run', '--noerrdialogs',
                             '--disable-session-crashed-bubble', '--disable-infobars',
                             '--autoplay-policy=no-user-gesture-required',
                             '--user-data-dir=' + str(profile)]
                    if os.environ.get('WAYLAND_DISPLAY'):
                        flags.append('--ozone-platform=wayland')
                    process = subprocess.Popen(flags + [target], start_new_session=True,
                                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    applied = desired
                    launched = now
                    logging.info('Opened kiosk source: %s', source)
                if now - launched > 120:
                    crash_delay = 2
                if process is None:
                    status = 'Browser stopped; waiting to retry.'
                api('/device/heartbeat', token, {'source': source if process else 'stopped',
                    'revision': applied[1] if applied else None, 'status': status})
            except Exception:
                logging.exception('Controller could not synchronize; retaining current display')
            for _ in range(20):
                if not running:
                    break
                time.sleep(0.1)
    finally:
        stop_browser(process)


if __name__ == '__main__':
    main()
