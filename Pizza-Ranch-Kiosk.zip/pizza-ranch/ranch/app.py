import argparse
from datetime import timedelta
from functools import wraps
import io
import ipaddress
import json
import logging
import os
from pathlib import Path
import secrets
import shutil
import socket
import threading
import time

from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
import qrcode
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.exceptions import HTTPException

from ranch.media import ingest, MediaError
from ranch.storage import database, get_setting, set_setting
from ranch.recovery import lan_interfaces, matching_lan
from ranch.updates import request_update, update_state

SOURCES = {
    'menu': ('Menu', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only'),
    'ads': ('Ads', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only'),
    'funzone': ('Funzone Ads', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads'),
    'media': ('Uploaded Media', 'http://127.0.0.1:8080/device/player'),
}


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        APP_VERSION='2026.09.17-manual-update',
        DATA_DIR=os.environ.get('RANCH_DATA', 'data'),
        DEVICE_TOKEN_FILE=os.environ.get('RANCH_DEVICE_TOKEN_FILE', ''),
        PUBLIC_URL=os.environ.get('RANCH_PUBLIC_URL', ''),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SECURE=True,
        SESSION_COOKIE_SAMESITE='Strict', PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=257 * 1024**2, MAX_FORM_MEMORY_SIZE=256 * 1024,
        MAX_FORM_PARTS=20, UPLOAD_LIMIT=256 * 1024**2, RESERVE_BYTES=512 * 1024**2,
    )
    if config:
        app.config.update(config)
    data = Path(app.config['DATA_DIR']).resolve()
    data.mkdir(parents=True, exist_ok=True)
    media = data / 'media'
    media.mkdir(exist_ok=True)
    os.chmod(data, 0o700)
    os.chmod(media, 0o700)
    secret_path = data / 'session-secret'
    if not secret_path.exists():
        with secret_path.open('x') as stream:
            stream.write(secrets.token_hex(32))
        os.chmod(secret_path, 0o600)
    app.secret_key = secret_path.read_text().strip()
    token_path = app.config['DEVICE_TOKEN_FILE']
    device_token = Path(token_path).read_text().strip() if token_path else secrets.token_hex(32)
    app.config['DEVICE_TOKEN'] = device_token
    db_path = data / 'ranch.sqlite3'
    app.config['DB_PATH'] = db_path
    with database(db_path) as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS media(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, filename TEXT NOT NULL UNIQUE,
          kind TEXT NOT NULL, size INTEGER NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts(ip TEXT PRIMARY KEY, count INTEGER, since REAL);
        ''')
        if get_setting(db, 'password') is None:
            set_setting(db, 'password', generate_password_hash('pranch'))
            set_setting(db, 'registered', False)
            set_setting(db, 'generation', 1)
            set_setting(db, 'source', 'menu')
            set_setting(db, 'playlist', [])
            set_setting(db, 'seconds', 10)
            set_setting(db, 'muted', True)
            set_setting(db, 'revision', 1)
    os.chmod(db_path, 0o600)
    upload_lock = threading.Lock()
    report_lock = threading.Lock()
    report = {}
    recovery_lock = threading.RLock()
    recovery = {}

    def require_local_recovery():
        if (request.remote_addr not in {'127.0.0.1', '::1'} or
                request.headers.get('X-Ranch-Local-Entry') != '1'):
            abort(403, 'Password recovery requires the Pi’s local HTTPS address on the same Ethernet/Wi-Fi network. Disconnect remote VPN access for this step.')
        interface = matching_lan(request.headers.get('X-Real-IP', ''), lan_interfaces())
        if interface is None:
            abort(403, 'Connect to the same local subnet as the Pi and use its local HTTPS address to reset the password.')
        return interface

    def recovery_active():
        with recovery_lock:
            if not recovery or recovery['expires'] <= time.time():
                recovery.clear()
                return False
            with database(db_path) as db:
                valid = recovery['generation'] == get_setting(db, 'generation')
            if not valid:
                recovery.clear()
            return valid

    def authenticated():
        with database(db_path) as db:
            return (session.get('user') == 'admin' and
                    session.get('generation') == get_setting(db, 'generation'))

    def require_login(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if not authenticated():
                if request.path.startswith('/api/'):
                    abort(401)
                return redirect(url_for('login'))
            with database(db_path) as db:
                registered = get_setting(db, 'registered')
            if not registered and request.endpoint not in {'password', 'logout'}:
                if request.path.startswith('/api/'):
                    abort(403, 'Change the initial password first.')
                return redirect(url_for('password'))
            return function(*args, **kwargs)
        return wrapped

    def is_device_request():
        # Reverse proxies must deny /device/. Also reject forwarded requests here.
        return (request.remote_addr in {'127.0.0.1', '::1'} and
                request.host.split(':')[0] in {'127.0.0.1', 'localhost'} and
                not any(h in request.headers for h in
                        ['X-Forwarded-For', 'Forwarded', 'X-Real-IP', 'Tailscale-User-Login']))

    def device_only(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if not is_device_request():
                abort(403)
            return function(*args, **kwargs)
        return wrapped

    def csrf_token():
        if 'csrf' not in session:
            session['csrf'] = secrets.token_urlsafe(32)
        return session['csrf']

    app.jinja_env.globals['csrf_token'] = csrf_token

    @app.before_request
    def protect_request():
        # Reject arbitrary DNS names to prevent DNS rebinding onto local endpoints.
        host = request.host.split(':')[0].lower()
        allowed = {socket.gethostname().lower(), socket.gethostname().lower() + '.local',
                   'localhost', 'pizza-ranch.local'}
        try:
            valid_ip = ipaddress.ip_address(host).is_private
        except ValueError:
            valid_ip = False
        if host not in allowed and not valid_ip and not host.endswith('.ts.net'):
            abort(400, 'Unrecognized management hostname.')
        if request.path.startswith('/api/') and not authenticated():
            # Reject unauthenticated uploads before Flask parses multipart data.
            abort(401)
        if request.method in {'POST', 'PUT', 'PATCH', 'DELETE'}:
            if request.endpoint == 'device_heartbeat' and is_device_request():
                if secrets.compare_digest(request.headers.get('X-Device-Token', ''), device_token):
                    return
                abort(403)
            expected = session.get('csrf', '')
            supplied = request.headers.get('X-CSRF-Token', '') or request.form.get('csrf_token', '')
            if not expected or not secrets.compare_digest(expected, supplied):
                abort(403, 'Your session expired. Refresh the page and try again.')

    @app.after_request
    def security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; "
            "frame-ancestors 'none'; form-action 'self'")
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        if request.path.startswith('/api/') or request.path.startswith('/device/'):
            return jsonify(error=error.description), error.code
        return render_template('error.html', message=error.description), error.code

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            # Only the local reverse proxy supplies this; backend is loopback-only.
            ip = request.headers.get('X-Real-IP', request.remote_addr)[:100]
            now = time.time()
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('DELETE FROM attempts WHERE since < ?', (now - 900,))
                row = db.execute('SELECT * FROM attempts WHERE ip=?', (ip,)).fetchone()
                if row and row['count'] >= 5:
                    abort(429, 'Too many attempts. Try again in 15 minutes.')
                good = (request.form.get('username') == 'admin' and
                        check_password_hash(get_setting(db, 'password'), request.form.get('password', '')))
                if good:
                    db.execute('DELETE FROM attempts WHERE ip=?', (ip,))
                    generation = get_setting(db, 'generation')
                else:
                    db.execute('INSERT INTO attempts(ip,count,since) VALUES(?,1,?) '
                               'ON CONFLICT(ip) DO UPDATE SET count=count+1', (ip, now))
            if good:
                session.clear()
                session.update(user='admin', generation=generation)
                session.permanent = True
                return redirect(url_for('dashboard'))
            flash('Username or password is incorrect.', 'error')
        return render_template('login.html')

    @app.route('/recover', methods=['GET', 'POST'])
    def recover():
        interface = require_local_recovery()
        if request.method == 'POST':
            with recovery_lock:
                if not recovery_active():
                    with database(db_path) as db:
                        db.execute('BEGIN IMMEDIATE')
                        now = time.time()
                        if now - get_setting(db, 'reset_requested_at', 0) < 600:
                            abort(429, 'A reset was recently requested. Requests are limited to one every 10 minutes.')
                        generation = get_setting(db, 'generation')
                        set_setting(db, 'reset_requested_at', now)
                    recovery.update(token=secrets.token_urlsafe(32), expires=now + 300,
                                    generation=generation, address=str(interface.ip))
            return redirect(url_for('recover_wait'))
        return render_template('recover.html')

    @app.get('/recover/wait')
    def recover_wait():
        require_local_recovery()
        return render_template('recover_wait.html', active=recovery_active())

    @app.route('/recover/scan', methods=['GET', 'POST'])
    def recover_scan():
        require_local_recovery()
        if request.method == 'GET':
            return render_template('recover_scan.html', token='')
        token = request.form.get('reset_token', '')
        new = request.form.get('new_password', '')
        with recovery_lock:
            if not recovery_active() or not secrets.compare_digest(token, recovery['token']):
                abort(400, 'The reset QR is invalid, expired, or already used. Request a new one from the login page.')
            if not 12 <= len(new) <= 128 or new != request.form.get('confirm_password'):
                flash('Use 12–128 characters and make both new password fields match.', 'error')
                return render_template('recover_scan.html', token=token)
            password_hash = generate_password_hash(new)
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                if (recovery['expires'] <= time.time() or
                        recovery['generation'] != get_setting(db, 'generation')):
                    abort(400, 'This reset has expired. Request another QR code.')
                set_setting(db, 'password', password_hash)
                set_setting(db, 'registered', True)
                set_setting(db, 'generation', get_setting(db, 'generation') + 1)
                set_setting(db, 'revision', get_setting(db, 'revision') + 1)
                db.execute('DELETE FROM attempts')
            recovery.clear()
        session.clear()
        flash('Admin password reset. Sign in with your new password.', 'success')
        return redirect(url_for('login'))

    @app.route('/password', methods=['GET', 'POST'])
    @require_login
    def password():
        with database(db_path) as db:
            first = not get_setting(db, 'registered')
        if request.method == 'POST':
            new = request.form.get('new_password', '')
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                if not check_password_hash(get_setting(db, 'password'), request.form.get('current_password', '')):
                    flash('Current password is incorrect.', 'error')
                elif len(new) < 12 or len(new) > 128 or new != request.form.get('confirm_password'):
                    flash('Use 12–128 characters and make both new password fields match.', 'error')
                elif check_password_hash(get_setting(db, 'password'), new):
                    flash('Choose a different password.', 'error')
                else:
                    generation = get_setting(db, 'generation') + 1
                    set_setting(db, 'password', generate_password_hash(new))
                    set_setting(db, 'registered', True)
                    set_setting(db, 'generation', generation)
                    set_setting(db, 'revision', get_setting(db, 'revision') + 1)
                    session.clear()
                    session.update(user='admin', generation=generation)
                    session.permanent = True
                    flash('Password saved. Setup is complete.', 'success')
                    return redirect(url_for('dashboard'))
        return render_template('password.html', first=first)

    @app.post('/logout')
    @require_login
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @require_login
    def dashboard():
        return render_template('dashboard.html', sources=SOURCES)

    def snapshot():
        with database(db_path) as db:
            state = {key: get_setting(db, key) for key in
                     ['registered', 'source', 'playlist', 'seconds', 'muted', 'revision']}
            state['library'] = [dict(r) for r in db.execute('SELECT * FROM media ORDER BY created')]
        state['free_bytes'] = shutil.disk_usage(media).free
        with report_lock:
            state['display'] = dict(report)
        state['display']['online'] = time.time() - state['display'].get('at', 0) < 20
        maintenance = Path('/var/lib/pizza-ranch-maintenance/status.json')
        try:
            state['maintenance'] = json.loads(maintenance.read_text())
        except (OSError, ValueError):
            state['maintenance'] = {'status': 'No scheduled update has run yet.'}
        try:
            state['app_updates'] = json.loads(Path('/var/lib/pizza-ranch-maintenance/app-status.json').read_text())
        except (OSError, ValueError):
            state['app_updates'] = {'status': 'No GitHub update check has run yet.'}
        state['app_updates'].update(update_state())
        state['reboot_required'] = Path('/var/run/reboot-required').exists()
        return state

    def json_object():
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            abort(400, 'Expected a JSON object.')
        return body

    @app.get('/api/state')
    @require_login
    def state():
        return jsonify(snapshot())

    @app.post('/api/display')
    @require_login
    def change_display():
        body = json_object()
        source = body.get('source')
        if not isinstance(source, str) or source not in SOURCES:
            abort(400, 'Choose one of the four display sources.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            if source == 'media' and not get_setting(db, 'playlist'):
                abort(400, 'Add media to your playlist first.')
            set_setting(db, 'source', source)
            set_setting(db, 'revision', get_setting(db, 'revision') + 1)
        return jsonify(ok=True)

    @app.post('/api/reload')
    @require_login
    def reload_display():
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            set_setting(db, 'revision', get_setting(db, 'revision') + 1)
        return jsonify(ok=True)

    @app.post('/api/app-update')
    @require_login
    def app_update():
        update = update_state()
        if not update['available']:
            abort(503, 'Manual updates are unavailable. Install this release on the Pi once to enable them.')
        if update['busy']:
            return jsonify(ok=True, busy=True), 202
        try:
            request_update()
        except OSError:
            abort(503, 'The Pi could not queue the update check. Rerun the installer to repair permissions.')
        return jsonify(ok=True, busy=True), 202

    @app.post('/api/playlist')
    @require_login
    def playlist():
        body = json_object()
        ids, seconds, muted = body.get('ids'), body.get('seconds'), body.get('muted')
        if (not isinstance(ids, list) or len(ids) > 500 or
                not all(isinstance(i, str) for i in ids) or len(set(ids)) != len(ids) or
                type(seconds) is not int or not 3 <= seconds <= 300 or type(muted) is not bool):
            abort(400, 'Invalid playlist. Use 3–300 seconds per image and unique media entries.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            valid = {r['id'] for r in db.execute('SELECT id FROM media')}
            if not set(ids) <= valid:
                abort(400, 'A playlist file no longer exists. Refresh the library.')
            if not ids and get_setting(db, 'source') == 'media':
                abort(400, 'Switch to a website before clearing the active playlist.')
            for key, value in [('playlist', ids), ('seconds', seconds), ('muted', muted)]:
                set_setting(db, key, value)
            set_setting(db, 'revision', get_setting(db, 'revision') + 1)
        return jsonify(ok=True)

    @app.post('/api/upload')
    @require_login
    def upload():
        if 'file' not in request.files:
            abort(400, 'Choose a file.')
        if not upload_lock.acquire(blocking=False):
            abort(409, 'Another upload is processing. Try again shortly.')
        item = None
        try:
            item = ingest(request.files['file'], media, app.config['UPLOAD_LIMIT'], app.config['RESERVE_BYTES'])
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('INSERT INTO media VALUES(?,?,?,?,?,?)',
                           (item['id'], item['name'], item['filename'], item['kind'], item['size'], time.time()))
                item['added_to_playlist'] = request.form.get('add_to_playlist') == 'true'
                if item['added_to_playlist']:
                    playlist = get_setting(db, 'playlist')
                    if len(playlist) >= 500:
                        abort(400, 'The playlist is full. Remove an entry or turn off automatic playlist addition.')
                    set_setting(db, 'playlist', playlist + [item['id']])
                    set_setting(db, 'revision', get_setting(db, 'revision') + 1)
            return jsonify(item), 201
        except MediaError as error:
            app.logger.warning('Media upload rejected: %s', error)
            abort(400, str(error))
        except Exception:
            if item:
                (media / item['filename']).unlink(missing_ok=True)
            raise
        finally:
            upload_lock.release()

    @app.delete('/api/media/<identifier>')
    @require_login
    def delete_media(identifier):
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            if identifier in get_setting(db, 'playlist'):
                abort(409, 'Remove this file from the playlist and save before deleting it.')
            row = db.execute('SELECT filename FROM media WHERE id=?', (identifier,)).fetchone()
            if not row:
                abort(404)
            (media / row['filename']).unlink(missing_ok=True)
            db.execute('DELETE FROM media WHERE id=?', (identifier,))
        return jsonify(ok=True)

    def serve_media(identifier):
        with database(db_path) as db:
            row = db.execute('SELECT filename,kind FROM media WHERE id=?', (identifier,)).fetchone()
        if not row:
            abort(404)
        # Only database-owned UUID filenames; never a user-supplied path or MIME type.
        return send_file(media / row['filename'], conditional=True,
                         mimetype='video/mp4' if row['kind'] == 'video' else 'image/jpeg')

    @app.get('/media/<identifier>')
    @require_login
    def protected_media(identifier):
        return serve_media(identifier)

    @app.get('/device/media/<identifier>')
    @device_only
    def device_media(identifier):
        return serve_media(identifier)

    @app.get('/device/state')
    @device_only
    def device_state():
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), device_token):
            abort(403)
        result = snapshot()
        result['url'] = SOURCES[result['source']][1] if result['registered'] else 'http://127.0.0.1:8080/device/setup'
        result['recovery'] = recovery_active()
        if result['recovery']:
            result['url'] = 'http://127.0.0.1:8080/device/recovery'
        return jsonify(result)

    @app.get('/device/recovery')
    @device_only
    def recovery_screen():
        if not recovery_active():
            with database(db_path) as db:
                destination = SOURCES[get_setting(db, 'source')][1] if get_setting(db, 'registered') else '/device/setup'
            return redirect(destination)
        return render_template('recovery_screen.html')

    @app.get('/device/recovery-qr.png')
    @device_only
    def recovery_qr():
        with recovery_lock:
            if not recovery_active():
                abort(404)
            # Fragment is read by the phone locally; it is never in HTTP access
            # logs, controller URLs, or the requesting browser's response.
            address = f"https://{recovery['address']}:8443/recover/scan#{recovery['token']}"
            output = io.BytesIO()
            qrcode.make(address).save(output, format='PNG')
        output.seek(0)
        return send_file(output, mimetype='image/png')

    @app.post('/device/heartbeat')
    @device_only
    def device_heartbeat():
        body = json_object()
        with report_lock:
            report.update(at=time.time(), source=str(body.get('source', ''))[:30],
                          status=str(body.get('status', ''))[:300], revision=body.get('revision'))
        return jsonify(ok=True)

    def setup_url():
        configured = app.config['PUBLIC_URL'].strip()
        if configured:
            return configured.rstrip('/') + '/login'
        # Obtain the selected LAN interface without transmitting packets.
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.connect(('192.0.2.1', 80))
                host = sock.getsockname()[0]
        except OSError:
            host = socket.gethostname() + '.local'
        return f'https://{host}:8443/login'

    @app.get('/device/setup')
    @device_only
    def setup():
        with database(db_path) as db:
            if get_setting(db, 'registered'):
                return redirect(SOURCES[get_setting(db, 'source')][1])
        return render_template('setup.html', setup_url=setup_url())

    @app.get('/device/qr.png')
    @device_only
    def qr():
        with database(db_path) as db:
            if get_setting(db, 'registered'):
                abort(404)
        output = io.BytesIO()
        qrcode.make(setup_url()).save(output, format='PNG')
        output.seek(0)
        return send_file(output, mimetype='image/png')

    @app.get('/device/player')
    @device_only
    def player():
        return render_template('player.html')

    @app.get('/device/offline')
    @device_only
    def offline():
        return render_template('offline.html')

    @app.get('/device/playlist')
    @device_only
    def device_playlist():
        state = snapshot()
        library = {i['id']: i for i in state['library']}
        return jsonify(items=[{'url': '/device/media/' + i, 'kind': library[i]['kind']}
                              for i in state['playlist'] if i in library],
                       seconds=state['seconds'], muted=state['muted'])

    return app


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reset-password', action='store_true', help='Local recovery; prompts for a new password.')
    args = parser.parse_args()
    app = create_app()
    if args.reset_password:
        import getpass
        password = getpass.getpass('New admin password (12–128 characters): ')
        if not 12 <= len(password) <= 128 or password != getpass.getpass('Repeat password: '):
            raise SystemExit('Passwords must match and contain 12–128 characters.')
        with database(app.config['DB_PATH']) as db:
            db.execute('BEGIN IMMEDIATE')
            set_setting(db, 'password', generate_password_hash(password))
            set_setting(db, 'registered', True)
            set_setting(db, 'generation', get_setting(db, 'generation') + 1)
            set_setting(db, 'revision', get_setting(db, 'revision') + 1)
        print('Password changed. Existing sessions are invalid.')
        return
    from waitress import serve
    logging.basicConfig(level=logging.INFO)
    serve(app, host='127.0.0.1', port=8080, threads=4,
          max_request_body_size=app.config['MAX_CONTENT_LENGTH'], clear_untrusted_proxy_headers=False)


if __name__ == '__main__':
    main()
