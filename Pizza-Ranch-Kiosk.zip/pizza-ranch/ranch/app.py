import argparse
from datetime import timedelta
from functools import wraps
import io
import ipaddress
import json
import logging
import os
from pathlib import Path
import secrets
import shutil
import socket
import ssl
import threading
import time
import hashlib

from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
import qrcode
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.exceptions import HTTPException

from ranch.media import ingest, MediaError, file_sha256
from ranch.storage import database, get_setting, set_setting
from ranch.recovery import lan_interfaces, matching_lan
from ranch.updates import request_update, update_state
from ranch.accounts import (DEFAULT_LOCATION_ID, DEFAULT_URLS, ROLES,
                            can_access_location, location_state, locations_for_user,
                            migrate as migrate_accounts, save_location_state,
                            user_locations, validate_location, validate_username)

SOURCES = {
    'menu': ('Menu', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only'),
    'ads': ('Ads', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only'),
    'funzone': ('Funzone Ads', 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads'),
    'media': ('Uploaded Media', 'http://127.0.0.1:8080/device/player'),
}


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        APP_VERSION='2026.09.19-cloud-connector',
        DATA_DIR=os.environ.get('RANCH_DATA', 'data'),
        DEVICE_TOKEN_FILE=os.environ.get('RANCH_DEVICE_TOKEN_FILE', ''),
        PUBLIC_URL=os.environ.get('RANCH_PUBLIC_URL', ''),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SECURE=True,
        SESSION_COOKIE_SAMESITE='Strict', PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=257 * 1024**2, MAX_FORM_MEMORY_SIZE=256 * 1024,
        MAX_FORM_PARTS=20, UPLOAD_LIMIT=256 * 1024**2, RESERVE_BYTES=512 * 1024**2,
        TLS_SERVER_CERT=os.environ.get('RANCH_TLS_SERVER_CERT', '/etc/pizza-ranch/tls/server.crt'),
        TLS_CA_CERT=os.environ.get('RANCH_TLS_CA_CERT', '/etc/pizza-ranch/tls/ca.crt'),
    )
    if config:
        app.config.update(config)
    data = Path(app.config['DATA_DIR']).resolve()
    data.mkdir(parents=True, exist_ok=True)
    media = data / 'media'
    media.mkdir(exist_ok=True)
    os.chmod(data, 0o700)
    os.chmod(media, 0o700)
    secret_path = data / 'session-secret'
    if not secret_path.exists():
        with secret_path.open('x') as stream:
            stream.write(secrets.token_hex(32))
        os.chmod(secret_path, 0o600)
    app.secret_key = secret_path.read_text().strip()
    token_path = app.config['DEVICE_TOKEN_FILE']
    device_token = Path(token_path).read_text().strip() if token_path else secrets.token_hex(32)
    app.config['DEVICE_TOKEN'] = device_token
    db_path = data / 'ranch.sqlite3'
    app.config['DB_PATH'] = db_path
    with database(db_path) as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS media(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, filename TEXT NOT NULL UNIQUE,
          kind TEXT NOT NULL, size INTEGER NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts(ip TEXT PRIMARY KEY, count INTEGER, since REAL);
        CREATE TABLE IF NOT EXISTS devices(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, token_hash TEXT,
          pairing_hash TEXT, pairing_token TEXT, pairing_expires REAL,
          source TEXT NOT NULL DEFAULT 'menu', revision INTEGER NOT NULL DEFAULT 1,
          last_seen REAL NOT NULL DEFAULT 0, report_source TEXT, report_status TEXT);
        ''')
        if 'sha256' not in {row['name'] for row in db.execute('PRAGMA table_info(media)')}:
            db.execute('ALTER TABLE media ADD COLUMN sha256 TEXT')
        if 'certificate_sha256' not in {row['name'] for row in db.execute('PRAGMA table_info(devices)')}:
            db.execute('ALTER TABLE devices ADD COLUMN certificate_sha256 TEXT')
        if get_setting(db, 'password') is None:
            set_setting(db, 'password', generate_password_hash('pranch'))
            set_setting(db, 'registered', False)
            set_setting(db, 'generation', 1)
            set_setting(db, 'source', 'menu')
            set_setting(db, 'playlist', [])
            set_setting(db, 'seconds', 10)
            set_setting(db, 'muted', True)
            set_setting(db, 'revision', 1)
        migrate_accounts(db)
    os.chmod(db_path, 0o600)
    upload_lock = threading.Lock()
    report_lock = threading.Lock()
    report = {}
    recovery_lock = threading.RLock()
    recovery = {}
    certificate = Path(app.config['TLS_SERVER_CERT'])
    if certificate.exists():
        fleet_certificate = hashlib.sha256(ssl.PEM_cert_to_DER_cert(
            certificate.read_text())).hexdigest()
    else:
        fleet_certificate = app.config.get('FLEET_CERT_SHA256', '0' * 64)

    def require_local_recovery():
        if (request.remote_addr not in {'127.0.0.1', '::1'} or
                request.headers.get('X-Ranch-Local-Entry') != '1'):
            abort(403, 'Password recovery requires the Pi’s local HTTPS address on the same Ethernet/Wi-Fi network. Disconnect remote VPN access for this step.')
        interface = matching_lan(request.headers.get('X-Real-IP', ''), lan_interfaces())
        if interface is None:
            abort(403, 'Connect to the same local subnet as the Pi and use its local HTTPS address to reset the password.')
        return interface

    def recovery_active():
        with recovery_lock:
            if not recovery or recovery['expires'] <= time.time():
                recovery.clear()
                return False
            with database(db_path) as db:
                valid = recovery['generation'] == get_setting(db, 'generation')
            if not valid:
                recovery.clear()
            return valid

    def session_user(db):
        identifier = session.get('user_id')
        if not identifier:
            return None
        user = db.execute('SELECT * FROM users WHERE id=?', (identifier,)).fetchone()
        if (not user or not user['active'] or
                session.get('generation') != user['generation']):
            return None
        return user

    def authenticated():
        with database(db_path) as db:
            return session_user(db) is not None

    def require_role(*roles):
        def decorate(function):
            @wraps(function)
            def wrapped(*args, **kwargs):
                with database(db_path) as db:
                    user = session_user(db)
                    if not user:
                        abort(401)
                    if user['role'] not in roles:
                        abort(403, 'Your account does not have permission for this action.')
                return function(*args, **kwargs)
            return wrapped
        return decorate

    def requested_location(db, user=None):
        user = user or session_user(db)
        identifier = request.args.get('location', DEFAULT_LOCATION_ID)
        if not can_access_location(db, user, identifier):
            abort(403, 'Your account does not have access to this location.')
        return identifier

    def location_source_url(db, location_id, source):
        if source == 'media':
            return SOURCES['media'][1]
        row = db.execute('SELECT menu_url,ads_url,funzone_url FROM locations WHERE id=?',
                         (location_id,)).fetchone()
        if not row:
            abort(404, 'Location not found.')
        return row[{'menu': 'menu_url', 'ads': 'ads_url', 'funzone': 'funzone_url'}[source]]

    def require_login(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if not authenticated():
                if request.path.startswith('/api/'):
                    abort(401)
                return redirect(url_for('login'))
            with database(db_path) as db:
                user = session_user(db)
                must_change = bool(user['must_change'])
            if must_change and request.endpoint not in {'password', 'logout'}:
                if request.path.startswith('/api/'):
                    abort(403, 'Change the initial password first.')
                return redirect(url_for('password'))
            return function(*args, **kwargs)
        return wrapped

    def is_device_request():
        # Reverse proxies must deny /device/. Also reject forwarded requests here.
        return (request.remote_addr in {'127.0.0.1', '::1'} and
                request.host.split(':')[0] in {'127.0.0.1', 'localhost'} and
                not any(h in request.headers for h in
                        ['X-Forwarded-For', 'Forwarded', 'X-Real-IP', 'Tailscale-User-Login']))

    def device_only(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if not is_device_request():
                abort(403)
            return function(*args, **kwargs)
        return wrapped

    def csrf_token():
        if 'csrf' not in session:
            session['csrf'] = secrets.token_urlsafe(32)
        return session['csrf']

    app.jinja_env.globals['csrf_token'] = csrf_token

    @app.before_request
    def protect_request():
        # Reject arbitrary DNS names to prevent DNS rebinding onto local endpoints.
        host = request.host.split(':')[0].lower()
        allowed = {socket.gethostname().lower(), socket.gethostname().lower() + '.local',
                   'localhost', 'pizza-ranch.local'}
        try:
            valid_ip = ipaddress.ip_address(host).is_private
        except ValueError:
            valid_ip = False
        if host not in allowed and not valid_ip and not host.endswith('.ts.net'):
            abort(400, 'Unrecognized management hostname.')
        if request.path.startswith('/fleet/'):
            require_local_recovery()
            if request.method == 'POST':
                return
        if request.path.startswith('/api/') and not authenticated():
            # Reject unauthenticated uploads before Flask parses multipart data.
            abort(401)
        if request.method in {'POST', 'PUT', 'PATCH', 'DELETE'}:
            if request.endpoint == 'device_heartbeat' and is_device_request():
                if secrets.compare_digest(request.headers.get('X-Device-Token', ''), device_token):
                    return
                abort(403)
            expected = session.get('csrf', '')
            supplied = request.headers.get('X-CSRF-Token', '') or request.form.get('csrf_token', '')
            if not expected or not secrets.compare_digest(expected, supplied):
                abort(403, 'Your session expired. Refresh the page and try again.')

    @app.after_request
    def security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; "
            "frame-ancestors 'none'; form-action 'self'")
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        if request.path.startswith('/api/') or request.path.startswith('/device/'):
            return jsonify(error=error.description), error.code
        return render_template('error.html', message=error.description), error.code

    @app.get('/service-worker.js')
    def service_worker():
        response = send_file(Path(app.root_path) / 'static' / 'service-worker.js',
                             mimetype='application/javascript')
        response.headers['Service-Worker-Allowed'] = '/'
        return response

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            # Only the local reverse proxy supplies this; backend is loopback-only.
            ip = request.headers.get('X-Real-IP', request.remote_addr)[:100]
            now = time.time()
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('DELETE FROM attempts WHERE since < ?', (now - 900,))
                row = db.execute('SELECT * FROM attempts WHERE ip=?', (ip,)).fetchone()
                if row and row['count'] >= 5:
                    abort(429, 'Too many attempts. Try again in 15 minutes.')
                user = db.execute('SELECT * FROM users WHERE username=? COLLATE NOCASE',
                                  (request.form.get('username', '').strip(),)).fetchone()
                good = bool(user and user['active'] and
                            check_password_hash(user['password_hash'], request.form.get('password', '')))
                if good:
                    db.execute('DELETE FROM attempts WHERE ip=?', (ip,))
                else:
                    db.execute('INSERT INTO attempts(ip,count,since) VALUES(?,1,?) '
                               'ON CONFLICT(ip) DO UPDATE SET count=count+1', (ip, now))
            if good:
                session.clear()
                session.update(user_id=user['id'], user=user['username'], role=user['role'],
                               generation=user['generation'])
                session.permanent = True
                return redirect(url_for('password' if user['must_change'] else 'dashboard'))
            flash('Username or password is incorrect.', 'error')
        return render_template('login.html')

    @app.route('/recover', methods=['GET', 'POST'])
    def recover():
        interface = require_local_recovery()
        if request.method == 'POST':
            with recovery_lock:
                if not recovery_active():
                    with database(db_path) as db:
                        db.execute('BEGIN IMMEDIATE')
                        now = time.time()
                        if now - get_setting(db, 'reset_requested_at', 0) < 600:
                            abort(429, 'A reset was recently requested. Requests are limited to one every 10 minutes.')
                        generation = get_setting(db, 'generation')
                        set_setting(db, 'reset_requested_at', now)
                    recovery.update(token=secrets.token_urlsafe(32), expires=now + 300,
                                    generation=generation, address=str(interface.ip))
            return redirect(url_for('recover_wait'))
        return render_template('recover.html')

    @app.get('/recover/wait')
    def recover_wait():
        require_local_recovery()
        return render_template('recover_wait.html', active=recovery_active())

    @app.route('/recover/scan', methods=['GET', 'POST'])
    def recover_scan():
        require_local_recovery()
        if request.method == 'GET':
            return render_template('recover_scan.html', token='')
        token = request.form.get('reset_token', '')
        new = request.form.get('new_password', '')
        with recovery_lock:
            if not recovery_active() or not secrets.compare_digest(token, recovery['token']):
                abort(400, 'The reset QR is invalid, expired, or already used. Request a new one from the login page.')
            if not 12 <= len(new) <= 128 or new != request.form.get('confirm_password'):
                flash('Use 12–128 characters and make both new password fields match.', 'error')
                return render_template('recover_scan.html', token=token)
            password_hash = generate_password_hash(new)
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                if (recovery['expires'] <= time.time() or
                        recovery['generation'] != get_setting(db, 'generation')):
                    abort(400, 'This reset has expired. Request another QR code.')
                set_setting(db, 'password', password_hash)
                set_setting(db, 'registered', True)
                set_setting(db, 'generation', get_setting(db, 'generation') + 1)
                set_setting(db, 'revision', get_setting(db, 'revision') + 1)
                db.execute('''UPDATE users SET password_hash=?,must_change=0,generation=generation+1
                              WHERE username='admin' COLLATE NOCASE''', (password_hash,))
                db.execute('DELETE FROM attempts')
            recovery.clear()
        session.clear()
        flash('Admin password reset. Sign in with your new password.', 'success')
        return redirect(url_for('login'))

    @app.route('/password', methods=['GET', 'POST'])
    @require_login
    def password():
        with database(db_path) as db:
            user = session_user(db)
            first = bool(user['must_change'])
        if request.method == 'POST':
            new = request.form.get('new_password', '')
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                user = session_user(db)
                if not check_password_hash(user['password_hash'], request.form.get('current_password', '')):
                    flash('Current password is incorrect.', 'error')
                elif len(new) < 12 or len(new) > 128 or new != request.form.get('confirm_password'):
                    flash('Use 12–128 characters and make both new password fields match.', 'error')
                elif check_password_hash(user['password_hash'], new):
                    flash('Choose a different password.', 'error')
                else:
                    password_hash = generate_password_hash(new)
                    generation = user['generation'] + 1
                    db.execute('''UPDATE users SET password_hash=?,must_change=0,generation=? WHERE id=?''',
                               (password_hash, generation, user['id']))
                    if user['username'].lower() == 'admin':
                        set_setting(db, 'password', password_hash)
                        set_setting(db, 'registered', True)
                        set_setting(db, 'generation', generation)
                        set_setting(db, 'revision', get_setting(db, 'revision') + 1)
                    session.clear()
                    session.update(user_id=user['id'], user=user['username'], role=user['role'],
                                   generation=generation)
                    session.permanent = True
                    flash('Password saved. Setup is complete.', 'success')
                    return redirect(url_for('dashboard'))
        return render_template('password.html', first=first)

    @app.post('/logout')
    @require_login
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @require_login
    def dashboard():
        with database(db_path) as db:
            user = session_user(db)
            locations = locations_for_user(db, user)
        if not locations:
            abort(403, 'Your account is not assigned to a location. Ask an administrator for access.')
        return render_template('dashboard.html', sources=SOURCES, locations=locations,
                               can_admin=user['role'] in {'system_admin', 'location_manager'})

    @app.get('/administration')
    @require_login
    @require_role('system_admin', 'location_manager')
    def administration():
        return render_template('administration.html')

    def visible_users(db, actor):
        rows = list(db.execute('SELECT * FROM users ORDER BY username COLLATE NOCASE'))
        allowed = set(user_locations(db, actor['id']))
        output = []
        for row in rows:
            assigned = user_locations(db, row['id'])
            if actor['role'] != 'system_admin':
                if row['role'] != 'operator' or not (allowed & set(assigned)):
                    continue
            item = {key: row[key] for key in ('id', 'username', 'display_name', 'role',
                                               'active', 'must_change', 'created')}
            item['location_ids'] = assigned
            output.append(item)
        return output

    def manageable_locations(db, actor, requested_ids):
        if not isinstance(requested_ids, list) or not requested_ids or len(requested_ids) > 100:
            abort(400, 'Assign at least one valid location.')
        identifiers = set(requested_ids)
        existing = {row['id'] for row in db.execute('SELECT id FROM locations')}
        if not identifiers <= existing:
            abort(400, 'One of the selected locations no longer exists.')
        if actor['role'] != 'system_admin' and not identifiers <= set(user_locations(db, actor['id'])):
            abort(403, 'You can assign only locations you manage.')
        return sorted(identifiers)

    @app.get('/api/administration')
    @require_login
    @require_role('system_admin', 'location_manager')
    def administration_state():
        with database(db_path) as db:
            actor = session_user(db)
            locations = locations_for_user(db, actor)
            users = visible_users(db, actor)
        return jsonify(locations=locations, users=users, role=actor['role'],
                       current_user_id=actor['id'], default_location=DEFAULT_LOCATION_ID)

    @app.post('/api/locations')
    @require_login
    @require_role('system_admin')
    def create_location():
        body = json_object()
        try:
            name, urls = validate_location(body.get('name'), body)
        except ValueError as error:
            abort(400, str(error))
        identifier = 'loc-' + secrets.token_hex(8)
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT 1 FROM locations WHERE name=? COLLATE NOCASE', (name,)).fetchone():
                abort(409, 'A location with that name already exists.')
            db.execute('''INSERT INTO locations(id,name,menu_url,ads_url,funzone_url,created)
                          VALUES(?,?,?,?,?,?)''',
                       (identifier, name, urls['menu_url'], urls['ads_url'], urls['funzone_url'],
                        time.time()))
            db.execute('INSERT INTO location_settings(location_id) VALUES(?)', (identifier,))
        return jsonify(id=identifier, name=name), 201

    @app.patch('/api/locations/<identifier>')
    @require_login
    @require_role('system_admin')
    def update_location(identifier):
        body = json_object()
        try:
            name, urls = validate_location(body.get('name'), body)
        except ValueError as error:
            abort(400, str(error))
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            duplicate = db.execute('SELECT id FROM locations WHERE name=? COLLATE NOCASE AND id<>?',
                                   (name, identifier)).fetchone()
            if duplicate:
                abort(409, 'A location with that name already exists.')
            changed = db.execute('''UPDATE locations SET name=?,menu_url=?,ads_url=?,funzone_url=?
                                    WHERE id=?''',
                                 (name, urls['menu_url'], urls['ads_url'], urls['funzone_url'], identifier))
            if not changed.rowcount:
                abort(404, 'Location not found.')
            current = location_state(db, identifier)
            save_location_state(db, identifier, revision=current['revision'] + 1)
            db.execute('UPDATE devices SET revision=revision+1 WHERE location_id=?', (identifier,))
        return jsonify(ok=True)

    @app.delete('/api/locations/<identifier>')
    @require_login
    @require_role('system_admin')
    def delete_location(identifier):
        if identifier == DEFAULT_LOCATION_ID:
            abort(409, 'Tyler is the default location and cannot be removed.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            counts = [db.execute(f'SELECT 1 FROM {table} WHERE location_id=? LIMIT 1',
                                 (identifier,)).fetchone()
                      for table in ('devices', 'media', 'user_locations')]
            if any(counts):
                abort(409, 'Remove this location’s users, media, and displays before deleting it.')
            if not db.execute('DELETE FROM locations WHERE id=?', (identifier,)).rowcount:
                abort(404, 'Location not found.')
        return jsonify(ok=True)

    @app.post('/api/users')
    @require_login
    @require_role('system_admin', 'location_manager')
    def create_user():
        body = json_object()
        try:
            username = validate_username(body.get('username'))
        except ValueError as error:
            abort(400, str(error))
        display_name = ' '.join(str(body.get('display_name', '')).split())
        password = str(body.get('password', ''))
        role = body.get('role')
        if not 2 <= len(display_name) <= 80:
            abort(400, 'Display names must contain 2–80 characters.')
        if not 12 <= len(password) <= 128:
            abort(400, 'Temporary passwords must contain 12–128 characters.')
        if role not in ROLES:
            abort(400, 'Choose a valid account role.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            actor = session_user(db)
            if actor['role'] != 'system_admin' and role != 'operator':
                abort(403, 'Location managers can create operator accounts only.')
            assigned = [] if role == 'system_admin' else manageable_locations(
                db, actor, body.get('location_ids'))
            identifier = secrets.token_hex(16)
            if db.execute('SELECT 1 FROM users WHERE username=? COLLATE NOCASE', (username,)).fetchone():
                abort(409, 'That username already exists.')
            db.execute('''INSERT INTO users(id,username,display_name,password_hash,role,active,must_change,generation,created)
                          VALUES(?,?,?,?,?,1,1,1,?)''',
                       (identifier, username, display_name, generate_password_hash(password), role, time.time()))
            db.executemany('INSERT INTO user_locations(user_id,location_id) VALUES(?,?)',
                           [(identifier, location_id) for location_id in assigned])
        return jsonify(id=identifier, username=username), 201

    @app.patch('/api/users/<identifier>')
    @require_login
    @require_role('system_admin', 'location_manager')
    def update_user(identifier):
        body = json_object()
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            actor = session_user(db)
            target = db.execute('SELECT * FROM users WHERE id=?', (identifier,)).fetchone()
            if not target:
                abort(404, 'User not found.')
            if actor['role'] != 'system_admin' and target['role'] != 'operator':
                abort(403, 'Location managers can manage operator accounts only.')
            role = body.get('role', target['role'])
            if role not in ROLES or (actor['role'] != 'system_admin' and role != 'operator'):
                abort(403, 'You cannot assign that role.')
            if actor['role'] != 'system_admin':
                current_assignments = set(user_locations(db, target['id']))
                if not current_assignments <= set(user_locations(db, actor['id'])):
                    abort(403, 'You cannot change an account assigned outside your locations.')
            assigned = [] if role == 'system_admin' else manageable_locations(
                db, actor, body.get('location_ids'))
            display_name = ' '.join(str(body.get('display_name', target['display_name'])).split())
            if not 2 <= len(display_name) <= 80:
                abort(400, 'Display names must contain 2–80 characters.')
            active = bool(body.get('active', target['active']))
            if identifier == actor['id'] and not active:
                abort(409, 'You cannot disable your own account.')
            if target['role'] == 'system_admin' and (role != 'system_admin' or not active):
                others = db.execute("SELECT COUNT(*) AS count FROM users WHERE role='system_admin' AND active=1 AND id<>?",
                                    (identifier,)).fetchone()['count']
                if not others:
                    abort(409, 'At least one active system administrator is required.')
            password = str(body.get('password', ''))
            if password and not 12 <= len(password) <= 128:
                abort(400, 'Temporary passwords must contain 12–128 characters.')
            generation = target['generation'] + (1 if password or not active or role != target['role'] else 0)
            password_hash = generate_password_hash(password) if password else target['password_hash']
            db.execute('''UPDATE users SET display_name=?,role=?,active=?,password_hash=?,
                          must_change=?,generation=? WHERE id=?''',
                       (display_name, role, int(active), password_hash,
                        int(bool(password) or target['must_change']), generation, identifier))
            if target['username'].lower() == 'admin' and password:
                set_setting(db, 'password', password_hash)
                set_setting(db, 'generation', generation)
            db.execute('DELETE FROM user_locations WHERE user_id=?', (identifier,))
            db.executemany('INSERT INTO user_locations(user_id,location_id) VALUES(?,?)',
                           [(identifier, location_id) for location_id in assigned])
        return jsonify(ok=True)

    @app.delete('/api/users/<identifier>')
    @require_login
    @require_role('system_admin', 'location_manager')
    def delete_user(identifier):
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            actor = session_user(db)
            target = db.execute('SELECT * FROM users WHERE id=?', (identifier,)).fetchone()
            if not target:
                abort(404, 'User not found.')
            if target['id'] == actor['id']:
                abort(409, 'You cannot delete your own account.')
            if actor['role'] != 'system_admin':
                assigned = set(user_locations(db, target['id']))
                allowed = set(user_locations(db, actor['id']))
                if target['role'] != 'operator' or not assigned or not assigned <= allowed:
                    abort(403, 'You cannot delete this account.')
            if target['role'] == 'system_admin':
                abort(409, 'System administrators must be demoted before deletion.')
            db.execute('DELETE FROM users WHERE id=?', (identifier,))
        return jsonify(ok=True)

    def snapshot(location_id=DEFAULT_LOCATION_ID, user=None):
        with database(db_path) as db:
            settings = location_state(db, location_id)
            if settings is None:
                abort(404, 'Location not found.')
            location = db.execute('SELECT * FROM locations WHERE id=?', (location_id,)).fetchone()
            state = dict(settings)
            state['registered'] = get_setting(db, 'registered')
            state['location'] = dict(location)
            state['main_display'] = location_id == DEFAULT_LOCATION_ID
            state['library'] = [dict(r) for r in db.execute(
                'SELECT * FROM media WHERE location_id=? ORDER BY created', (location_id,))]
            state['devices'] = [dict(row) for row in db.execute(
                '''SELECT id,name,token_hash IS NOT NULL AS paired,source,revision,last_seen,
                   report_source,report_status,certificate_sha256,location_id FROM devices
                   WHERE location_id=? OR token_hash IS NULL ORDER BY name,id''', (location_id,))]
            if user:
                state['permissions'] = {'role': user['role'],
                    'manage_accounts': user['role'] in {'system_admin', 'location_manager'},
                    'system_admin': user['role'] == 'system_admin'}
                state['available_locations'] = [
                    {'id': item['id'], 'name': item['name']} for item in locations_for_user(db, user)]
        state['free_bytes'] = shutil.disk_usage(media).free
        with report_lock:
            state['display'] = dict(report) if location_id == DEFAULT_LOCATION_ID else {}
        state['display']['online'] = time.time() - state['display'].get('at', 0) < 20
        maintenance = Path('/var/lib/pizza-ranch-maintenance/status.json')
        try:
            state['maintenance'] = json.loads(maintenance.read_text())
        except (OSError, ValueError):
            state['maintenance'] = {'status': 'No scheduled update has run yet.'}
        try:
            state['app_updates'] = json.loads(Path('/var/lib/pizza-ranch-maintenance/app-status.json').read_text())
        except (OSError, ValueError):
            state['app_updates'] = {'status': 'No GitHub update check has run yet.'}
        state['app_updates'].update(update_state())
        state['reboot_required'] = Path('/var/run/reboot-required').exists()
        for device in state['devices']:
            device['online'] = time.time() - device['last_seen'] < 25
        return state

    def json_object():
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            abort(400, 'Expected a JSON object.')
        return body

    @app.get('/api/state')
    @require_login
    def state():
        with database(db_path) as db:
            user = session_user(db)
            location_id = requested_location(db, user)
        return jsonify(snapshot(location_id, user))

    @app.post('/api/display')
    @require_login
    def change_display():
        body = json_object()
        source = body.get('source')
        if not isinstance(source, str) or source not in SOURCES:
            abort(400, 'Choose one of the four display sources.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            current = location_state(db, location_id)
            if source == 'media' and not current['playlist']:
                abort(400, 'Add media to your playlist first.')
            save_location_state(db, location_id, source=source, revision=current['revision'] + 1)
        return jsonify(ok=True)

    @app.post('/api/reload')
    @require_login
    def reload_display():
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            current = location_state(db, location_id)
            save_location_state(db, location_id, revision=current['revision'] + 1)
        return jsonify(ok=True)

    @app.post('/api/app-update')
    @require_login
    @require_role('system_admin')
    def app_update():
        update = update_state()
        if not update['available']:
            abort(503, 'Manual updates are unavailable. Install this release on the Pi once to enable them.')
        if update['busy']:
            return jsonify(ok=True, busy=True), 202
        try:
            request_update()
        except OSError:
            abort(503, 'The Pi could not queue the update check. Rerun the installer to repair permissions.')
        return jsonify(ok=True, busy=True), 202

    @app.post('/api/devices/<identifier>/pair')
    @require_login
    def pair_device(identifier):
        body = json_object()
        code = str(body.get('code', '')).strip()
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            row = db.execute('SELECT pairing_hash,pairing_expires,certificate_sha256 FROM devices WHERE id=?', (identifier,)).fetchone()
            if not row or not row['pairing_hash'] or row['pairing_expires'] < time.time():
                abort(404, 'This display is no longer waiting for pairing. Restart it and try again.')
            if not check_password_hash(row['pairing_hash'], code):
                abort(403, 'The pairing code does not match the code on that TV.')
            if not secrets.compare_digest(row['certificate_sha256'] or '', fleet_certificate):
                abort(409, 'This display did not see the server’s expected certificate. Check the network and restart pairing.')
            token = secrets.token_urlsafe(32)
            db.execute('UPDATE devices SET token_hash=?,pairing_token=?,location_id=? WHERE id=?',
                       (hashlib.sha256(token.encode()).hexdigest(), token, location_id, identifier))
        return jsonify(ok=True)

    @app.post('/api/devices/<identifier>/display')
    @require_login
    def change_remote_display(identifier):
        body = json_object()
        source = body.get('source')
        if source not in SOURCES:
            abort(400, 'Choose a valid content source.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            current = location_state(db, location_id)
            row = db.execute('SELECT location_id FROM devices WHERE id=?', (identifier,)).fetchone()
            if not row or row['location_id'] != location_id:
                abort(404, 'Display not found at this location.')
            if source == 'media' and not current['playlist']:
                abort(400, 'Add media to the playlist first.')
            changed = db.execute(
                'UPDATE devices SET source=?,revision=revision+1 WHERE id=? AND token_hash IS NOT NULL',
                (source, identifier))
            if not changed.rowcount:
                abort(404, 'Pair this display first.')
        return jsonify(ok=True)

    @app.patch('/api/devices/<identifier>/location')
    @require_login
    @require_role('system_admin', 'location_manager')
    def move_remote_display(identifier):
        body = json_object()
        destination = str(body.get('location_id', ''))
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            user = session_user(db)
            source = requested_location(db, user)
            if not can_access_location(db, user, destination):
                abort(403, 'You cannot move a display to that location.')
            changed = db.execute('''UPDATE devices SET location_id=?,source='menu',revision=revision+1
                                    WHERE id=? AND location_id=? AND token_hash IS NOT NULL''',
                                 (destination, identifier, source))
            if not changed.rowcount:
                abort(404, 'Paired display not found at this location.')
        return jsonify(ok=True)

    @app.delete('/api/devices/<identifier>')
    @require_login
    def forget_device(identifier):
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            if not db.execute('DELETE FROM devices WHERE id=? AND location_id=?',
                              (identifier, location_id)).rowcount:
                abort(404)
        return jsonify(ok=True)

    def fleet_body():
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            abort(400)
        identifier = str(body.get('id', ''))
        if len(identifier) != 32 or any(c not in '0123456789abcdef' for c in identifier):
            abort(400)
        return body, identifier

    def fleet_auth(db, identifier, supplied):
        row = db.execute('SELECT token_hash FROM devices WHERE id=?', (identifier,)).fetchone()
        digest = hashlib.sha256(supplied.encode()).hexdigest()
        if not row or not row['token_hash'] or not secrets.compare_digest(row['token_hash'], digest):
            abort(403)
        return row

    @app.post('/fleet/hello')
    def fleet_hello():
        body, identifier = fleet_body()
        name = ''.join(c for c in str(body.get('name', 'Display')) if c.isprintable())[:60] or 'Display'
        code = str(body.get('code', ''))
        observed_certificate = str(body.get('certificate', '')).lower()
        if len(code) != 6 or not code.isdigit():
            abort(400)
        if len(observed_certificate) != 64 or any(c not in '0123456789abcdef' for c in observed_certificate):
            abort(400)
        now = time.time()
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('''SELECT token_hash,pairing_token,pairing_hash,pairing_expires,
                                certificate_sha256 FROM devices WHERE id=?''', (identifier,)).fetchone()
            if row is None:
                db.execute('''INSERT INTO devices(id,name,pairing_hash,pairing_expires,last_seen,certificate_sha256)
                              VALUES(?,?,?,?,?,?)''',
                           (identifier, name, generate_password_hash(code), now + 900, now,
                            observed_certificate))
                return jsonify(status='pending')
            if row['pairing_token'] and row['pairing_hash'] and \
                    check_password_hash(row['pairing_hash'], code) and \
                    secrets.compare_digest(row['certificate_sha256'] or '', observed_certificate):
                token = row['pairing_token']
                db.execute('''UPDATE devices SET pairing_token=NULL,pairing_hash=NULL,
                              pairing_expires=NULL,last_seen=? WHERE id=?''', (now, identifier))
                ca = Path(app.config['TLS_CA_CERT'])
                if not ca.is_file():
                    abort(503, 'The server local certificate authority is missing.')
                return jsonify(status='paired', token=token, ca=ca.read_text())
            if row['token_hash']:
                return jsonify(status='paired')
            db.execute('UPDATE devices SET name=?,last_seen=?,certificate_sha256=? WHERE id=?',
                       (name, now, observed_certificate, identifier))
            if (not row['token_hash'] and (not row['pairing_hash'] or
                    row['pairing_expires'] < now or not check_password_hash(row['pairing_hash'], code))):
                db.execute('UPDATE devices SET pairing_hash=?,pairing_expires=? WHERE id=?',
                           (generate_password_hash(code), now + 900, identifier))
                return jsonify(status='pending')
            return jsonify(status='pending')

    @app.post('/fleet/state')
    def fleet_state():
        body, identifier = fleet_body()
        supplied = request.headers.get('X-Display-Token', '')
        with database(db_path) as db:
            fleet_auth(db, identifier, supplied)
            db.execute('''UPDATE devices SET last_seen=?,report_source=?,report_status=? WHERE id=?''',
                       (time.time(), str(body.get('source', ''))[:30],
                        str(body.get('status', ''))[:300], identifier))
            device = db.execute('SELECT source,revision,location_id FROM devices WHERE id=?', (identifier,)).fetchone()
            settings = location_state(db, device['location_id'])
            playlist = settings['playlist']
            seconds, muted = settings['seconds'], settings['muted']
            rows = {r['id']: dict(r) for r in db.execute(
                'SELECT * FROM media WHERE location_id=?', (device['location_id'],))}
            for row in rows.values():
                if not row.get('sha256'):
                    file = media / row['filename']
                    row['sha256'] = file_sha256(file)
                    db.execute('UPDATE media SET sha256=? WHERE id=?', (row['sha256'], row['id']))
            source = device['source']
            url = location_source_url(db, device['location_id'], source)
        items = []
        for media_id in playlist:
            if media_id not in rows:
                continue
            row = rows[media_id]
            items.append(dict(id=media_id, kind=row['kind'], size=row['size'], sha256=row['sha256']))
        return jsonify(source=source, url=url, revision=device['revision'], playlist=items,
                       seconds=seconds, muted=muted)

    @app.get('/fleet/media/<identifier>')
    def fleet_media(identifier):
        node_id = request.headers.get('X-Display-ID', '')
        with database(db_path) as db:
            fleet_auth(db, node_id, request.headers.get('X-Display-Token', ''))
            device = db.execute('SELECT location_id FROM devices WHERE id=?', (node_id,)).fetchone()
            item = db.execute('SELECT location_id FROM media WHERE id=?', (identifier,)).fetchone()
            if not item or item['location_id'] != device['location_id']:
                abort(404)
        return serve_media(identifier)

    @app.post('/api/playlist')
    @require_login
    def playlist():
        body = json_object()
        ids, seconds, muted = body.get('ids'), body.get('seconds'), body.get('muted')
        if (not isinstance(ids, list) or len(ids) > 500 or
                not all(isinstance(i, str) for i in ids) or len(set(ids)) != len(ids) or
                type(seconds) is not int or not 3 <= seconds <= 300 or type(muted) is not bool):
            abort(400, 'Invalid playlist. Use 3–300 seconds per image and unique media entries.')
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            current = location_state(db, location_id)
            valid = {r['id'] for r in db.execute('SELECT id FROM media WHERE location_id=?',
                                                 (location_id,))}
            if not set(ids) <= valid:
                abort(400, 'A playlist file no longer exists. Refresh the library.')
            remote_media = db.execute("SELECT 1 FROM devices WHERE location_id=? AND source='media' AND token_hash IS NOT NULL LIMIT 1",
                                      (location_id,)).fetchone()
            if not ids and (current['source'] == 'media' or remote_media):
                abort(400, 'Switch to a website before clearing the active playlist.')
            save_location_state(db, location_id, playlist=ids, seconds=seconds, muted=muted,
                                revision=current['revision'] + 1)
            db.execute("UPDATE devices SET revision=revision+1 WHERE location_id=? AND source='media'",
                       (location_id,))
        return jsonify(ok=True)

    @app.post('/api/upload')
    @require_login
    def upload():
        if 'file' not in request.files:
            abort(400, 'Choose a file.')
        if not upload_lock.acquire(blocking=False):
            abort(409, 'Another upload is processing. Try again shortly.')
        item = None
        try:
            item = ingest(request.files['file'], media, app.config['UPLOAD_LIMIT'], app.config['RESERVE_BYTES'])
            with database(db_path) as db:
                db.execute('BEGIN IMMEDIATE')
                location_id = requested_location(db)
                db.execute('''INSERT INTO media(id,name,filename,kind,size,created,sha256,location_id)
                              VALUES(?,?,?,?,?,?,?,?)''',
                           (item['id'], item['name'], item['filename'], item['kind'],
                            item['size'], time.time(), item['sha256'], location_id))
                item['added_to_playlist'] = request.form.get('add_to_playlist') == 'true'
                if item['added_to_playlist']:
                    current = location_state(db, location_id)
                    playlist = current['playlist']
                    if len(playlist) >= 500:
                        abort(400, 'The playlist is full. Remove an entry or turn off automatic playlist addition.')
                    save_location_state(db, location_id, playlist=playlist + [item['id']],
                                        revision=current['revision'] + 1)
                    db.execute("UPDATE devices SET revision=revision+1 WHERE location_id=? AND source='media'",
                               (location_id,))
            return jsonify(item), 201
        except MediaError as error:
            app.logger.warning('Media upload rejected: %s', error)
            abort(400, str(error))
        except Exception:
            if item:
                (media / item['filename']).unlink(missing_ok=True)
            raise
        finally:
            upload_lock.release()

    @app.delete('/api/media/<identifier>')
    @require_login
    def delete_media(identifier):
        with database(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            location_id = requested_location(db)
            current = location_state(db, location_id)
            if identifier in current['playlist']:
                abort(409, 'Remove this file from the playlist and save before deleting it.')
            row = db.execute('SELECT filename FROM media WHERE id=? AND location_id=?',
                             (identifier, location_id)).fetchone()
            if not row:
                abort(404)
            (media / row['filename']).unlink(missing_ok=True)
            db.execute('DELETE FROM media WHERE id=?', (identifier,))
        return jsonify(ok=True)

    def serve_media(identifier):
        with database(db_path) as db:
            row = db.execute('SELECT filename,kind FROM media WHERE id=?', (identifier,)).fetchone()
        if not row:
            abort(404)
        # Only database-owned UUID filenames; never a user-supplied path or MIME type.
        return send_file(media / row['filename'], conditional=True,
                         mimetype='video/mp4' if row['kind'] == 'video' else 'image/jpeg')

    @app.get('/media/<identifier>')
    @require_login
    def protected_media(identifier):
        with database(db_path) as db:
            location_id = requested_location(db)
            row = db.execute('SELECT location_id FROM media WHERE id=?', (identifier,)).fetchone()
            if not row or row['location_id'] != location_id:
                abort(404)
        return serve_media(identifier)

    @app.get('/device/media/<identifier>')
    @device_only
    def device_media(identifier):
        with database(db_path) as db:
            row = db.execute('SELECT location_id FROM media WHERE id=?', (identifier,)).fetchone()
            if not row or row['location_id'] != DEFAULT_LOCATION_ID:
                abort(404)
        return serve_media(identifier)

    @app.get('/device/state')
    @device_only
    def device_state():
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), device_token):
            abort(403)
        result = snapshot(DEFAULT_LOCATION_ID)
        with database(db_path) as db:
            result['url'] = (location_source_url(db, DEFAULT_LOCATION_ID, result['source'])
                             if result['registered'] else 'http://127.0.0.1:8080/device/setup')
        result['recovery'] = recovery_active()
        if result['recovery']:
            result['url'] = 'http://127.0.0.1:8080/device/recovery'
        return jsonify(result)

    @app.get('/device/recovery')
    @device_only
    def recovery_screen():
        if not recovery_active():
            with database(db_path) as db:
                destination = (location_source_url(db, DEFAULT_LOCATION_ID,
                                                   location_state(db, DEFAULT_LOCATION_ID)['source'])
                               if get_setting(db, 'registered') else '/device/setup')
            return redirect(destination)
        return render_template('recovery_screen.html')

    @app.get('/device/recovery-qr.png')
    @device_only
    def recovery_qr():
        with recovery_lock:
            if not recovery_active():
                abort(404)
            # Fragment is read by the phone locally; it is never in HTTP access
            # logs, controller URLs, or the requesting browser's response.
            address = f"https://{socket.gethostname()}.local:8443/recover/scan#{recovery['token']}"
            output = io.BytesIO()
            qrcode.make(address).save(output, format='PNG')
        output.seek(0)
        return send_file(output, mimetype='image/png')

    @app.post('/device/heartbeat')
    @device_only
    def device_heartbeat():
        body = json_object()
        with report_lock:
            report.update(at=time.time(), source=str(body.get('source', ''))[:30],
                          status=str(body.get('status', ''))[:300], revision=body.get('revision'))
        return jsonify(ok=True)

    def setup_url():
        configured = app.config['PUBLIC_URL'].strip()
        if configured:
            return configured.rstrip('/') + '/login'
        # The stable mDNS name remains covered by the local certificate even if
        # DHCP later changes the Pi's address.
        host = socket.gethostname() + '.local'
        return f'https://{host}:8443/login'

    def trust_url():
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.connect(('192.0.2.1', 80))
                host = sock.getsockname()[0]
        except OSError:
            host = socket.gethostname() + '.local'
        return f'http://{host}:8083/trust'

    def ca_fingerprint():
        ca = Path(app.config['TLS_CA_CERT'])
        if not ca.is_file():
            return None
        fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(ca.read_text())).hexdigest().upper()
        return ':'.join(fingerprint[i:i + 2] for i in range(0, len(fingerprint), 2))

    @app.get('/trust')
    def trust_certificate():
        require_local_recovery()
        fingerprint = ca_fingerprint()
        if fingerprint is None:
            abort(503, 'The local certificate authority is not installed. Rerun the server installer.')
        return render_template('trust.html', fingerprint=fingerprint, management_url=setup_url())

    @app.get('/local-ca.crt')
    def local_ca():
        require_local_recovery()
        ca = Path(app.config['TLS_CA_CERT'])
        if not ca.is_file():
            abort(404)
        return send_file(ca, mimetype='application/x-x509-ca-cert', as_attachment=True,
                         download_name='pizza-ranch-local-ca.crt')

    @app.get('/device/setup')
    @device_only
    def setup():
        with database(db_path) as db:
            if get_setting(db, 'registered'):
                state = location_state(db, DEFAULT_LOCATION_ID)
                return redirect(location_source_url(db, DEFAULT_LOCATION_ID, state['source']))
        return render_template('setup.html', setup_url=trust_url(),
                               fingerprint=ca_fingerprint() or 'Unavailable until the server installer completes')

    @app.get('/device/qr.png')
    @device_only
    def qr():
        with database(db_path) as db:
            if get_setting(db, 'registered'):
                abort(404)
        output = io.BytesIO()
        qrcode.make(trust_url()).save(output, format='PNG')
        output.seek(0)
        return send_file(output, mimetype='image/png')

    @app.get('/device/player')
    @device_only
    def player():
        return render_template('player.html')

    @app.get('/device/offline')
    @device_only
    def offline():
        return render_template('offline.html')

    @app.get('/device/playlist')
    @device_only
    def device_playlist():
        state = snapshot(DEFAULT_LOCATION_ID)
        library = {i['id']: i for i in state['library']}
        return jsonify(items=[{'url': '/device/media/' + i, 'kind': library[i]['kind']}
                              for i in state['playlist'] if i in library],
                       seconds=state['seconds'], muted=state['muted'])

    return app


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reset-password', action='store_true', help='Local recovery; prompts for a new password.')
    args = parser.parse_args()
    app = create_app()
    if args.reset_password:
        import getpass
        password = getpass.getpass('New admin password (12–128 characters): ')
        if not 12 <= len(password) <= 128 or password != getpass.getpass('Repeat password: '):
            raise SystemExit('Passwords must match and contain 12–128 characters.')
        with database(app.config['DB_PATH']) as db:
            db.execute('BEGIN IMMEDIATE')
            set_setting(db, 'password', generate_password_hash(password))
            set_setting(db, 'registered', True)
            set_setting(db, 'generation', get_setting(db, 'generation') + 1)
            set_setting(db, 'revision', get_setting(db, 'revision') + 1)
            db.execute('''UPDATE users SET password_hash=?,must_change=0,generation=generation+1
                          WHERE username='admin' COLLATE NOCASE''',
                       (get_setting(db, 'password'),))
        print('Password changed. Existing sessions are invalid.')
        return
    from waitress import serve
    logging.basicConfig(level=logging.INFO)
    serve(app, host='127.0.0.1', port=8080, threads=4,
          max_request_body_size=app.config['MAX_CONTENT_LENGTH'], clear_untrusted_proxy_headers=False)


if __name__ == '__main__':
    main()
