'use strict';
const tokenField=document.getElementById('reset-token');
const fragment=location.hash.slice(1);
history.replaceState(null,'',location.pathname);
if(fragment)tokenField.value=fragment;
if(!tokenField.value){document.getElementById('reset-form').hidden=true;document.getElementById('reset-help').textContent='Scan the reset QR displayed on the TV to open this form.';}
