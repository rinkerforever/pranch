'use strict';
let installPrompt;
window.addEventListener('beforeinstallprompt',event=>{
  event.preventDefault();installPrompt=event;
  const button=document.getElementById('install-app');
  if(button)button.hidden=false;
});
window.addEventListener('DOMContentLoaded',()=>{
  const button=document.getElementById('install-app');
  if(button)button.onclick=async()=>{if(!installPrompt)return;await installPrompt.prompt();installPrompt=undefined;button.hidden=true;};
  const standalone=window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true;
  const ios=/iPhone|iPad|iPod/.test(navigator.userAgent);
  const help=document.getElementById('ios-install-help');
  if(help&&ios&&!standalone)help.hidden=false;
  if('serviceWorker' in navigator&&window.isSecureContext)navigator.serviceWorker.register('/service-worker.js').catch(()=>{});
});
