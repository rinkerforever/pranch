'use strict';
const $ = id => document.getElementById(id);
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const labels = {menu:'Menu',ads:'Ads',funzone:'Funzone Ads',media:'Uploaded Media',setup:'Setup',fallback:'Offline fallback',stopped:'Stopped',recovery:'Password reset QR'};
let state, order = [], dirty = false, initialized = false, uploading = false, refreshSequence = 0;
const locationSelect=$('location-select');
const requestedLocation=new URLSearchParams(location.search).get('location');
if(requestedLocation&&[...locationSelect.options].some(option=>option.value===requestedLocation))locationSelect.value=requestedLocation;
function scoped(path){const separator=path.includes('?')?'&':'?';return path+separator+'location='+encodeURIComponent(locationSelect.value);}
function notify(message) { $('notice').textContent = message; }
async function api(path, method='GET', body) {
  const response = await fetch(scoped(path), {method, headers:{'X-CSRF-Token':csrf,'Content-Type':'application/json'}, body:body === undefined ? undefined : JSON.stringify(body)});
  if (response.status === 401) { location.href='/login'; throw new Error('Please sign in again.'); }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
}
function button(text, handler, disabled=false) {
  const node=document.createElement('button');node.type='button';node.textContent=text;node.disabled=disabled;
  node.onclick=async()=>{node.disabled=true;try{await handler();}catch(error){notify(error.message);}finally{node.disabled=disabled;}};return node;
}
function changed() { dirty=true; $('playlist-state').textContent='Unsaved changes'; renderPlaylist(); renderLibrary(); }
function renderDevices(){
  const container=$('devices');container.replaceChildren();
  if(!state.devices.length){const p=document.createElement('p');p.className='muted';p.textContent='No other displays discovered yet.';container.append(p);return;}
  state.devices.forEach(device=>{
    const card=document.createElement('div');card.className='device-card';
    const title=document.createElement('h3');title.textContent=device.name;
    const status=document.createElement('p');status.className='muted';status.textContent=device.paired?(device.online?'Online · '+(labels[device.report_source]||labels[device.source]||'Starting'):'Offline · last assigned '+labels[device.source]):'Waiting for pairing';
    const actions=document.createElement('div');actions.className='actions';
    if(!device.paired){actions.append(button('Pair display',async()=>{const code=prompt('Enter the six-digit code shown on '+device.name);if(!code)return;await api('/api/devices/'+device.id+'/pair','POST',{code});notify('Display paired. It will connect automatically.');await refresh(true);}));}
    else{
      const select=document.createElement('select');Object.entries(labels).filter(([key])=>['menu','ads','funzone','media'].includes(key)).forEach(([key,label])=>{const option=document.createElement('option');option.value=key;option.textContent=label;option.selected=key===device.source;select.append(option);});
      actions.append(select,button('Show on this TV',async()=>{await api('/api/devices/'+device.id+'/display','POST',{source:select.value});notify('Selection sent to '+device.name+'.');await refresh(true);}));
      if(state.permissions.manage_accounts&&state.available_locations.length>1){const destination=document.createElement('select');destination.setAttribute('aria-label','Move '+device.name+' to location');state.available_locations.filter(item=>item.id!==state.location.id).forEach(item=>{const option=document.createElement('option');option.value=item.id;option.textContent='Move to '+item.name;destination.append(option);});actions.append(destination,button('Move',async()=>{const name=state.available_locations.find(item=>item.id===destination.value).name;if(!confirm('Move '+device.name+' to '+name+'? Its page will reset to Menu.'))return;await api('/api/devices/'+device.id+'/location','PATCH',{location_id:destination.value});notify(device.name+' moved to '+name+'.');await refresh(true);}));}
      actions.append(button('Forget',async()=>{if(!confirm('Forget '+device.name+'? The TV will require pairing again.'))return;await api('/api/devices/'+device.id,'DELETE');await refresh(true);}));
    }
    card.append(title,status,actions);container.append(card);
  });
}
function renderPlaylist() {
  const list=$('playlist');list.replaceChildren();
  if (!order.length) { const p=document.createElement('p');p.textContent='Add files from the library to start a playlist.';list.append(p); }
  order.forEach((id,index)=>{
    const item=state.library.find(x=>x.id===id);
    const row=document.createElement('li');row.className='playlist-row';
    const name=document.createElement('span');name.className='name';name.textContent=`${index+1}. ${item ? item.name : 'Missing file — remove this entry'}`;
    const actions=document.createElement('div');actions.className='row-actions';
    actions.append(button('Up',()=>{[order[index-1],order[index]]=[order[index],order[index-1]];changed();}, index===0),button('Down',()=>{[order[index+1],order[index]]=[order[index],order[index+1]];changed();}, index===order.length-1),button('Remove',()=>{order.splice(index,1);changed();}));
    row.append(name,actions);list.append(row);
  });
}
function renderLibrary() {
  const library=$('library');library.replaceChildren();
  if (!state.library.length) { const p=document.createElement('p');p.className='muted';p.textContent='Your media library is empty.';library.append(p); }
  state.library.forEach(item=>{
    const row=document.createElement('div');row.className='library-row';
    if(item.kind==='image'){const img=document.createElement('img');img.src=scoped('/media/'+item.id);img.alt='';img.loading='lazy';row.append(img);}
    const name=document.createElement('span');name.className='name';name.textContent=item.name;
    const detail=document.createElement('small');detail.textContent=`${item.kind} · ${(item.size/1024/1024).toFixed(1)} MB`;name.append(detail);
    const actions=document.createElement('div');actions.className='row-actions';
    actions.append(button(order.includes(item.id)?'In playlist':'Add to playlist',()=>{if(!order.includes(item.id)){order.push(item.id);changed();}},order.includes(item.id)),button('Delete',async()=>{if(!confirm(`Delete ${item.name} from the Pi?`))return;await api('/api/media/'+item.id,'DELETE');await refresh(true);notify('File deleted.');}));
    row.append(name,actions);library.append(row);
  });
}
async function refresh(force=false) {
  const sequence=++refreshSequence;
  const previous=state;
  const incoming=await api('/api/state');
  if(sequence!==refreshSequence)return;
  state=incoming;
  $('location-title').textContent=state.location.name+' screens';
  $('main-display-grid').hidden=!state.main_display;
  $('connection').textContent=state.main_display?(state.display.online?'Pi controller connected':'Waiting for Pi controller'):(state.devices.filter(device=>device.online).length+' of '+state.devices.length+' TVs online');
  $('current').textContent=state.display.online?(labels[state.display.source] || 'Starting…'):'Status unavailable';
  $('requested').textContent='Selected: '+labels[state.source];
  $('display-detail').textContent=state.display.online?state.display.status:'The management service is running. The display controller has not reported recently.';
  $('storage').textContent=(state.free_bytes/1024**3).toFixed(1)+' GB available';
  $('maintenance').textContent=state.maintenance.status+(state.maintenance.completed_at?' · '+new Date(state.maintenance.completed_at).toLocaleString():'');
  $('app-updates').textContent=state.app_updates.status+(state.app_updates.completed_at?' · '+new Date(state.app_updates.completed_at).toLocaleString():'');
  $('check-update').disabled=!state.permissions.system_admin || !state.app_updates.available || state.app_updates.busy;
  $('check-update').textContent=state.app_updates.busy?'Checking for updates…':'Check for updates now';
  $('reboot').textContent=state.reboot_required?'A system reboot is required to finish updates. Arrange it outside business hours.':'No system reboot is currently reported as required.';
  if(!initialized){$('source').value=state.source;initialized=true;}
  if(!dirty){order=[...state.playlist];$('seconds').value=state.seconds;$('muted').checked=state.muted;$('playlist-state').textContent='Saved';renderPlaylist();}
  if(force || !previous || JSON.stringify(previous.library)!==JSON.stringify(state.library) || JSON.stringify(previous.playlist)!==JSON.stringify(state.playlist)){renderLibrary();if(dirty)renderPlaylist();}
  renderDevices();
}
async function action(node, task) {node.disabled=true;try{await task();}catch(error){notify(error.message);}finally{node.disabled=false;}}
$('apply').onclick=()=>action($('apply'),async()=>{await api('/api/display','POST',{source:$('source').value});notify('Selection saved. Waiting for the Pi to apply it…');await refresh();});
$('reload').onclick=()=>action($('reload'),async()=>{await api('/api/reload','POST',{});notify('Reload requested.');});
$('check-update').onclick=async()=>{const node=$('check-update');node.disabled=true;node.textContent='Checking for updates…';try{await api('/api/app-update','POST',{});notify('Update check started. The admin page may reconnect while an update installs.');}catch(error){notify(error.message);node.disabled=false;node.textContent='Check for updates now';}};
$('seconds').oninput=changed;$('muted').onchange=changed;
async function savePlaylist(show=false){
  if(uploading)throw new Error('Wait for the uploads to finish before saving the playlist.');
  await api('/api/playlist','POST',{ids:order,seconds:Number($('seconds').value),muted:$('muted').checked});
  dirty=false;
  if(show){await api('/api/display','POST',{source:'media'});$('source').value='media';}
  await refresh(true);notify(show?'Playlist saved. Uploaded Media selected for the TV.':'Playlist saved. Tap Save & show playlist to play it.');
}
$('save-playlist').onclick=()=>action($('save-playlist'),()=>savePlaylist());
$('show-playlist').onclick=()=>action($('show-playlist'),()=>savePlaylist(true));
function uploadFile(file, autoAdd) {return new Promise((resolve,reject)=>{
  const xhr=new XMLHttpRequest();xhr.open('POST',scoped('/api/upload'));xhr.setRequestHeader('X-CSRF-Token',csrf);xhr.timeout=300000;
  xhr.upload.onprogress=event=>{if(event.lengthComputable)$('upload-progress').value=event.loaded/event.total*100;};
  xhr.upload.onload=()=>{$('upload-status').textContent='Checking and saving '+file.name+' on the Pi…';};
  xhr.onload=()=>{
    if(xhr.status===401){reject(new Error('Your login expired. Sign in again, then retry.'));return;}
    if(xhr.status===413){reject(new Error('This file is too large. Photos: 20 MB; videos: 256 MB.'));return;}
    let result;try{result=JSON.parse(xhr.responseText);}catch{reject(new Error('The Pi could not finish this upload (HTTP '+xhr.status+'). Check its connection and service logs.'));return;}
    if(xhr.status>=200&&xhr.status<300)resolve(result);else reject(new Error(result.error || 'Upload failed.'));
  };
  xhr.onerror=()=>reject(new Error('Connection lost during upload.'));
  xhr.ontimeout=()=>reject(new Error('Upload timed out. Check the library before retrying.'));
  const form=new FormData();form.append('file',file);form.append('add_to_playlist',String(autoAdd));xhr.send(form);
});}
async function uploadFiles(files) {
  if(!files.length)return;
  if(uploading){notify('Please wait for the current upload to finish.');return;}
  const autoAdd=$('auto-add').checked;
  let succeeded=0,failed=0;
  $('upload-results').replaceChildren();
  uploading=true;$('files').disabled=true;$('upload-progress').hidden=false;
  try{
    for(const file of files){
      $('upload-progress').value=0;$('upload-status').textContent='Uploading '+file.name+'…';
      const resultLine=document.createElement('li');$('upload-results').append(resultLine);
      let item;
      try{item=await uploadFile(file,autoAdd);}catch(error){failed++;resultLine.className='error';resultLine.textContent=file.name+': '+error.message;continue;}
      succeeded++;resultLine.className='success';resultLine.textContent=file.name+': saved on Pi'+(item.added_to_playlist?' and added to playlist.':'.');
      if(item.added_to_playlist&&dirty&&!order.includes(item.id)){order.push(item.id);}
      try{await refresh(true);}catch(error){notify('The file was saved, but the library could not refresh. Reload this page to see it.');}
    }
    $('upload-status').textContent=succeeded+' saved · '+failed+' failed.'+(succeeded?(autoAdd?' Tap Save & show playlist below to display your uploads.':' Add saved files to the playlist below.'):' See the errors below; no files were saved.');
  }finally{uploading=false;$('files').disabled=false;$('files').value='';$('upload-progress').hidden=true;}
}
$('files').onchange=event=>uploadFiles(Array.from(event.target.files));
$('drop').ondragover=event=>{event.preventDefault();$('drop').classList.add('over');};
$('drop').ondragleave=()=>$('drop').classList.remove('over');
$('drop').ondrop=event=>{event.preventDefault();$('drop').classList.remove('over');uploadFiles(Array.from(event.dataTransfer.files));};
window.addEventListener('beforeunload',event=>{if(dirty || uploading){event.preventDefault();event.returnValue='';}});
locationSelect.onchange=()=>{if(dirty&&!confirm('Discard unsaved playlist changes and switch locations?')){locationSelect.value=state.location.id;return;}dirty=false;initialized=false;state=undefined;order=[];history.replaceState(null,'','/?location='+encodeURIComponent(locationSelect.value));refresh(true).catch(error=>notify(error.message));};
async function poll(){try{if(!uploading)await refresh();}catch(error){notify(error.message);$('connection').textContent='Connection interrupted';}setTimeout(poll,5000);}
poll();
