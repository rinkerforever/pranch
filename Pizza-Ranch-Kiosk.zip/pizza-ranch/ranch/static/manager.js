'use strict';
const $ = id => document.getElementById(id);
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const labels = {menu:'Menu',ads:'Ads',funzone:'Funzone Ads',media:'Uploaded Media',setup:'Setup',fallback:'Offline fallback',stopped:'Stopped'};
let state, order = [], dirty = false, initialized = false, uploading = false;
function notify(message) { $('notice').textContent = message; }
async function api(path, method='GET', body) {
  const response = await fetch(path, {method, headers:{'X-CSRF-Token':csrf,'Content-Type':'application/json'}, body:body === undefined ? undefined : JSON.stringify(body)});
  if (response.status === 401) { location.href='/login'; throw new Error('Please sign in again.'); }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
}
function button(text, handler, disabled=false) {
  const node=document.createElement('button');node.type='button';node.textContent=text;node.disabled=disabled;
  node.onclick=async()=>{node.disabled=true;try{await handler();}catch(error){notify(error.message);}finally{node.disabled=disabled;}};return node;
}
function changed() { dirty=true; $('playlist-state').textContent='Unsaved changes'; renderPlaylist(); }
function renderPlaylist() {
  const list=$('playlist');list.replaceChildren();
  if (!order.length) { const p=document.createElement('p');p.textContent='Add files from the library to start a playlist.';list.append(p); }
  order.forEach((id,index)=>{
    const item=state.library.find(x=>x.id===id);
    const row=document.createElement('li');row.className='playlist-row';
    const name=document.createElement('span');name.className='name';name.textContent=`${index+1}. ${item ? item.name : 'Missing file — remove this entry'}`;
    const actions=document.createElement('div');actions.className='row-actions';
    actions.append(button('Up',()=>{[order[index-1],order[index]]=[order[index],order[index-1]];changed();}, index===0),button('Down',()=>{[order[index+1],order[index]]=[order[index],order[index+1]];changed();}, index===order.length-1),button('Remove',()=>{order.splice(index,1);changed();}));
    row.append(name,actions);list.append(row);
  });
}
function renderLibrary() {
  const library=$('library');library.replaceChildren();
  if (!state.library.length) { const p=document.createElement('p');p.className='muted';p.textContent='Your media library is empty.';library.append(p); }
  state.library.forEach(item=>{
    const row=document.createElement('div');row.className='library-row';
    if(item.kind==='image'){const img=document.createElement('img');img.src='/media/'+item.id;img.alt='';img.loading='lazy';row.append(img);}
    const name=document.createElement('span');name.className='name';name.textContent=item.name;
    const detail=document.createElement('small');detail.textContent=`${item.kind} · ${(item.size/1024/1024).toFixed(1)} MB`;name.append(detail);
    const actions=document.createElement('div');actions.className='row-actions';
    actions.append(button('Add to playlist',()=>{if(!order.includes(item.id)){order.push(item.id);changed();}else{notify('This file is already in the playlist.');}}),button('Delete',async()=>{if(!confirm(`Delete ${item.name} from the Pi?`))return;await api('/api/media/'+item.id,'DELETE');await refresh(true);notify('File deleted.');}));
    row.append(name,actions);library.append(row);
  });
}
async function refresh(force=false) {
  const previous=state;
  state=await api('/api/state');
  $('connection').textContent=state.display.online?'Pi controller connected':'Waiting for Pi controller';
  $('current').textContent=state.display.online?(labels[state.display.source] || 'Starting…'):'Status unavailable';
  $('requested').textContent='Selected: '+labels[state.source];
  $('display-detail').textContent=state.display.online?state.display.status:'The management service is running. The display controller has not reported recently.';
  $('storage').textContent=(state.free_bytes/1024**3).toFixed(1)+' GB available';
  $('maintenance').textContent=state.maintenance.status+(state.maintenance.completed_at?' · '+new Date(state.maintenance.completed_at).toLocaleString():'');
  $('reboot').textContent=state.reboot_required?'A system reboot is required to finish updates. Arrange it outside business hours.':'No system reboot is currently reported as required.';
  if(!initialized){$('source').value=state.source;initialized=true;}
  if(!dirty){order=[...state.playlist];$('seconds').value=state.seconds;$('muted').checked=state.muted;$('playlist-state').textContent='Saved';renderPlaylist();}
  if(force || !previous || JSON.stringify(previous.library)!==JSON.stringify(state.library)){renderLibrary();if(dirty)renderPlaylist();}
}
async function action(node, task) {node.disabled=true;try{await task();}catch(error){notify(error.message);}finally{node.disabled=false;}}
$('apply').onclick=()=>action($('apply'),async()=>{await api('/api/display','POST',{source:$('source').value});notify('Selection saved. Waiting for the Pi to apply it…');await refresh();});
$('reload').onclick=()=>action($('reload'),async()=>{await api('/api/reload','POST',{});notify('Reload requested.');});
$('seconds').oninput=changed;$('muted').onchange=changed;
$('save-playlist').onclick=()=>action($('save-playlist'),async()=>{await api('/api/playlist','POST',{ids:order,seconds:Number($('seconds').value),muted:$('muted').checked});dirty=false;await refresh();notify('Playlist saved. Select Uploaded Media to show it on the TV.');});
function uploadFile(file) {return new Promise((resolve,reject)=>{
  const xhr=new XMLHttpRequest();xhr.open('POST','/api/upload');xhr.setRequestHeader('X-CSRF-Token',csrf);xhr.timeout=300000;
  xhr.upload.onprogress=event=>{if(event.lengthComputable)$('upload-progress').value=event.loaded/event.total*100;};
  xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText);}catch{reject(new Error('Upload failed. Please sign in again if your session expired.'));return;}if(xhr.status>=200&&xhr.status<300)resolve(result);else reject(new Error(result.error || 'Upload failed.'));};
  xhr.onerror=()=>reject(new Error('Connection lost during upload.'));
  xhr.ontimeout=()=>reject(new Error('Upload timed out. Check the library before retrying.'));
  const form=new FormData();form.append('file',file);xhr.send(form);
});}
async function uploadFiles(files) {
  if(uploading){notify('Please wait for the current upload to finish.');return;}
  uploading=true;$('files').disabled=true;$('upload-progress').hidden=false;
  try{for(const file of files){$('upload-progress').value=0;$('upload-status').textContent='Uploading and validating '+file.name+'…';try{await uploadFile(file);await refresh(true);}catch(error){notify(file.name+': '+error.message);}}$('upload-status').textContent='Finished. Add uploaded files to your playlist.';}finally{uploading=false;$('files').disabled=false;$('files').value='';$('upload-progress').hidden=true;}
}
$('files').onchange=event=>uploadFiles(Array.from(event.target.files));
$('drop').ondragover=event=>{event.preventDefault();$('drop').classList.add('over');};
$('drop').ondragleave=()=>$('drop').classList.remove('over');
$('drop').ondrop=event=>{event.preventDefault();$('drop').classList.remove('over');uploadFiles(Array.from(event.dataTransfer.files));};
window.addEventListener('beforeunload',event=>{if(dirty || uploading){event.preventDefault();event.returnValue='';}});
async function poll(){try{await refresh();}catch(error){notify(error.message);$('connection').textContent='Connection interrupted';}setTimeout(poll,5000);}
poll();
