'use strict';
const picture = document.getElementById('image');
const video = document.getElementById('video');
const statusText = document.getElementById('player-status');
let playlist, index = -1, timer, generation = 0;
function advance() {
  clearTimeout(timer);
  const currentGeneration = ++generation;
  video.pause(); video.removeAttribute('src'); video.load();
  video.hidden = true; picture.hidden = true;
  index = (index + 1) % playlist.items.length;
  const item = playlist.items[index];
  const next = () => { if (currentGeneration === generation) advance(); };
  const failed = () => { if (currentGeneration === generation) { statusText.textContent = 'Skipping unavailable media…'; statusText.hidden = false; timer = setTimeout(next, 3000); } };
  statusText.hidden = true;
  if (item.kind === 'image') {
    picture.onload = () => { if (currentGeneration === generation) { clearTimeout(timer); picture.hidden = false; timer = setTimeout(next, playlist.seconds * 1000); } };
    picture.onerror = failed;
    timer = setTimeout(failed, 15000);
    picture.src = item.url;
  } else {
    video.muted = playlist.muted;
    video.onended = next;
    video.onerror = failed;
    video.onplaying = () => { if (currentGeneration === generation) clearTimeout(timer); };
    video.onwaiting = () => { clearTimeout(timer); timer = setTimeout(failed, 30000); };
    video.src = item.url; video.hidden = false;
    timer = setTimeout(failed, 30000);
    video.play().catch(failed);
  }
}
async function load() {
  try {
    const response = await fetch('/device/playlist', {cache:'no-store'});
    if (!response.ok) throw new Error('Playlist unavailable');
    playlist = await response.json();
    if (!playlist.items.length) throw new Error('No media selected');
    advance();
  } catch (error) { statusText.textContent = error.message; setTimeout(load, 10000); }
}
load();
