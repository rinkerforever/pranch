'use strict';
const $=id=>document.getElementById(id);
const csrf=document.querySelector('meta[name="csrf-token"]').content;
let adminState;
function notice(message,error=false){const node=$('admin-notice');node.textContent=message;node.className=error?'message error':'message success';}
async function api(path,method='GET',body){
  const response=await fetch(path,{method,headers:{'X-CSRF-Token':csrf,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
  if(response.status===401){location.href='/login';throw new Error('Please sign in again.');}
  const result=await response.json();if(!response.ok)throw new Error(result.error||'Request failed.');return result;
}
function action(button,task){button.disabled=true;Promise.resolve().then(task).catch(error=>notice(error.message,true)).finally(()=>button.disabled=false);}
function makeButton(label,handler,className=''){const node=document.createElement('button');node.type='button';node.textContent=label;node.className=className;node.onclick=()=>action(node,handler);return node;}
function roleName(role){return {system_admin:'System administrator',location_manager:'Location manager',operator:'Operator'}[role]||role;}
function locationNames(ids){return ids.length?ids.map(id=>adminState.locations.find(location=>location.id===id)?.name||'Removed location').join(', '):'All locations';}
function renderLocations(){
  const container=$('locations-list');container.replaceChildren();
  adminState.locations.forEach(location=>{
    const row=document.createElement('div');row.className='admin-row';
    const copy=document.createElement('div');const name=document.createElement('h3');name.textContent=location.name;
    const detail=document.createElement('p');detail.className='muted';detail.textContent=location.id===adminState.default_location?'Default location · Original store 8300 pages':'Custom location pages';copy.append(name,detail);
    const actions=document.createElement('div');actions.className='row-actions';
    if(adminState.role==='system_admin'){
      actions.append(makeButton('Edit',()=>openLocation(location)));
      if(location.id!==adminState.default_location)actions.append(makeButton('Delete',async()=>{if(!confirm('Delete '+location.name+'? It must have no assigned users, displays, or media.'))return;await api('/api/locations/'+location.id,'DELETE');notice(location.name+' deleted.');await refresh();}));
    }
    row.append(copy,actions);container.append(row);
  });
}
function renderUsers(){
  const container=$('users-list');container.replaceChildren();
  adminState.users.forEach(user=>{
    const row=document.createElement('div');row.className='admin-row';
    const copy=document.createElement('div');const name=document.createElement('h3');name.textContent=user.display_name+' · '+user.username;
    const detail=document.createElement('p');detail.className='muted';detail.textContent=roleName(user.role)+' · '+locationNames(user.location_ids)+' · '+(user.active?'Active':'Disabled')+(user.must_change?' · Password change required':'');copy.append(name,detail);
    const actions=document.createElement('div');actions.className='row-actions';
    actions.append(makeButton('Manage',()=>openUser(user)));
    if(user.id!==adminState.current_user_id&&user.role!=='system_admin')actions.append(makeButton('Delete',async()=>{if(!confirm('Delete '+user.username+'?'))return;await api('/api/users/'+user.id,'DELETE');notice(user.username+' deleted.');await refresh();}));
    row.append(copy,actions);container.append(row);
  });
}
async function refresh(){adminState=await api('/api/administration');$('add-location').hidden=adminState.role!=='system_admin';renderLocations();renderUsers();}
function openLocation(item){
  $('location-form-title').textContent=item?'Edit location':'Add location';$('location-id').value=item?.id||'';$('location-name').value=item?.name||'';$('menu-url').value=item?.menu_url||'';$('ads-url').value=item?.ads_url||'';$('funzone-url').value=item?.funzone_url||'';$('location-dialog').showModal();
}
function renderLocationChecks(selected){
  const container=$('user-locations');container.replaceChildren();adminState.locations.forEach(location=>{const label=document.createElement('label');label.className='check';const input=document.createElement('input');input.type='checkbox';input.value=location.id;input.checked=selected.includes(location.id);label.append(input,document.createTextNode(location.name));container.append(label);});
}
function openUser(user){
  $('user-form-title').textContent=user?'Manage user':'Add user';$('user-id').value=user?.id||'';$('user-name').value=user?.username||'';$('user-name').disabled=Boolean(user);$('user-display-name').value=user?.display_name||'';$('user-role').value=user?.role||'operator';$('user-active').checked=user?Boolean(user.active):true;$('user-active').disabled=user?.id===adminState.current_user_id;$('user-password').value='';$('password-help').textContent=user?'Leave blank to keep the current password':'Required for new users';
  [...$('user-role').options].forEach(option=>option.disabled=adminState.role!=='system_admin'&&option.value!=='operator');
  renderLocationChecks(user?.location_ids||[]);$('user-dialog').showModal();
}
$('locations-tab').onclick=()=>{$('locations-panel').hidden=false;$('users-panel').hidden=true;$('locations-tab').className='primary';$('users-tab').className='';};
$('users-tab').onclick=()=>{$('locations-panel').hidden=true;$('users-panel').hidden=false;$('locations-tab').className='';$('users-tab').className='primary';};
$('add-location').onclick=()=>openLocation();$('add-user').onclick=()=>openUser();
$('location-form').onsubmit=event=>{if(event.submitter?.value==='cancel')return;event.preventDefault();const id=$('location-id').value;const body={name:$('location-name').value,menu_url:$('menu-url').value,ads_url:$('ads-url').value,funzone_url:$('funzone-url').value};action(event.submitter,async()=>{await api(id?'/api/locations/'+id:'/api/locations',id?'PATCH':'POST',body);$('location-dialog').close();notice(id?'Location saved.':'Location created.');await refresh();});};
$('user-form').onsubmit=event=>{if(event.submitter?.value==='cancel')return;event.preventDefault();const id=$('user-id').value;const body={username:$('user-name').value,display_name:$('user-display-name').value,role:$('user-role').value,active:$('user-active').checked,password:$('user-password').value,location_ids:[...$('user-locations').querySelectorAll('input:checked')].map(input=>input.value)};action(event.submitter,async()=>{await api(id?'/api/users/'+id:'/api/users',id?'PATCH':'POST',body);$('user-dialog').close();notice(id?'User saved.':'User created with a required first-login password change.');await refresh();});};
refresh().catch(error=>notice(error.message,true));
