import json
import sqlite3
from contextlib import contextmanager


@contextmanager
def database(path):
    connection = sqlite3.connect(path, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute('PRAGMA foreign_keys=ON')
    try:
        yield connection
        connection.commit()
    except BaseException:
        connection.rollback()
        raise
    finally:
        connection.close()


def get_setting(db, key, default=None):
    row = db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    return json.loads(row['value']) if row else default


def set_setting(db, key, value):
    db.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',
               (key, json.dumps(value)))
