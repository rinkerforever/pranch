"""Direct cloud display used by the prebuilt Raspberry Pi appliance image."""
import hashlib
import io
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import threading
import time
import urllib.error
import urllib.request

from flask import Flask, abort, jsonify, render_template, request, send_file
import qrcode
from waitress import serve

CLOUD = os.environ.get('RANCH_CLOUD_URL', 'https://display.projectaimnet.com').rstrip('/')
DATA = Path(os.environ.get('RANCH_NODE_DATA', '/var/lib/pizza-ranch-node'))
MEDIA = DATA / 'media'
CREDS = DATA / 'cloud-device.json'
PENDING = DATA / 'cloud-enrollment.json'
LOCAL_TOKEN = Path(os.environ.get('RANCH_DEVICE_TOKEN_FILE', '/etc/pizza-ranch/device-token'))
UPDATE_REQUEST = Path('/var/lib/pizza-ranch-update-requests/check')
DEFAULTS = {
    'menu_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only',
    'ads_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only',
    'funzone_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads',
    'custom_pages': [],
}


def identity():
    machine = Path('/etc/machine-id').read_text().strip()
    return hashlib.sha256(('pizza-ranch-cloud:' + machine).encode()).hexdigest()[:32]


def cloud_request(path, payload, token=None, timeout=30):
    headers = {'Content-Type': 'application/json', 'User-Agent': 'PizzaRanchCloudDisplay/1.0'}
    if token:
        headers['Authorization'] = 'Device ' + token
    call = urllib.request.Request(CLOUD + path, data=json.dumps(payload).encode(), headers=headers, method='POST')
    with urllib.request.urlopen(call, timeout=timeout) as response:
        return json.load(response)


def private_json(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value))
    os.chmod(temporary, 0o600)
    temporary.replace(path)


def begin_enrollment(device_id, name):
    current = None
    try:
        current = json.loads(PENDING.read_text())
        if current.get('expires_at', 0) > time.time() + 30:
            return current
    except (OSError, ValueError):
        pass
    claim = secrets.token_hex(32)
    result = cloud_request('/api/device/enroll/start', {
        'device_id': device_id, 'device_name': name, 'claim_secret': claim,
    })
    pending = dict(result, claim_secret=claim, expires_at=time.time() + int(result['expires_in']))
    private_json(PENDING, pending)
    return pending


def poll_enrollment(device_id, name):
    pending = begin_enrollment(device_id, name)
    result = cloud_request('/api/device/enroll/status', {
        'enrollment_id': pending['enrollment_id'], 'claim_secret': pending['claim_secret'],
    })
    if result.get('status') != 'approved':
        return None, pending
    credentials = {key: result[key] for key in ('device_id', 'screen_id', 'location_id', 'device_token')}
    private_json(CREDS, credentials)
    PENDING.unlink(missing_ok=True)
    try:
        UPDATE_REQUEST.parent.mkdir(parents=True, exist_ok=True)
        UPDATE_REQUEST.write_text('check\n')
    except (FileExistsError, PermissionError, OSError):
        pass
    return credentials, None


def download(item, token):
    suffix = '.mp4' if item['kind'] == 'video' else {
        'image/png': '.png', 'image/webp': '.webp'
    }.get(item.get('mime_type'), '.jpg')
    destination = MEDIA / (str(item['id']) + suffix)
    if destination.is_file() and destination.stat().st_size == int(item['size']):
        digest = hashlib.sha256()
        with destination.open('rb') as existing:
            while chunk := existing.read(1024 * 1024):
                digest.update(chunk)
        digest = digest.hexdigest()
        if secrets.compare_digest(digest, item['sha256']):
            return destination
    temporary = MEDIA / (str(item['id']) + '.part')
    call = urllib.request.Request(CLOUD + item['url'], headers={
        'Authorization': 'Device ' + token, 'User-Agent': 'PizzaRanchCloudDisplay/1.0'})
    digest = hashlib.sha256(); size = 0
    try:
        with urllib.request.urlopen(call, timeout=180) as response, temporary.open('xb') as output:
            os.chmod(temporary, 0o600)
            while chunk := response.read(1024 * 1024):
                size += len(chunk)
                if size > 100 * 1024**2 or size > int(item['size']):
                    raise ValueError('Campaign file exceeded its declared size.')
                digest.update(chunk); output.write(chunk)
        if size != int(item['size']) or not secrets.compare_digest(digest.hexdigest(), item['sha256']):
            raise ValueError('Campaign file failed its integrity check.')
        temporary.replace(destination); os.chmod(destination, 0o600)
        return destination
    finally:
        temporary.unlink(missing_ok=True)


def create_app():
    DATA.mkdir(parents=True, exist_ok=True); MEDIA.mkdir(exist_ok=True)
    os.chmod(DATA, 0o700); os.chmod(MEDIA, 0o700)
    device_id, name = identity(), socket.gethostname()
    local_token = LOCAL_TOKEN.read_text().strip()
    state = dict(source='setup', url='http://127.0.0.1:8080/device/setup', revision=0,
                 playlist=[], seconds=10, muted=True, status='Starting secure cloud enrollment…')
    enrollment = {}; lock = threading.RLock(); app = Flask(__name__)

    def local_only():
        if request.remote_addr not in {'127.0.0.1', '::1'}:
            abort(403)

    @app.after_request
    def secure_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.get('/device/state')
    def device_state():
        local_only()
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), local_token): abort(403)
        with lock: result = dict(state)
        result.update(registered=True, recovery=False, maintenance={})
        return jsonify(result)

    @app.post('/device/heartbeat')
    def heartbeat():
        local_only()
        if not secrets.compare_digest(request.headers.get('X-Device-Token', ''), local_token): abort(403)
        return jsonify(ok=True)

    @app.get('/device/setup')
    def setup():
        local_only()
        with lock: current, status = dict(enrollment), state['status']
        return render_template('node_setup.html', code=current.get('code','------'), name=name,
                               status=status, qr_image='/device/enroll-qr.png' if current.get('enrollment_url') else None)

    @app.get('/device/enroll-qr.png')
    def enrollment_qr():
        local_only()
        with lock: url = enrollment.get('enrollment_url')
        if not url: abort(404)
        output=io.BytesIO(); qrcode.make(url).save(output,format='PNG'); output.seek(0)
        return send_file(output,mimetype='image/png')

    @app.get('/device/player')
    def player(): local_only(); return render_template('player.html')

    @app.get('/device/offline')
    def offline(): local_only(); return render_template('offline.html')

    @app.get('/device/playlist')
    def playlist():
        local_only()
        with lock: current=dict(state)
        return jsonify(items=[{'url':'/device/media/'+item['id'],'kind':item['kind']} for item in current['playlist']],
                       seconds=current['seconds'],muted=current['muted'])

    @app.get('/device/media/<identifier>')
    def media(identifier):
        local_only()
        with lock: item=next((entry for entry in state['playlist'] if entry['id']==identifier),None)
        if not item: abort(404)
        path=next((candidate for candidate in MEDIA.glob(identifier+'.*') if candidate.suffix != '.part'),None)
        if not path: abort(404)
        return send_file(path,conditional=True,mimetype=item.get('mime_type') or ('video/mp4' if item['kind']=='video' else 'image/jpeg'))

    def synchronize():
        credentials = None
        while True:
            try:
                if not credentials:
                    try: credentials=json.loads(CREDS.read_text())
                    except (OSError,ValueError):
                        credentials,pending=poll_enrollment(device_id,name)
                        with lock:
                            enrollment.clear(); enrollment.update(pending or {})
                            state['status']='Scan the QR code, sign in, and add this TV.' if pending else 'Enrollment approved. Updating now…'
                        if not credentials: time.sleep(5); continue
                token=credentials['device_token']
                desired=cloud_request('/api/device/state',{'reported_source':state['source'] if state['source'] in {'menu','ads','funzone','media'} else None},token)
                pages={**DEFAULTS,**(desired.get('pages') or {})}; requested=desired.get('desired_source','menu')
                new_state=dict(source='menu',url=pages['menu_url'],playlist=[],seconds=10,muted=True,
                               status='Connected securely to the cloud.')
                if requested in {'menu','ads','funzone'}:
                    new_state['source']=requested; new_state['url']=pages[{'menu':'menu_url','ads':'ads_url','funzone':'funzone_url'}[requested]]
                elif requested.startswith('custom:'):
                    page=next((p for p in pages.get('custom_pages',[]) if 'custom:'+str(p.get('id'))==requested),None)
                    if page: new_state['url']=page['url']
                elif requested.startswith('campaign:') and desired.get('campaign'):
                    campaign=desired['campaign']; items=campaign.get('items') or []
                    if sum(int(item['size']) for item in items) > 2*1024**3: raise ValueError('Campaign exceeds the 2 GB display cache.')
                    if shutil.disk_usage(MEDIA).free < sum(int(item['size']) for item in items)+256*1024**2: raise ValueError('Not enough storage for campaign.')
                    for item in items: download(item,token)
                    keep={item['id'] for item in items}
                    for file in MEDIA.iterdir():
                        if file.is_file() and file.stem not in keep: file.unlink()
                    new_state.update(source='media',url='http://127.0.0.1:8080/device/player',playlist=items,
                                     seconds=int(campaign.get('seconds',10)),muted=bool(campaign.get('muted',True)))
                with lock:
                    comparable = ('source', 'url', 'playlist', 'seconds', 'muted')
                    changed = any(state.get(key) != new_state.get(key) for key in comparable)
                    new_state['revision'] = state.get('revision', 0) + (1 if changed else 0)
                    state.update(new_state); enrollment.clear()
            except urllib.error.HTTPError as error:
                if error.code in {401,403}: credentials=None; CREDS.unlink(missing_ok=True)
                if error.code == 410: PENDING.unlink(missing_ok=True)
                with lock: state['status']=f'Cloud connection returned HTTP {error.code}; retrying.'
            except Exception as error:
                with lock: state['status']=('Offline; keeping the last downloaded content. '+str(error))[:180]
            time.sleep(15 if credentials else 5)

    threading.Thread(target=synchronize,daemon=True).start()
    return app


def main():
    serve(create_app(),host='127.0.0.1',port=8080,threads=4)


if __name__ == '__main__': main()
