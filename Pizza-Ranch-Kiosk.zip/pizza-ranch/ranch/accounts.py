import json
import re
import secrets
import time
from urllib.parse import urlparse

from werkzeug.security import generate_password_hash

from ranch.storage import get_setting, set_setting


DEFAULT_LOCATION_ID = 'tyler'
ROLES = {'system_admin', 'location_manager', 'operator'}
USERNAME = re.compile(r'^[a-z0-9][a-z0-9._-]{2,49}$')
DEFAULT_URLS = {
    'menu_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=menu-only',
    'ads_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=ads-only',
    'funzone_url': 'https://green-forest-07f346210.6.azurestaticapps.net/8300?type=funzone-ads',
}


def migrate(db):
    db.executescript('''
    CREATE TABLE IF NOT EXISTS locations(
      id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
      menu_url TEXT NOT NULL, ads_url TEXT NOT NULL, funzone_url TEXT NOT NULL,
      created REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS users(
      id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL, password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('system_admin','location_manager','operator')),
      active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 1,
      generation INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS user_locations(
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      location_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
      PRIMARY KEY(user_id,location_id));
    CREATE TABLE IF NOT EXISTS location_settings(
      location_id TEXT PRIMARY KEY REFERENCES locations(id) ON DELETE CASCADE,
      source TEXT NOT NULL DEFAULT 'menu', playlist TEXT NOT NULL DEFAULT '[]',
      seconds INTEGER NOT NULL DEFAULT 10, muted INTEGER NOT NULL DEFAULT 1,
      revision INTEGER NOT NULL DEFAULT 1);
    ''')
    db.execute('''INSERT OR IGNORE INTO locations(id,name,menu_url,ads_url,funzone_url,created)
                  VALUES(?,?,?,?,?,?)''',
               (DEFAULT_LOCATION_ID, 'Tyler', DEFAULT_URLS['menu_url'], DEFAULT_URLS['ads_url'],
                DEFAULT_URLS['funzone_url'], time.time()))
    db.execute('''INSERT OR IGNORE INTO location_settings(location_id,source,playlist,seconds,muted,revision)
                  VALUES(?,?,?,?,?,?)''',
               (DEFAULT_LOCATION_ID, get_setting(db, 'source', 'menu'),
                json.dumps(get_setting(db, 'playlist', [])), get_setting(db, 'seconds', 10),
                int(get_setting(db, 'muted', True)), get_setting(db, 'revision', 1)))
    registered = bool(get_setting(db, 'registered', False))
    admin = db.execute("SELECT id FROM users WHERE username='admin' COLLATE NOCASE").fetchone()
    if admin is None:
        db.execute('''INSERT INTO users(id,username,display_name,password_hash,role,active,must_change,generation,created)
                      VALUES(?,?,?,?,?,?,?,?,?)''',
                   (secrets.token_hex(16), 'admin', 'Administrator',
                    get_setting(db, 'password', generate_password_hash('pranch')), 'system_admin',
                    1, int(not registered), get_setting(db, 'generation', 1), time.time()))
    for table in ('devices', 'media'):
        columns = {row['name'] for row in db.execute(f'PRAGMA table_info({table})')}
        if 'location_id' not in columns:
            db.execute(f"ALTER TABLE {table} ADD COLUMN location_id TEXT NOT NULL DEFAULT '{DEFAULT_LOCATION_ID}'")


def validate_location(name, urls):
    name = ' '.join(str(name or '').split())
    if not 2 <= len(name) <= 80:
        raise ValueError('Location names must contain 2–80 characters.')
    cleaned = {}
    for key in DEFAULT_URLS:
        value = str(urls.get(key, '')).strip()
        parsed = urlparse(value)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError('Every location page must be a complete HTTPS address.')
        if parsed.port not in {None, 443}:
            raise ValueError('Location pages must use the standard HTTPS port.')
        cleaned[key] = value
    return name, cleaned


def validate_username(value):
    username = str(value or '').strip().lower()
    if not USERNAME.fullmatch(username):
        raise ValueError('Usernames must be 3–50 lowercase letters, numbers, dots, dashes, or underscores.')
    return username


def location_state(db, location_id):
    row = db.execute('SELECT * FROM location_settings WHERE location_id=?', (location_id,)).fetchone()
    if row is None:
        return None
    if location_id == DEFAULT_LOCATION_ID:
        return {key: get_setting(db, key, {'source': 'menu', 'playlist': [], 'seconds': 10,
                                           'muted': True, 'revision': 1}[key])
                for key in ('source', 'playlist', 'seconds', 'muted', 'revision')}
    return {'source': row['source'], 'playlist': json.loads(row['playlist']),
            'seconds': row['seconds'], 'muted': bool(row['muted']), 'revision': row['revision']}


def save_location_state(db, location_id, **changes):
    current = location_state(db, location_id)
    if current is None:
        raise KeyError(location_id)
    current.update(changes)
    db.execute('''UPDATE location_settings SET source=?,playlist=?,seconds=?,muted=?,revision=?
                  WHERE location_id=?''',
               (current['source'], json.dumps(current['playlist']), current['seconds'],
                int(current['muted']), current['revision'], location_id))
    if location_id == DEFAULT_LOCATION_ID:
        for key in ('source', 'playlist', 'seconds', 'muted', 'revision'):
            set_setting(db, key, current[key])
    return current


def user_locations(db, user_id):
    return [row['location_id'] for row in db.execute(
        'SELECT location_id FROM user_locations WHERE user_id=? ORDER BY location_id', (user_id,))]


def can_access_location(db, user, location_id):
    if not user or not user['active']:
        return False
    if user['role'] == 'system_admin':
        return db.execute('SELECT 1 FROM locations WHERE id=?', (location_id,)).fetchone() is not None
    return db.execute('SELECT 1 FROM user_locations WHERE user_id=? AND location_id=?',
                      (user['id'], location_id)).fetchone() is not None


def locations_for_user(db, user):
    if user['role'] == 'system_admin':
        rows = db.execute('SELECT * FROM locations ORDER BY name COLLATE NOCASE')
    else:
        rows = db.execute('''SELECT l.* FROM locations l JOIN user_locations ul ON ul.location_id=l.id
                             WHERE ul.user_id=? ORDER BY l.name COLLATE NOCASE''', (user['id'],))
    return [dict(row) for row in rows]
