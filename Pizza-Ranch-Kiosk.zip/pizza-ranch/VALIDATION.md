# Validation and installation acceptance

## Completed on the development computer

The application, controller, video-validation, and maintenance suites cover the delivered behavior. The separate real-browser management workflow also passes.

- Automated application/security tests: authentication, required first password change, password persistence across restart, session invalidation, throttling, CSRF, security headers, preset URL restrictions, protected media delivery, playlist validation/deletion rules, image sanitization, invalid/oversized uploads, free-space limits, and QR removal after registration.
- Internal device endpoints reject LAN and forwarded requests; the controller state and heartbeat require a private token.
- Video validation tests cover H.264/AAC acceptance, incompatible codecs/resolution, explicit remux streams, and shell-free subprocess arguments. These use mocked FFmpeg/ffprobe; actual decoding was not tested here.
- Maintenance tests cover successful update status, management-service restart, failed update reporting, and absence of automatic reboot. They do not run package updates on the development computer.
- Controller tests cover network failures, its private token channel, fallback to a playlist, and recovery to the selected website. Firefox process calls in these tests are mocked.
- Firefox migration checks verify kiosk/profile isolation, disabled password storage, private browsing, autoplay configuration, and maintenance behavior. Actual Firefox launch/keyring behavior and video playback still require the Pi; the earlier Edge management-page checks do not establish Firefox runtime compatibility.
- Real headless Edge browser: login, registration, preset switching, image upload, playlist saving, selecting Uploaded Media, screenshots at desktop/phone sizes, and overflow checks at 320, 390, 736, and 1024 pixels. No JavaScript runtime errors.
- Phone-upload update: real HEIC sample converted by libheif on Windows; automatic playlist persistence tested across application restart; extensionless mobile images, 24 MP JPEG resizing, missing decoder errors, and H.264 MOV / HEVC rejection covered. Linux conversion memory limits and actual iOS Safari still need testing on the Pi/phone.
- JavaScript syntax checks and shell syntax checks for the shipped scripts.
- Screen recovery: tests cover one-time tokens, five-minute expiry, ten-minute request cooldown, session invalidation, rejection of remote/different-subnet clients and spoofed proxy requests, exclusion of VPN interfaces, fail-closed network discovery, restart invalidation, CSRF, and weak-password handling. Controller tests verify the reset screen takes priority over an offline fallback and returns to the previous selection afterward. Physical QR scanning and the installed nginx/netlink configuration still require checking on the Pi.

Development environment: Windows, Python 3.12, Flask 3.1.3, Waitress 3.0.2, Pillow 12.3.0, qrcode 8.2. Production uses the Raspberry Pi OS/Debian Python packages; it does not use this Windows virtual environment.

Windows example launcher: PowerShell prerequisite check, Python demo startup on loopback port 8085, and an HTTP login smoke check were verified. The demo is explicitly labeled and uses separate demo-data; that data is excluded from the release ZIP.

## Required on the actual Pi before unattended use

- [ ] Install on Raspberry Pi OS 32-bit Desktop with labwc; verify nginx and both application/controller services start without errors. The installer also accepts 64-bit Desktop. Neither architecture has been tested on physical hardware here.
- [ ] Reboot: setup QR appears. Scan it from your phone and verify the local certificate/address.
- [ ] Change admin/pranch to a new password: QR disappears and does not return after another reboot.
- [ ] Open each exact Menu, Ads, and Funzone Ads URL; verify it renders correctly and needs no manual login/cookie interaction.
- [ ] Switch between each source from a phone and desktop. Check that the physical TV follows the chosen content.
- [ ] Upload and loop a real JPEG/PNG and H.264/AAC MP4; test image timing, video end, mute/unmute, reorder, and repeat. Check CPU/memory and playback smoothness on the Pi 3 B+.
- [ ] Disconnect internet: saved media fallback appears after about two failed reachability checks. Reconnect: website returns.
- [ ] Kill the kiosk Firefox process: controller relaunches it with the last selected source.
- [ ] Confirm system timezone and `systemctl list-timers pizza-ranch-updates.timer`. Run one scheduled update manually outside business hours; inspect journal and dashboard status.
- [ ] Verify media filesystem execute bits are absent and service `NoExecPaths=/var/lib/pizza-ranch` is active. Confirm both LAN and Tailscale proxies reject `/device/state`, `/device/setup`, and `/device/player`.
- [ ] Configure Tailscale, access management while your phone is on cellular data, and restrict access to approved accounts/devices.
- [ ] Check the local certificate renewal date and make a secure backup.
- [ ] Install a second Pi 3 B+ with `sudo bash install.sh display`; confirm it discovers only the same-subnet server and shows a six-digit pairing code.
- [ ] Pair it from the server admin page, reboot both Pis independently, and verify automatic reconnection, per-TV Menu/Ads/Funzone/Media selection, online/offline reporting, and Forget/re-pair behavior.
- [ ] Assign Uploaded Media, wait for the display to download it, then interrupt Wi-Fi and verify cached playback. Confirm altered or incomplete transfers are rejected and the node cache remains within 2 GB.
- [ ] Confirm guest/client-isolated Wi-Fi fails closed, Tailscale cannot reach `/fleet`, and replacing the server certificate requires explicit re-pairing.

Application updater tests cover unchanged-release detection, changed-release installation, recovery after installer failure, unsafe ZIP rejection, required-release files and download failure without installation. Installer execution is mocked in these tests; apt, systemd scheduling, user-session restart and real recovery must still be verified on the Pi. Confirm both timers with `systemctl list-timers 'pizza-ranch*'`, and test a changed GitHub ZIP before relying on unattended operation.

JPEG compatibility fix: reproduced the exact unsupported-image error using real encoded multipicture JPEG (MPO) uploads with .JPG/.jpeg names. Both now save only the primary picture as a plain single-frame JPEG. The 14 phone-upload/video tests pass, including unsupported GIF renamed to JPEG rejection and temporary-file cleanup. The user's original failing photo has not been supplied or tested.

Multi-display tests cover LAN-only discovery endpoints, pairing-code rejection and acceptance, one-time token delivery, certificate matching, per-display source assignment, authenticated media transfer, SHA-256 cache validation, cache reuse, modified-transfer cleanup, forgetting a display, and private-address mDNS selection. systemd, Avahi, Wi-Fi behavior and simultaneous real Pi displays remain hardware acceptance items.

Local certificate tests cover same-subnet enforcement for the HTTP bootstrap page and CA download, fingerprint display, CA download contents, the address-only setup QR, and rejection when reached outside the trusted nginx LAN entry point. The installer now migrates the old self-signed leaf to a private CA plus server certificate. Actual iOS/Android/Windows certificate installation and browser trust-store behavior must be verified on each management device.

No Raspberry Pi, restaurant network, Tailscale account, or physical TV was available in this workspace. Those installation/hardware checks are not claimed as completed.
