"""Install changed releases from the owner's fixed HTTPS GitHub ZIP URL.

The repository is a trusted software source: its installer runs as root.
Never take a source URL or installer identity from application-writable data.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tempfile
import time
import urllib.request
import zipfile

URL = 'https://raw.githubusercontent.com/rinkerforever/pranch/main/Pizza-Ranch-Kiosk.zip'
STATE = Path('/var/lib/pizza-ranch-maintenance')
INSTALLED = Path('/opt/pizza-ranch')
LIMIT = 32 * 1024 * 1024


def fingerprint(root):
    digest = hashlib.sha256()
    files = [root / 'install.sh']
    for folder in ('ranch', 'deploy'):
        files.extend(p for p in (root / folder).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix != '.pyc')
    for file in sorted(files):
        digest.update(file.relative_to(root).as_posix().encode() + b'\0')
        digest.update(hashlib.sha256(file.read_bytes()).digest())
    return digest.hexdigest()


def unpack(archive, destination):
    with zipfile.ZipFile(archive) as release:
        entries = release.infolist()
        if len(entries) > 2000 or sum(e.file_size for e in entries) > LIMIT:
            raise ValueError('Release exceeds extraction limits')
        seen = set()
        for entry in entries:
            path = PurePosixPath(entry.filename)
            mode = entry.external_attr >> 16
            if (path.is_absolute() or '..' in path.parts or '\\' in entry.orig_filename
                    or not path.parts or path.parts[0] != 'pizza-ranch'
                    or entry.filename in seen or stat.S_ISLNK(mode)
                    or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR))):
                raise ValueError('Unsafe release archive entry')
            seen.add(entry.filename)
        release.extractall(destination)
    root = destination / 'pizza-ranch'
    for required in ('install.sh', 'ranch/app.py', 'deploy/pizza-ranch.service',
                     'deploy/app_updates.py', 'deploy/pizza-ranch-app-updates.timer',
                     'deploy/pizza-ranch-app-updates.path'):
        if not (root / required).is_file():
            raise ValueError('Incomplete or old release; required file missing: ' + required)
    subprocess.run(['/bin/bash', '-n', str(root / 'install.sh')], check=True)
    # Syntax validation without importing/executing release code.
    for folder in ('ranch', 'deploy'):
        for file in (root / folder).rglob('*.py'):
            compile(file.read_bytes(), str(file), 'exec')
    return root


def download(destination):
    request = urllib.request.Request(URL, headers={'Cache-Control': 'no-cache',
                                                  'User-Agent': 'Pizza-Ranch-Updater'})
    with urllib.request.urlopen(request, timeout=60) as response:
        if not response.url.startswith('https://raw.githubusercontent.com/'):
            raise ValueError('Unexpected release download destination')
        size = 0
        with destination.open('wb') as output:
            while chunk := response.read(65536):
                size += len(chunk)
                if size > LIMIT:
                    raise ValueError('Release download too large')
                output.write(chunk)


def install(root, user):
    environment = dict(os.environ, SUDO_USER=user, RANCH_AUTO_UPDATE='1')
    subprocess.run(['/bin/bash', str(root / 'install.sh')], env=environment,
                   check=True, timeout=7200)
    for attempt in range(30):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8080/login', timeout=3) as response:
                if response.status == 200:
                    return
        except OSError:
            pass
        time.sleep(2)
    raise RuntimeError('Installed management service did not become healthy')


def apply_release(root, user):
    if fingerprint(root) == fingerprint(INSTALLED):
        return 'No application changes.'
    backup = STATE / 'previous-release'
    if backup.exists():
        shutil.rmtree(backup)
    shutil.copytree(INSTALLED, backup)
    try:
        install(root, user)
    except Exception:
        # Restore the last application installer/code. OS package changes and
        # database migrations cannot in general be undone by this rollback.
        install(backup, user)
        raise RuntimeError('Application update failed; previous release restored')
    return 'Application updated successfully.'


def main():
    success = False
    try:
        user = Path('/etc/pizza-ranch/desktop-user').read_text().strip()
        with tempfile.TemporaryDirectory(prefix='pizza-ranch-update-') as work:
            directory = Path(work)
            archive = directory / 'release.zip'
            download(archive)
            root = unpack(archive, directory)
            status = apply_release(root, user)
        success = True
    except Exception as error:
        status = 'Application update failed: ' + str(error)
    STATE.mkdir(mode=0o755, exist_ok=True)
    temporary = STATE / 'app-status.tmp'
    temporary.write_text(json.dumps(dict(success=success, status=status,
                          completed_at=datetime.now(timezone.utc).isoformat())))
    temporary.chmod(0o644)
    temporary.replace(STATE / 'app-status.json')
    print(status, flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
