#!/bin/sh
# Run inside the actual graphical session; no hard-coded DISPLAY or user ID.
systemctl --user import-environment DISPLAY WAYLAND_DISPLAY XDG_RUNTIME_DIR XDG_SESSION_TYPE
systemctl --user restart pizza-ranch-kiosk.service
