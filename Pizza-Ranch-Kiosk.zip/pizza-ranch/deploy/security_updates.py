"""Root-owned maintenance runner. Never imports code from the writable data path."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys


def main():
    status = 'Security update run completed.'
    success = False
    try:
        subprocess.run(['apt-get', '-o', 'DPkg::Lock::Timeout=120',
                        '-o', 'APT::Update::Error-Mode=any', 'update'], check=True, timeout=900)
        subprocess.run(['unattended-upgrade'], check=True, timeout=5400)
        # Pi's Firefox builds may be in the Raspberry Pi repository, which does
        # not label security-only releases. Update this browser family explicitly.
        packages = ['firefox', 'firefox-esr']
        installed = [p for p in packages if subprocess.run(
            ['dpkg-query', '-W', '-f=${Status}', p], capture_output=True, text=True
        ).stdout.strip() == 'install ok installed']
        if installed:
            subprocess.run(['apt-get', '-o', 'DPkg::Lock::Timeout=120',
                            '-y', '--only-upgrade', 'install', *installed], check=True, timeout=900)
        success = True
    except (OSError, subprocess.SubprocessError) as error:
        status = 'Security updates failed. See journalctl -u pizza-ranch-updates.'
        print(str(error), file=sys.stderr)
    # Separate root-owned state prevents replacement with an application symlink.
    directory = Path('/var/lib/pizza-ranch-maintenance')
    directory.mkdir(mode=0o755, exist_ok=True)
    temporary = directory / 'status.tmp'
    temporary.write_text(json.dumps({'status': status, 'success': success,
                                    'completed_at': datetime.now(timezone.utc).isoformat()}))
    temporary.chmod(0o644)
    temporary.replace(directory / 'status.json')
    if success:
        # Refresh Python workers so patched OS-managed libraries take effect.
        subprocess.run(['systemctl', 'try-restart', 'pizza-ranch.service'], check=True)
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
