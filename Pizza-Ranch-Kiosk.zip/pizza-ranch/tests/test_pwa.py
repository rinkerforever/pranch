import json
from pathlib import Path

from PIL import Image
import pytest

from ranch.app import create_app


BASE = 'https://localhost'


@pytest.fixture
def app(tmp_path):
    return create_app({'TESTING': True, 'DATA_DIR': str(tmp_path)})


def test_management_pages_publish_installable_app_metadata(app):
    client = app.test_client()
    page = client.get('/login', base_url=BASE)
    assert page.status_code == 200
    assert 'Pizza Ranch · Digital Media Controller' in page.text
    assert '/static/manifest.webmanifest' in page.text
    assert '/static/icons/apple-touch-icon.png' in page.text
    assert '/static/app-shell.js' in page.text

    manifest_response = client.get('/static/manifest.webmanifest', base_url=BASE)
    manifest = json.loads(manifest_response.text)
    assert manifest['name'] == 'Pizza Ranch Digital Media Controller'
    assert manifest['display'] == 'standalone'
    assert {icon['sizes'] for icon in manifest['icons']} == {'192x192', '512x512'}


def test_service_worker_is_root_scoped_and_only_precaches_public_shell(app):
    response = app.test_client().get('/service-worker.js', base_url=BASE)
    assert response.status_code == 200
    assert response.mimetype == 'application/javascript'
    assert response.headers['Service-Worker-Allowed'] == '/'
    script = response.text
    assert '/static/manifest.webmanifest' in script
    assert '/api/' not in script
    assert '/media/' not in script
    assert '/fleet/' not in script


@pytest.mark.parametrize('filename,size', [
    ('apple-touch-icon.png', (180, 180)),
    ('icon-192.png', (192, 192)),
    ('icon-512.png', (512, 512)),
    ('icon-maskable-512.png', (512, 512)),
])
def test_app_icon_files_are_valid_pngs(filename, size):
    path = Path(__file__).parents[1] / 'ranch' / 'static' / 'icons' / filename
    with Image.open(path) as image:
        assert image.format == 'PNG'
        assert image.size == size
