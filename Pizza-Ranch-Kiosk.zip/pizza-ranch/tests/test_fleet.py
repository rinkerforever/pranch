import ipaddress
from unittest.mock import patch

from tests.test_app import BASE, app, csrf, image_data, post, register

LAN = {'X-Ranch-Local-Entry': '1', 'X-Real-IP': '192.168.50.24'}
NODE = '0123456789abcdef0123456789abcdef'
CERTIFICATE = '0' * 64


def fleet(client, path, body=None, token=None, method='POST'):
    headers = dict(LAN)
    if token:
        headers['X-Display-Token'] = token
    return client.open(path, method=method, base_url='https://localhost:8443',
                       headers=headers, json=body,
                       environ_overrides={'REMOTE_ADDR': '127.0.0.1'})


def test_pair_assign_report_and_forget_display(app, tmp_path):
    ca = tmp_path / 'ca.crt'
    ca.write_text('test-ca')
    app.config['TLS_CA_CERT'] = str(ca)
    client = app.test_client()
    register(client)
    interfaces = [ipaddress.ip_interface('192.168.50.10/24')]
    with patch('ranch.app.lan_interfaces', return_value=interfaces):
        hello = {'id': NODE, 'name': 'Dining TV', 'code': '123456', 'certificate': CERTIFICATE}
        assert fleet(client, '/fleet/hello', hello).json['status'] == 'pending'
        devices = client.get('/api/state', base_url=BASE).json['devices']
        assert devices[0]['name'] == 'Dining TV' and not devices[0]['paired']
        assert post(client, f'/api/devices/{NODE}/pair', {'code': '000000'}).status_code == 403
        assert post(client, f'/api/devices/{NODE}/pair', {'code': '123456'}).status_code == 200
        paired = fleet(client, '/fleet/hello', hello).json
        token = paired['token']
        state = fleet(client, '/fleet/state', {'id': NODE, 'source': 'setup', 'status': 'ready'}, token).json
        assert state['source'] == 'menu'
        assert post(client, f'/api/devices/{NODE}/display', {'source': 'ads'}).status_code == 200
        assert fleet(client, '/fleet/state', {'id': NODE}, token).json['source'] == 'ads'
        assert client.delete(f'/api/devices/{NODE}', base_url=BASE,
                             headers={'X-CSRF-Token': csrf(client, '/')}).status_code == 200
        assert fleet(client, '/fleet/state', {'id': NODE}, token).status_code == 403


def test_fleet_is_lan_only_and_media_is_authenticated(app, tmp_path):
    ca = tmp_path / 'ca.crt'
    ca.write_text('test-ca')
    app.config['TLS_CA_CERT'] = str(ca)
    client = app.test_client()
    register(client)
    interfaces = [ipaddress.ip_interface('192.168.50.10/24')]
    hello = {'id': NODE, 'name': 'TV', 'code': '123456', 'certificate': CERTIFICATE}
    assert fleet(client, '/fleet/hello', hello).status_code == 403
    with patch('ranch.app.lan_interfaces', return_value=interfaces):
        fleet(client, '/fleet/hello', hello)
        post(client, f'/api/devices/{NODE}/pair', {'code': '123456'})
        token = fleet(client, '/fleet/hello', hello).json['token']
        uploaded = client.post('/api/upload', base_url=BASE,
            headers={'X-CSRF-Token': csrf(client, '/')},
            data={'file': (image_data(), 'offer.jpg'), 'add_to_playlist': 'true'}).json
        post(client, f'/api/devices/{NODE}/display', {'source': 'media'})
        state = fleet(client, '/fleet/state', {'id': NODE}, token).json
        assert state['source'] == 'media' and state['playlist'][0]['id'] == uploaded['id']
        assert len(state['playlist'][0]['sha256']) == 64
        assert fleet(client, '/fleet/media/' + uploaded['id'], method='GET').status_code == 403
        response = client.get('/fleet/media/' + uploaded['id'], base_url='https://localhost:8443',
            headers={**LAN, 'X-Display-ID': NODE, 'X-Display-Token': token},
            environ_overrides={'REMOTE_ADDR': '127.0.0.1'})
        assert response.status_code == 200 and response.mimetype == 'image/jpeg'


def test_pairing_rejects_wrong_server_certificate(app):
    client = app.test_client()
    register(client)
    interfaces = [ipaddress.ip_interface('192.168.50.10/24')]
    hello = {'id': NODE, 'name': 'Wrong Server TV', 'code': '123456', 'certificate': 'f' * 64}
    with patch('ranch.app.lan_interfaces', return_value=interfaces):
        assert fleet(client, '/fleet/hello', hello).status_code == 200
        response = post(client, f'/api/devices/{NODE}/pair', {'code': '123456'})
    assert response.status_code == 409
    assert 'certificate' in response.json['error'].lower()
