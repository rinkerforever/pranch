from ranch.storage import database
from tests.test_app import BASE, app, csrf, login, register


URLS = {
    'menu_url': 'https://example.com/menu',
    'ads_url': 'https://example.com/ads',
    'funzone_url': 'https://example.com/funzone',
}


def request_json(client, path, method='POST', body=None):
    return client.open(path, method=method, base_url=BASE, json=body or {},
                       headers={'X-CSRF-Token': csrf(client, '/')})


def create_location(client, name='Longview'):
    response = request_json(client, '/api/locations', body={'name': name, **URLS})
    assert response.status_code == 201
    return response.json['id']


def create_user(client, username, role, locations):
    response = request_json(client, '/api/users', body={
        'username': username, 'display_name': username.title(), 'role': role,
        'password': 'temporary-password-123', 'location_ids': locations})
    assert response.status_code == 201
    return response.json['id']


def finish_first_login(client, username):
    assert login_as(client, username, 'temporary-password-123').location.endswith('/password')
    response = client.post('/password', base_url=BASE, data={
        'csrf_token': csrf(client, '/password'), 'current_password': 'temporary-password-123',
        'new_password': 'permanent-password-123', 'confirm_password': 'permanent-password-123'})
    assert response.status_code == 302


def login_as(client, username, password):
    return client.post('/login', base_url=BASE, data={
        'csrf_token': csrf(client), 'username': username, 'password': password})


def test_existing_install_migrates_to_tyler_and_admin(app):
    with database(app.config['DB_PATH']) as db:
        location = db.execute("SELECT * FROM locations WHERE id='tyler'").fetchone()
        admin = db.execute("SELECT * FROM users WHERE username='admin'").fetchone()
    assert location['name'] == 'Tyler'
    assert '8300?type=menu-only' in location['menu_url']
    assert admin['role'] == 'system_admin' and admin['active']


def test_admin_creates_location_and_location_scoped_operator(app):
    admin = app.test_client()
    register(admin)
    location_id = create_location(admin)
    create_user(admin, 'longview.operator', 'operator', [location_id])

    operator = app.test_client()
    finish_first_login(operator, 'longview.operator')
    state = operator.get('/api/state?location=' + location_id, base_url=BASE)
    assert state.status_code == 200 and state.json['location']['name'] == 'Longview'
    assert operator.get('/api/state?location=tyler', base_url=BASE).status_code == 403
    assert operator.get('/administration', base_url=BASE).status_code == 403
    changed = request_json(operator, '/api/display?location=' + location_id,
                           body={'source': 'ads'})
    assert changed.status_code == 200
    assert operator.get('/api/state?location=' + location_id,
                        base_url=BASE).json['source'] == 'ads'


def test_location_manager_can_manage_only_operators_in_assigned_locations(app):
    admin = app.test_client()
    register(admin)
    location_id = create_location(admin)
    create_user(admin, 'longview.manager', 'location_manager', [location_id])
    manager = app.test_client()
    finish_first_login(manager, 'longview.manager')
    assert manager.get('/administration', base_url=BASE).status_code == 200
    assert request_json(manager, '/api/locations', body={'name': 'Blocked', **URLS}).status_code == 403
    assert request_json(manager, '/api/users', body={
        'username': 'blocked.manager', 'display_name': 'Blocked Manager',
        'role': 'location_manager', 'password': 'temporary-password-123',
        'location_ids': [location_id]}).status_code == 403
    created = request_json(manager, '/api/users', body={
        'username': 'allowed.operator', 'display_name': 'Allowed Operator',
        'role': 'operator', 'password': 'temporary-password-123',
        'location_ids': [location_id]})
    assert created.status_code == 201


def test_location_pages_validate_https_and_admin_payload_omits_secrets(app):
    client = app.test_client()
    register(client)
    bad = request_json(client, '/api/locations', body={
        'name': 'Unsafe', **{**URLS, 'menu_url': 'http://example.com/menu'}})
    assert bad.status_code == 400
    state = client.get('/api/administration', base_url=BASE)
    assert state.status_code == 200
    assert 'password_hash' not in state.text and 'pranch' not in state.text


def test_admin_can_move_paired_display_between_locations(app):
    client = app.test_client()
    register(client)
    location_id = create_location(client)
    device_id = 'a' * 32
    with database(app.config['DB_PATH']) as db:
        db.execute('''INSERT INTO devices(id,name,token_hash,source,location_id)
                      VALUES(?,?,?,?,?)''', (device_id, 'Lobby TV', 'token', 'ads', 'tyler'))
    moved = request_json(client, f'/api/devices/{device_id}/location?location=tyler',
                         method='PATCH', body={'location_id': location_id})
    assert moved.status_code == 200
    destination = client.get('/api/state?location=' + location_id, base_url=BASE).json
    assert destination['devices'][0]['id'] == device_id
    assert destination['devices'][0]['source'] == 'menu'
