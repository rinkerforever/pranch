import io
from unittest.mock import patch, MagicMock
import urllib.error

from ranch.controller import reachable, api
from ranch import controller
import pytest


def test_website_outage_and_head_unsupported():
    with patch('urllib.request.urlopen', side_effect=OSError('offline')):
        assert reachable('https://example.com') is False
    with patch('urllib.request.urlopen', side_effect=urllib.error.HTTPError('url', 405, '', {}, None)):
        assert reachable('https://example.com') is True


def test_controller_uses_private_token_channel():
    response = MagicMock()
    response.__enter__.return_value = io.BytesIO(b'{"ok":true}')
    with patch('urllib.request.urlopen', return_value=response) as opened:
        assert api('/device/heartbeat', 'test-token', {'source': 'menu'}) == {'ok': True}
    request = opened.call_args.args[0]
    assert request.full_url.startswith('http://127.0.0.1:8080/')
    assert request.get_header('X-device-token') == 'test-token'


def test_controller_falls_back_then_recovers(tmp_path, monkeypatch):
    token = tmp_path / 'token'
    token.write_text('device-secret')
    monkeypatch.setenv('RANCH_DEVICE_TOKEN_FILE', str(token))
    states = iter([{'registered': True, 'source': 'menu', 'url': 'https://example.com/menu',
                    'playlist': ['image'], 'revision': 1}] * 3)

    def fake_api(path, *args):
        if path.endswith('heartbeat'):
            return {}
        try:
            return next(states)
        except StopIteration:
            raise KeyboardInterrupt

    processes = []

    def launch(*args, **kwargs):
        process = MagicMock()
        process.pid = 1234 + len(processes)
        process.poll.return_value = None
        processes.append(process)
        return process

    with patch.object(controller, 'api', side_effect=fake_api), \
         patch.object(controller, 'reachable', side_effect=[False, False, True]), \
         patch.object(controller.Path, 'home', return_value=tmp_path), \
         patch.object(controller.shutil, 'which', return_value='/usr/bin/firefox'), \
         patch.object(controller.signal, 'signal'), patch.object(controller.os, 'killpg', create=True), \
         patch.object(controller.time, 'sleep'), \
         patch.object(controller.time, 'monotonic', side_effect=[0, 35, 70]), \
         patch.object(controller.subprocess, 'Popen', side_effect=launch) as launched:
        with pytest.raises(KeyboardInterrupt):
            controller.main()
    destinations = [call.args[0][-1] for call in launched.call_args_list]
    assert destinations == ['https://example.com/menu', 'http://127.0.0.1:8080/device/player',
                            'https://example.com/menu']
    for call in launched.call_args_list:
        assert call.args[0][0] == '/usr/bin/firefox'
        assert '--kiosk' in call.args[0] and '--no-remote' in call.args[0]
        assert call.args[0][call.args[0].index('--profile') + 1] == str(tmp_path / '.local/share/pizza-ranch/firefox')
        assert '--no-sandbox' not in call.args[0]
        assert not any('remote-debugging' in arg for arg in call.args[0])


def test_firefox_profile_does_not_save_passwords(tmp_path):
    import json
    profile = tmp_path / 'dedicated-firefox'
    controller.prepare_profile(profile)
    lines = (profile / 'user.js').read_text().splitlines()[1:]
    prefs = dict(json.loads('[' + line[len('user_pref('):-2] + ']') for line in lines)
    assert prefs['signon.rememberSignons'] is False
    assert prefs['signon.autofillForms'] is False
    assert prefs['browser.privatebrowsing.autostart'] is True
    assert prefs['media.autoplay.default'] == 0
