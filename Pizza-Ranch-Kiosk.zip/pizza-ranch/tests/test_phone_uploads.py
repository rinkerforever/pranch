import io
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import pytest
from werkzeug.datastructures import FileStorage
from ranch.media import ingest, MediaError
from tests.test_app import app, register, csrf, image_data, BASE
from ranch.app import create_app


def test_upload_auto_add_is_persistent_and_selectable(app):
    client = app.test_client()
    register(client)
    result = client.post('/api/upload', base_url=BASE,
        headers={'X-CSRF-Token': csrf(client, '/')},
        data={'file': (image_data(), 'IMG_1234.PNG'), 'add_to_playlist': 'true'})
    assert result.status_code == 201
    assert result.json['added_to_playlist'] is True
    identifier = result.json['id']
    assert client.get('/api/state', base_url=BASE).json['playlist'] == [identifier]
    assert client.post('/api/display', base_url=BASE,
        headers={'X-CSRF-Token': csrf(client, '/')}, json={'source': 'media'}).status_code == 200
    restarted = create_app({'TESTING': True, 'DATA_DIR': app.config['DATA_DIR']})
    test_client = restarted.test_client()
    from tests.test_app import login
    login(test_client, 'ranch-test-password-123')
    state = test_client.get('/api/state', base_url=BASE).json
    assert state['playlist'] == [identifier] and state['source'] == 'media'
    assert len(state['library']) == 1


def test_extensionless_mobile_image_is_validated(tmp_path):
    item = ingest(FileStorage(stream=image_data(), filename='image', content_type='image/png'), tmp_path, 100000, 0)
    assert item['kind'] == 'image' and item['filename'].endswith('.jpg')


@pytest.mark.parametrize('filename', ['IMG_1234.JPG', 'photo.jpeg'])
def test_multipicture_jpeg_is_saved_as_primary_plain_jpeg(tmp_path, filename):
    data = io.BytesIO()
    with Image.new('RGB', (80, 40), 'red') as primary, Image.new('RGB', (80, 40), 'blue') as auxiliary:
        primary.save(data, 'MPO', save_all=True, append_images=[auxiliary])
    encoded = data.getvalue()
    with Image.open(io.BytesIO(encoded)) as detected:
        assert detected.format == 'MPO'
    item = ingest(FileStorage(stream=io.BytesIO(encoded), filename=filename, content_type='image/jpeg'), tmp_path, 100000, 0)
    with Image.open(tmp_path / item['filename']) as image:
        assert image.format == 'JPEG'
        assert getattr(image, 'n_frames', 1) == 1
        red, green, blue = image.getpixel((20, 20))
        assert red > 200 and green < 30 and blue < 30
        assert 'mp' not in image.info and not image.getexif()
    assert len(list(tmp_path.iterdir())) == 1


def test_unsupported_image_renamed_jpeg_reports_actual_format(tmp_path):
    data = io.BytesIO()
    Image.new('RGB', (30, 20), 'red').save(data, 'GIF')
    data.seek(0)
    with pytest.raises(MediaError, match='contains GIF'):
        ingest(FileStorage(stream=data, filename='fake.jpeg'), tmp_path, 100000, 0)
    assert not list(tmp_path.iterdir())


def test_large_iphone_jpeg_uses_reduced_decode(tmp_path):
    data = io.BytesIO()
    with Image.new('RGB', (6000, 4000), 'red') as image:
        image.save(data, 'JPEG')
    data.seek(0)
    item = ingest(FileStorage(stream=data, filename='IMG_24MP.JPG'), tmp_path, 20 * 1024**2, 0)
    with Image.open(tmp_path / item['filename']) as image:
        assert image.width <= 1920 and image.height <= 1080


def test_heic_conversion_outputs_sanitized_jpeg_and_cleans_temp(tmp_path):
    def decoder(command, **kwargs):
        Image.new('RGB', (30, 20), 'blue').save(command[-1], 'JPEG')
    with patch('ranch.media.shutil.which', side_effect=lambda name: name), patch('ranch.media.subprocess.run', side_effect=decoder):
        item = ingest(FileStorage(stream=io.BytesIO(b'heic fixture'), filename='IMG_1234.HEIC'), tmp_path, 100000, 0)
    assert list(tmp_path.iterdir()) == [tmp_path / item['filename']]
    with Image.open(tmp_path / item['filename']) as image:
        assert image.format == 'JPEG'


def test_heic_missing_decoder_gives_actionable_error(tmp_path):
    with patch('ranch.media.shutil.which', return_value=None):
        with pytest.raises(MediaError, match='HEIC support is not installed'):
            ingest(FileStorage(stream=io.BytesIO(b'heic'), filename='IMG.HEIC'), tmp_path, 100000, 0)
    assert not list(tmp_path.iterdir())
