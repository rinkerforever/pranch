import importlib.util
from pathlib import Path
from unittest.mock import patch
import zipfile

import pytest

spec = importlib.util.spec_from_file_location('app_updates', Path(__file__).parents[1] / 'deploy/app_updates.py')
updater = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updater)


def release(root, content='pass\n'):
    (root / 'ranch').mkdir(parents=True)
    (root / 'deploy').mkdir()
    (root / 'install.sh').write_text('#!/bin/bash\ntrue\n')
    (root / 'ranch/app.py').write_text(content)
    (root / 'deploy/app_updates.py').write_text('pass\n')
    (root / 'deploy/pizza-ranch.service').write_text('[Service]\n')
    (root / 'deploy/pizza-ranch-app-updates.timer').write_text('[Timer]\n')
    return root


def test_unchanged_does_not_install(tmp_path, monkeypatch):
    current = release(tmp_path / 'current')
    candidate = release(tmp_path / 'candidate')
    monkeypatch.setattr(updater, 'INSTALLED', current)
    (current / 'ranch/__pycache__').mkdir()
    (current / 'ranch/__pycache__/app.pyc').write_bytes(b'cache')
    with patch.object(updater, 'install') as install:
        assert updater.apply_release(candidate, 'pranch') == 'No application changes.'
        install.assert_not_called()


@pytest.mark.parametrize('fails', [False, True])
def test_update_and_restore_previous_release(tmp_path, monkeypatch, fails):
    current = release(tmp_path / 'current')
    candidate = release(tmp_path / 'candidate', 'version = 2\n')
    state = tmp_path / 'state'
    state.mkdir()
    monkeypatch.setattr(updater, 'INSTALLED', current)
    monkeypatch.setattr(updater, 'STATE', state)
    with patch.object(updater, 'install', side_effect=[OSError('failed'), None] if fails else None) as install:
        if fails:
            with pytest.raises(RuntimeError, match='previous release restored'):
                updater.apply_release(candidate, 'pranch')
            assert install.call_args_list[1].args == (state / 'previous-release', 'pranch')
        else:
            assert updater.apply_release(candidate, 'pranch') == 'Application updated successfully.'
        assert (state / 'previous-release/ranch/app.py').read_text() == 'pass\n'


@pytest.mark.parametrize('name,mode', [('../escape', 0), ('pizza-ranch/../../escape', 0),
    ('/absolute', 0), ('pizza-ranch/link', 0o120777), ('pizza-ranch\\evil', 0)])
def test_reject_unsafe_zip(tmp_path, name, mode):
    archive = tmp_path / 'bad.zip'
    with zipfile.ZipFile(archive, 'w') as output:
        entry = zipfile.ZipInfo(name)
        entry.filename = name  # Preserve malicious backslashes on Windows too.
        entry.external_attr = mode << 16
        output.writestr(entry, 'x')
    with pytest.raises(ValueError, match='Unsafe'):
        updater.unpack(archive, tmp_path / 'output')


def test_valid_zip_and_old_release_rejection(tmp_path):
    root = release(tmp_path / 'input')
    archive = tmp_path / 'release.zip'
    with zipfile.ZipFile(archive, 'w') as output:
        for path in root.rglob('*'):
            if path.is_file():
                output.write(path, 'pizza-ranch/' + path.relative_to(root).as_posix())
    with patch.object(updater.subprocess, 'run'):
        unpacked = updater.unpack(archive, tmp_path / 'output')
    assert updater.fingerprint(unpacked) == updater.fingerprint(root)
    with zipfile.ZipFile(archive, 'w') as output:
        output.writestr('pizza-ranch/install.sh', 'true')
    with pytest.raises(ValueError, match='Incomplete'):
        updater.unpack(archive, tmp_path / 'old')


def test_download_failure_leaves_install_untouched(tmp_path, monkeypatch):
    monkeypatch.setattr(updater, 'STATE', tmp_path)
    with patch.object(updater.Path, 'read_text', return_value='pranch'), \
            patch.object(updater, 'download', side_effect=OSError('offline')), \
            patch.object(updater, 'install') as install:
        assert updater.main() == 1
        install.assert_not_called()
    assert 'offline' in (tmp_path / 'app-status.json').read_text()
