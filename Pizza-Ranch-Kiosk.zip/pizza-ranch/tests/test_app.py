import io
import re
from pathlib import Path
import stat
from unittest.mock import patch

from PIL import Image
import pytest

from ranch.app import create_app, SOURCES
from ranch.storage import database, get_setting

BASE = 'https://localhost'


@pytest.fixture
def app(tmp_path):
    return create_app({'TESTING': True, 'DATA_DIR': str(tmp_path), 'RESERVE_BYTES': 0})


def csrf(client, path='/login'):
    page = client.get(path, base_url=BASE)
    return re.search(r'name="csrf-token" content="([^"]+)"', page.text)[1]


def login(client, password='pranch'):
    return client.post('/login', base_url=BASE, data={
        'csrf_token': csrf(client), 'username': 'admin', 'password': password})


def register(client):
    login(client)
    response = client.post('/password', base_url=BASE, data={
        'csrf_token': csrf(client, '/password'), 'current_password': 'pranch',
        'new_password': 'ranch-test-password-123', 'confirm_password': 'ranch-test-password-123'})
    assert response.status_code == 302


def post(client, path, data):
    return client.post(path, base_url=BASE, json=data, headers={'X-CSRF-Token': csrf(client, '/')})


def image_data():
    stream = io.BytesIO()
    Image.new('RGB', (30, 20), 'red').save(stream, 'PNG')
    stream.seek(0)
    return stream


def upload(client, filename='offer.png', stream=None):
    return client.post('/api/upload', base_url=BASE,
                       headers={'X-CSRF-Token': csrf(client, '/')},
                       data={'file': (stream or image_data(), filename)})


def device(client, path, headers=None, remote='127.0.0.1'):
    return client.get(path, base_url='http://127.0.0.1:8080', headers=headers or {},
                      environ_overrides={'REMOTE_ADDR': remote})


def test_registration_required_and_persisted(app):
    client = app.test_client()
    assert client.get('/api/state', base_url=BASE).status_code == 401
    assert login(client).status_code == 302
    assert client.get('/', base_url=BASE).location.endswith('/password')
    assert client.get('/api/state', base_url=BASE).status_code == 403
    register(client)
    assert client.get('/api/state', base_url=BASE).json['registered'] is True
    restarted = create_app({'TESTING': True, 'DATA_DIR': app.config['DATA_DIR']})
    assert login(restarted.test_client(), 'ranch-test-password-123').location.endswith('/')
    assert 'incorrect' in login(restarted.test_client()).text


def test_password_change_invalidates_other_sessions(app):
    first, second = app.test_client(), app.test_client()
    register(first)
    login(second, 'ranch-test-password-123')
    first.post('/password', base_url=BASE, data={
        'csrf_token': csrf(first, '/password'), 'current_password': 'ranch-test-password-123',
        'new_password': 'another-strong-pass-123', 'confirm_password': 'another-strong-pass-123'})
    assert second.get('/api/state', base_url=BASE).status_code == 401


def test_login_rate_limit(app):
    client = app.test_client()
    for _ in range(5):
        assert login(client, 'wrong').status_code == 200
    assert login(client, 'wrong').status_code == 429


def test_csrf_and_security_headers(app):
    client = app.test_client()
    register(client)
    assert client.post('/api/display', base_url=BASE, json={'source': 'ads'}).status_code == 403
    page = client.get('/', base_url=BASE)
    assert page.headers['X-Content-Type-Options'] == 'nosniff'
    assert "object-src 'none'" in page.headers['Content-Security-Policy']
    assert 'Secure' in page.headers['Set-Cookie']
    assert 'HttpOnly' in page.headers['Set-Cookie']
    assert client.get('/', base_url='https://attacker.example').status_code == 400


def test_presets_and_arbitrary_url_rejection(app):
    client = app.test_client()
    register(client)
    for source in ['menu', 'ads', 'funzone']:
        assert post(client, '/api/display', {'source': source}).status_code == 200
        state = device(client, '/device/state', {'X-Device-Token': app.config['DEVICE_TOKEN']}).json
        assert state['url'] == SOURCES[source][1]
    assert post(client, '/api/display', {'source': 'file:///etc/passwd'}).status_code == 400
    assert post(client, '/api/display', {'source': 'media'}).status_code == 400


def test_device_routes_block_network_and_proxy(app):
    client = app.test_client()
    for path in ['/device/state', '/device/setup', '/device/player', '/device/qr.png', '/device/playlist']:
        assert device(client, path, remote='192.168.1.20').status_code == 403
        assert device(client, path, {'X-Forwarded-For': '192.168.1.20'}).status_code == 403
    assert device(client, '/device/state').status_code == 403
    token = app.config['DEVICE_TOKEN']
    assert device(client, '/device/state', {'X-Device-Token': token}).status_code == 200
    assert client.post('/device/heartbeat', base_url='http://127.0.0.1:8080', json={}).status_code == 403
    assert client.post('/device/heartbeat', base_url='http://127.0.0.1:8080',
                       headers={'X-Device-Token': token}, json={'status': 'running'}).status_code == 200


def test_qr_contains_only_url_and_disappears(app):
    client = app.test_client()
    with patch('ranch.app.qrcode.make') as make:
        make.return_value.save.side_effect = lambda stream, **_: stream.write(b'png')
        assert device(client, '/device/qr.png').status_code == 200
        address = make.call_args.args[0]
        assert address.startswith('https://') and address.endswith('/login')
        assert '?' not in address and 'pranch' not in address and 'admin' not in address
    assert device(client, '/device/setup').status_code == 200
    register(client)
    assert device(client, '/device/qr.png').status_code == 404
    assert device(client, '/device/setup').status_code == 302


def test_media_playlist_and_protected_delivery(app):
    client = app.test_client()
    register(client)
    item = upload(client, '../../<script>.png')
    assert item.status_code == 201
    item = item.json
    assert item['name'] == '<script>.png'
    assert re.fullmatch('[a-f0-9]{32}.jpg', item['filename'])
    file_path = Path(app.config['DATA_DIR']) / 'media' / item['filename']
    if __import__('os').name != 'nt':
        assert not (file_path.stat().st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
    assert app.test_client().get('/media/' + item['id'], base_url=BASE).status_code == 302
    assert post(client, '/api/playlist', {'ids': [item['id']], 'seconds': 12, 'muted': True}).status_code == 200
    assert post(client, '/api/display', {'source': 'media'}).status_code == 200
    assert post(client, '/api/playlist', {'ids': [], 'seconds': 12, 'muted': True}).status_code == 400
    assert client.delete('/api/media/' + item['id'], base_url=BASE,
                         headers={'X-CSRF-Token': csrf(client, '/')}).status_code == 409
    result = device(client, '/device/playlist').json
    assert result['items'][0]['url'] == '/device/media/' + item['id']
    delivered = device(client, result['items'][0]['url'])
    assert delivered.mimetype == 'image/jpeg'
    delivered.close()
    assert post(client, '/api/display', {'source': 'menu'}).status_code == 200
    assert post(client, '/api/playlist', {'ids': [], 'seconds': 12, 'muted': True}).status_code == 200
    assert client.delete('/api/media/' + item['id'], base_url=BASE,
                         headers={'X-CSRF-Token': csrf(client, '/')}).status_code == 200
    assert not file_path.exists()


@pytest.mark.parametrize('name,content', [('evil.py', b'print(1)'), ('evil.html', b'<script>'),
                                         ('evil.svg', b'<svg/>'), ('evil.png', b'<script>alert(1)</script>'),
                                         ('evil.mp4', b'not a video')])
def test_reject_unsafe_uploads(app, name, content):
    client = app.test_client()
    register(client)
    assert upload(client, name, io.BytesIO(content)).status_code == 400
    assert list((Path(app.config['DATA_DIR']) / 'media').iterdir()) == []


def test_disk_floor_and_size_limit(app):
    client = app.test_client()
    register(client)
    app.config['RESERVE_BYTES'] = 10**20
    assert upload(client).status_code == 400
    app.config['RESERVE_BYTES'] = 0
    app.config['UPLOAD_LIMIT'] = 10
    assert upload(client).status_code == 400
    assert not list((Path(app.config['DATA_DIR']) / 'media').iterdir())


@pytest.mark.parametrize('body', [
    {'ids': ['missing'], 'seconds': 10, 'muted': True},
    {'ids': [], 'seconds': 0, 'muted': True},
    {'ids': [], 'seconds': 10, 'muted': 'yes'},
    {'ids': [{'bad': 'value'}], 'seconds': 10, 'muted': True},
])
def test_playlist_validation(app, body):
    client = app.test_client()
    register(client)
    assert post(client, '/api/playlist', body).status_code == 400


def test_password_not_stored_plaintext(app):
    with database(app.config['DB_PATH']) as db:
        stored = get_setting(db, 'password')
    assert stored != 'pranch' and 'pranch' not in stored


def test_non_object_json_rejected(app):
    client = app.test_client()
    register(client)
    assert post(client, '/api/display', ['ads']).status_code == 400
    assert post(client, '/api/display', {'source': []}).status_code == 400
    assert post(client, '/api/playlist', ['media']).status_code == 400
