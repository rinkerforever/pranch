import importlib.util
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import json

spec = importlib.util.spec_from_file_location('security_updates', Path(__file__).parents[1] / 'deploy/security_updates.py')
maintenance = importlib.util.module_from_spec(spec)
spec.loader.exec_module(maintenance)


def test_success_records_status_and_restarts_only_app(tmp_path):
    calls = []

    def run(command, **kwargs):
        calls.append(command)
        return SimpleNamespace(stdout='install ok installed', returncode=0)

    with patch.object(maintenance, 'Path', return_value=tmp_path), patch.object(maintenance.subprocess, 'run', side_effect=run):
        assert maintenance.main() == 0
    status = json.loads((tmp_path / 'status.json').read_text())
    assert status['success'] is True
    assert ['systemctl', 'try-restart', 'pizza-ranch.service'] in calls
    assert not any('reboot' in command for command in calls)


def test_failed_update_reported_and_no_restart(tmp_path):
    with patch.object(maintenance, 'Path', return_value=tmp_path), patch.object(maintenance.subprocess, 'run', side_effect=OSError('network down')) as run:
        assert maintenance.main() == 1
    assert run.call_count == 1
    assert json.loads((tmp_path / 'status.json').read_text())['success'] is False
