// Run against a fresh local test server, never a configured production Pi.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async()=>{
  const browser = await chromium.launch({headless:true, executablePath:process.env.BROWSER_PATH});
  const context = await browser.newContext({viewport:{width:1280,height:1100}});
  const page = await context.newPage();
  const errors=[];page.on('pageerror', error=>errors.push(error.message));
  await page.goto('http://localhost:8080/login');
  await page.locator('[name=username]').fill('admin');
  await page.locator('[name=password]').fill('pranch');
  await page.getByRole('button',{name:'Sign in',exact:true}).click();
  await page.waitForURL('**/password');
  await page.locator('[name=current_password]').fill('pranch');
  await page.locator('[name=new_password]').fill('browser-test-password-123');
  await page.locator('[name=confirm_password]').fill('browser-test-password-123');
  await page.getByRole('button',{name:'Save password',exact:true}).click();
  await page.waitForURL('http://localhost:8080/');
  await page.locator('#source').selectOption('funzone');
  await page.locator('#apply').click();
  await page.waitForFunction(()=>document.getElementById('requested').textContent.includes('Funzone Ads'));
  await page.locator('#files').setInputFiles(path.resolve('build/test-offer.png'));
  await page.getByRole('button',{name:'Add to playlist',exact:true}).waitFor();
  await page.getByRole('button',{name:'Add to playlist',exact:true}).click();
  await page.locator('#seconds').fill('15');
  await page.locator('#save-playlist').click();
  await page.waitForFunction(()=>document.getElementById('playlist-state').textContent==='Saved');
  await page.locator('#source').selectOption('media');
  await page.locator('#apply').click();
  await page.waitForFunction(()=>document.getElementById('requested').textContent.includes('Uploaded Media'));
  await page.screenshot({path:'build/management-desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path:'build/management-phone.png',fullPage:true});
  for(const width of [320,390,736,1024]){
    await page.setViewportSize({width,height:844});
    const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
    if(overflow)throw new Error('Horizontal overflow at '+width);
  }
  if(errors.length)throw new Error(errors.join('\n'));
  console.log('Browser checks passed: registration, source switching, image upload, playlist save, desktop/mobile layouts; no JS errors.');
  await browser.close();
})().catch(error=>{console.error(error);process.exit(1);});
