import hashlib
import io
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from ranch import node


class Response(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def test_discovers_private_ipv4_controller():
    output = '=;wlan0;IPv4;Pizza Ranch Controller;_pizza-ranch-controller._tcp;local;server.local;192.168.7.10;8443;\n'
    with patch.object(node.subprocess, 'run', return_value=SimpleNamespace(stdout=output)):
        assert node.discover_server() == 'https://192.168.7.10:8443'


def test_ignores_nonprivate_discovery():
    output = '=;wlan0;IPv4;Fake;_pizza-ranch-controller._tcp;local;fake;8.8.8.8;8443;\n'
    with patch.object(node.subprocess, 'run', return_value=SimpleNamespace(stdout=output)):
        assert node.discover_server() is None


def test_pairing_code_rotates_after_fifteen_minutes(tmp_path, monkeypatch):
    code_file = tmp_path / 'code'
    monkeypatch.setattr(node, 'CODE_FILE', code_file)
    with patch.object(node.time, 'time', return_value=1000), patch.object(node.secrets, 'randbelow', return_value=111111):
        assert node.pairing_code() == '211111'
    os.utime(code_file, (1000, 1000))
    with patch.object(node.time, 'time', return_value=1899), patch.object(node.secrets, 'randbelow', return_value=222222):
        assert node.pairing_code() == '211111'
    with patch.object(node.time, 'time', return_value=1900), patch.object(node.secrets, 'randbelow', return_value=222222):
        assert node.pairing_code() == '322222'


def test_download_validates_hash_and_reuses_cache(tmp_path, monkeypatch):
    media = tmp_path / 'media'
    media.mkdir()
    monkeypatch.setattr(node, 'MEDIA', media)
    certificate = tmp_path / 'certificate'
    certificate.write_text('f' * 64)
    monkeypatch.setattr(node, 'CERT_FILE', certificate)
    pem = tmp_path / 'certificate.pem'
    pem.write_text('test certificate')
    monkeypatch.setattr(node, 'CERT_PEM_FILE', pem)
    content = b'sanitized display media'
    item = {'id': 'a' * 32, 'kind': 'image', 'size': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}
    with patch.object(node.ssl, 'create_default_context'), \
            patch.object(node.urllib.request, 'urlopen', return_value=Response(content)) as fetch:
        path = node.download('https://192.168.1.2:8443', 'b' * 32, 'token', item)
    assert path.read_bytes() == content and path.stat().st_mode & 0o111 == 0
    with patch.object(node.ssl, 'create_default_context'), \
            patch.object(node.urllib.request, 'urlopen') as fetch_again:
        assert node.download('https://192.168.1.2:8443', 'b' * 32, 'token', item) == path
        fetch_again.assert_not_called()


def test_download_rejects_modified_media_and_cleans_partial(tmp_path, monkeypatch):
    media = tmp_path / 'media'
    media.mkdir()
    monkeypatch.setattr(node, 'MEDIA', media)
    certificate = tmp_path / 'certificate'
    certificate.write_text('f' * 64)
    monkeypatch.setattr(node, 'CERT_FILE', certificate)
    pem = tmp_path / 'certificate.pem'
    pem.write_text('test certificate')
    monkeypatch.setattr(node, 'CERT_PEM_FILE', pem)
    item = {'id': 'a' * 32, 'kind': 'image', 'size': 3,
            'sha256': hashlib.sha256(b'good').hexdigest()}
    with patch.object(node.ssl, 'create_default_context'), \
            patch.object(node.urllib.request, 'urlopen', return_value=Response(b'bad')):
        with pytest.raises(ValueError, match='hash or size'):
            node.download('https://192.168.1.2:8443', 'b' * 32, 'token', item)
    assert not list(media.iterdir())
