from ranch.cloud_node import return_to_pairing


def test_return_to_pairing_replaces_playback_state():
    state = {
        'source': 'media',
        'url': 'http://127.0.0.1:8080/device/player',
        'revision': 7,
        'playlist': [{'id': 'old'}],
        'seconds': 30,
        'muted': False,
        'status': 'Connected securely to the cloud.',
    }
    enrollment = {'code': '123456'}

    return_to_pairing(state, enrollment, 'Pair this TV again.')

    assert state == {
        'source': 'setup',
        'url': 'http://127.0.0.1:8080/device/setup',
        'revision': 8,
        'playlist': [],
        'seconds': 10,
        'muted': True,
        'status': 'Pair this TV again.',
    }
    assert enrollment == {}
