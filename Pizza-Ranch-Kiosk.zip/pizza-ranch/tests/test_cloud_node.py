import json

from ranch import cloud_node
from ranch.cloud_node import return_to_pairing, validated_playback


def test_return_to_pairing_replaces_playback_state():
    state = {
        'source': 'media',
        'url': 'http://127.0.0.1:8080/device/player',
        'revision': 7,
        'playlist': [{'id': 'old'}],
        'seconds': 30,
        'muted': False,
        'status': 'Connected securely to the cloud.',
    }
    enrollment = {'code': '123456'}

    return_to_pairing(state, enrollment, 'Pair this TV again.')

    assert state == {
        'source': 'setup',
        'url': 'http://127.0.0.1:8080/device/setup',
        'revision': 8,
        'playlist': [],
        'seconds': 10,
        'muted': True,
        'status': 'Pair this TV again.',
    }
    assert enrollment == {}


def test_validated_playback_restores_cached_campaign(tmp_path):
    (tmp_path / 'campaign-image.jpg').write_bytes(b'image')
    restored = validated_playback({
        'source':'media', 'url':'https://untrusted.example/wrong', 'revision':4,
        'playlist':[{'id':'campaign-image','kind':'image','mime_type':'image/jpeg'}],
        'seconds':12, 'muted':False,
    },tmp_path)
    assert restored['source'] == 'media'
    assert restored['url'] == 'http://127.0.0.1:8080/device/player'
    assert restored['playlist'][0]['id'] == 'campaign-image'
    assert restored['revision'] == 4 and restored['seconds'] == 12 and restored['muted'] is False


def test_validated_playback_rejects_unsafe_or_missing_content(tmp_path):
    assert validated_playback({'source':'menu','url':'file:///etc/passwd'},tmp_path) is None
    assert validated_playback({'source':'media','playlist':[{'id':'missing','kind':'image'}]},tmp_path) is None


def test_load_last_playback_requires_device_credentials(tmp_path, monkeypatch):
    credentials = tmp_path / 'credentials.json'; playback = tmp_path / 'playback.json'
    playback.write_text(json.dumps({'source':'menu','url':'https://example.com','revision':2}))
    monkeypatch.setattr(cloud_node,'CREDS',credentials)
    monkeypatch.setattr(cloud_node,'LAST_PLAYBACK',playback)
    assert cloud_node.load_last_playback() is None
    credentials.write_text('{}')
    assert cloud_node.load_last_playback()['url'] == 'https://example.com'
