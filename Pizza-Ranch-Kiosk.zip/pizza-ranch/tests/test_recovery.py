import ipaddress
import re
import socket
from unittest.mock import patch
import pytest
from ranch.app import create_app
from ranch.recovery import matching_lan, lan_interfaces
from tests.test_app import BASE, register, login, csrf, device

LAN = {'X-Real-IP': '192.168.50.24', 'X-Ranch-Local-Entry': '1'}


@pytest.fixture
def app(tmp_path):
    with patch('ranch.app.lan_interfaces', return_value=[ipaddress.ip_interface('192.168.50.10/24')]):
        yield create_app({'TESTING': True, 'DATA_DIR': str(tmp_path)})


def start(client):
    return client.post('/recover', base_url=BASE, headers=LAN,
                       data={'csrf_token': csrf(client)})


def screen_token(client):
    with patch('ranch.app.qrcode.make') as make:
        make.return_value.save.side_effect = lambda stream, **_: stream.write(b'png')
        response = device(client, '/device/recovery-qr.png')
        assert response.status_code == 200
        address = make.call_args.args[0]
    assert address.startswith(f'https://{socket.gethostname()}.local:8443/recover/scan#')
    assert '?' not in address
    return address.split('#')[1]


def finish(client, token, password='new-recovered-password'):
    return client.post('/recover/scan', base_url=BASE, headers=LAN, data={
        'csrf_token': csrf(client), 'reset_token': token,
        'new_password': password, 'confirm_password': password})


def test_reset_requires_screen_token_and_invalidates_sessions(app):
    owner, phone = app.test_client(), app.test_client()
    register(owner)
    assert start(phone).status_code == 302
    token = screen_token(phone)
    page = phone.get('/recover/wait', base_url=BASE, headers=LAN)
    assert token not in page.text
    state = device(phone, '/device/state', {'X-Device-Token': app.config['DEVICE_TOKEN']}).json
    assert state['recovery'] is True and state['url'].endswith('/device/recovery')
    assert token not in str(state)
    assert finish(phone, 'wrong-token').status_code == 400
    assert finish(phone, token).status_code == 302
    assert owner.get('/api/state', base_url=BASE).status_code == 401
    assert device(phone, '/device/recovery-qr.png').status_code == 404
    assert finish(phone, token).status_code == 400
    assert login(phone, 'new-recovered-password').status_code == 302
    assert phone.get('/api/state', base_url=BASE).status_code == 200
    state = device(phone, '/device/state', {'X-Device-Token': app.config['DEVICE_TOKEN']}).json
    assert state['recovery'] is False and 'menu-only' in state['url']


@pytest.mark.parametrize('headers,remote', [
    ({}, '127.0.0.1'),
    ({'X-Real-IP': '192.168.50.24', 'X-Ranch-Local-Entry': '0'}, '127.0.0.1'),
    ({'X-Real-IP': '100.90.0.1', 'X-Ranch-Local-Entry': '1'}, '127.0.0.1'),
    ({'X-Real-IP': '192.168.99.24', 'X-Ranch-Local-Entry': '1'}, '127.0.0.1'),
    (LAN, '192.168.50.24'),
])
def test_remote_and_spoofed_network_requests_blocked(app, headers, remote):
    client = app.test_client()
    for path in ['/recover', '/recover/wait', '/recover/scan']:
        assert client.get(path, base_url=BASE, headers=headers,
                          environ_overrides={'REMOTE_ADDR': remote}).status_code == 403


def test_recovery_expiry_and_cooldown(app):
    client = app.test_client()
    import time
    now = time.time()
    with patch('ranch.app.time.time', return_value=now):
        assert start(client).status_code == 302
        token = screen_token(client)
        # Additional requests do not rotate a QR while somebody is scanning.
        assert start(client).status_code == 302
        assert screen_token(client) == token
    with patch('ranch.app.time.time', return_value=now + 301):
        assert finish(client, token).status_code == 400
        assert device(client, '/device/recovery-qr.png').status_code == 404
        assert start(client).status_code == 429


def test_restart_invalidates_pending_token(app):
    client = app.test_client()
    start(client)
    token = screen_token(client)
    replacement = create_app({'TESTING': True, 'DATA_DIR': app.config['DATA_DIR']})
    assert finish(replacement.test_client(), token).status_code == 400


def test_weak_password_and_missing_csrf_do_not_consume_token(app):
    client = app.test_client()
    assert client.post('/recover', base_url=BASE, headers=LAN).status_code == 403
    start(client)
    token = screen_token(client)
    assert '12–128' in finish(client, token, 'short').text
    assert screen_token(client) == token


def test_normal_password_change_revokes_reset(app):
    owner, phone = app.test_client(), app.test_client()
    register(owner)
    start(phone)
    token = screen_token(phone)
    owner.post('/password', base_url=BASE, data={
        'csrf_token': csrf(owner, '/password'), 'current_password': 'ranch-test-password-123',
        'new_password': 'changed-normally-123', 'confirm_password': 'changed-normally-123'})
    assert finish(phone, token).status_code == 400


def test_network_discovery_excludes_vpn_and_fails_closed():
    from types import SimpleNamespace
    import json
    devices = [{'ifname': name, 'addr_info': [{'family':'inet', 'scope':'global',
        'local': address, 'prefixlen':24}]} for name,address in
        [('eth0','192.168.50.10'), ('tailscale0','100.90.0.1'), ('docker0','172.17.0.1')]]
    with patch('ranch.recovery.subprocess.run', return_value=SimpleNamespace(stdout=json.dumps(devices))):
        interfaces = lan_interfaces()
    assert len(interfaces) == 1
    assert matching_lan('192.168.50.22', interfaces)
    assert matching_lan('192.168.51.22', interfaces) is None
    with patch('ranch.recovery.subprocess.run', side_effect=OSError):
        assert lan_interfaces() == []
