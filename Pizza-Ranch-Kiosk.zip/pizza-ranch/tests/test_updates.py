from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from ranch import updates


def test_update_state_tracks_service_and_pending_request(tmp_path):
    request = tmp_path / 'check'
    with patch.object(updates, 'REQUEST', request), patch.object(
            updates.subprocess, 'run', return_value=SimpleNamespace(stdout='inactive\n')):
        assert updates.update_state() == {'available': True, 'busy': False}
        request.touch()
        assert updates.update_state() == {'available': True, 'busy': True}


def test_request_is_fixed_and_idempotent(tmp_path):
    request = tmp_path / 'check'
    with patch.object(updates, 'REQUEST', request):
        updates.request_update()
        updates.request_update()
    assert request.read_text() == 'check\n'
