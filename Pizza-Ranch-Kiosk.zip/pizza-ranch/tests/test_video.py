"""Validate the video acceptance boundary without requiring FFmpeg on Windows."""
import io
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from werkzeug.datastructures import FileStorage
from ranch.media import ingest, MediaError


def probe_info(codec='h264', width=1920, audio='aac'):
    return {'format': {'format_name': 'mov,mp4,m4a,3gp,3g2,mj2'},
            'streams': [{'codec_type': 'video', 'codec_name': codec, 'width': width, 'height': 1080},
                        {'codec_type': 'audio', 'codec_name': audio}]}


@pytest.mark.parametrize('filename', ['promo;evil.mp4', 'IMG_1234.MOV'])
def test_video_remux_has_no_shell_and_only_explicit_streams(tmp_path, filename):
    calls = []

    def run(command, **kwargs):
        calls.append((command, kwargs))
        if command[0] == 'ffprobe':
            return SimpleNamespace(stdout=json.dumps(probe_info()).encode())
        Path(command[-1]).write_bytes(b'sanitized-mp4')
        return SimpleNamespace(returncode=0)

    with patch('ranch.media.subprocess.run', side_effect=run), patch('ranch.media.shutil.which', side_effect=lambda name: name):
        result = ingest(FileStorage(stream=io.BytesIO(b'mp4'), filename=filename),
                        tmp_path, 1024, 0)
    assert result['kind'] == 'video'
    assert len(calls) == 2
    for command, kwargs in calls:
        assert isinstance(command, list) and not kwargs.get('shell')
        assert command[command.index('-protocol_whitelist') + 1] == 'file'
        assert filename not in command
    assert '-map_metadata' in calls[1][0] and '0:v:0' in calls[1][0]


@pytest.mark.parametrize('info', [probe_info(codec='hevc'), probe_info(width=3840), probe_info(audio='mp3')])
def test_incompatible_video_rejected(tmp_path, info):
    with patch('ranch.media.subprocess.run', return_value=SimpleNamespace(stdout=json.dumps(info).encode())), patch('ranch.media.shutil.which', side_effect=lambda name: name):
        with pytest.raises(MediaError):
            ingest(FileStorage(stream=io.BytesIO(b'mp4'), filename='promo.mp4'), tmp_path, 1024, 0)
    assert not list(tmp_path.iterdir())


def test_hevc_error_explains_iphone_format(tmp_path):
    with patch('ranch.media.subprocess.run', return_value=SimpleNamespace(stdout=json.dumps(probe_info(codec='hevc')).encode())), patch('ranch.media.shutil.which', side_effect=lambda name: name):
        with pytest.raises(MediaError, match='iPhone video uses HEVC'):
            ingest(FileStorage(stream=io.BytesIO(b'mp4'), filename='IMG_1234.MOV'), tmp_path, 1024, 0)
