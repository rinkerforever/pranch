[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)][int]$Port = 8080,
    [switch]$NoBrowser,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$demoPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $demoPython)) {
    $pythonLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($pythonLauncher) {
        & $pythonLauncher.Source -3 -m venv .venv
    } else {
        $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if (-not $pythonCommand) {
            throw 'Install Python 3.11 or newer from python.org, enable Add Python to PATH, reopen PowerShell, and run this script again.'
        }
        & $pythonCommand.Source -m venv .venv
    }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
}
& $demoPython -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or newer is required.' }
& $demoPython -c "import importlib.util,sys; sys.exit(0 if all(importlib.util.find_spec(m) for m in ['flask','waitress','PIL','qrcode']) else 1)"
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Installing demo dependencies. Internet access is needed on first use.'
    & $demoPython -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check internet access and retry.' }
}
if ($CheckOnly) { Write-Host 'PowerShell demo prerequisites are ready.'; return }
$demoArgs = @('-m', 'ranch.demo', '--port', $Port)
if ($NoBrowser) { $demoArgs += '--no-browser' }
& $demoPython @demoArgs
if ($LASTEXITCODE -ne 0) { throw 'Demo stopped with an error. Review the message above.' }
