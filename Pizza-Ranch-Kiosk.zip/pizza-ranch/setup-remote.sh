#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run: sudo bash setup-remote.sh'; exit 1; fi
if ! command -v tailscale >/dev/null; then
  echo 'First install Tailscale using https://tailscale.com/docs/install/linux'; exit 1
fi
echo 'Sign in with the account you will use on your phone/computer.'
tailscale up
# Tailscale Serve is private to your tailnet. Do not use Funnel.
tailscale serve --bg http://127.0.0.1:8081
tailscale serve status
echo 'Install Tailscale on each managing phone/computer and sign into the same approved network.'
echo 'Use the HTTPS address shown above. The app still requires your admin password.'
echo 'Restrict this Pi to approved users/devices in your Tailscale access policy.'
