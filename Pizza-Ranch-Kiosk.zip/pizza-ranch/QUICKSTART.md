# Install on your Raspberry Pi 3 B+

**Windows example:** with Python 3.11+ installed, open PowerShell in the extracted folder and run `powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Demo.ps1`. It opens a local management demo; use admin / pranch initially. Press Ctrl+C to stop. Pi installation steps follow below.

1. Install **Raspberry Pi OS 32-bit Desktop with labwc** (Bookworm or newer), connect the TV, and connect the Pi to your network. The installer also accepts 64-bit Desktop; it does not install or convert the OS.
2. Copy `Pizza-Ranch-Kiosk.zip` to the Pi and extract it.
3. Open a terminal in the extracted `pizza-ranch` folder and run:

   ```bash
   sudo bash install.sh server
   sudo reboot
   ```

   This installs Firefox (or Firefox ESR) and starts it in kiosk mode with a dedicated private profile. For an existing installation, rerun these commands from the new release folder; application passwords and media are retained.

4. Scan the QR on the TV using a phone on the same network. It opens the local certificate setup page without an HTTPS warning. Compare its SHA-256 fingerprint with the installer output, install the Pizza Ranch local CA once, follow your phone/computer’s trust steps, then open the secure management link. The QR contains no password or automatic login.

5. Add the controller to your phone like an app. On iPhone, open the secure address in Safari, tap **Share**, then **Add to Home Screen**. On Android, open it in Chrome and tap **Install app** on the page or in Chrome's menu. The shortcut opens as **PR Media** with the Pizza Ranch Digital Media Controller icon. Use the trusted HTTPS address; installation features are unavailable from an untrusted certificate page.
6. Log in with **admin / pranch** and change the password. The QR setup screen disappears.
7. Choose **Menu**, **Ads**, **Funzone Ads**, or **Uploaded Media**, then press **Show on screen**.

8. To add stores or staff accounts, open **Administration**. The update automatically places the existing installation in **Tyler**. System administrators can add locations and set their Menu, Ads, and Funzone Ads HTTPS addresses. Create each user with a temporary 12-character-or-longer password and assign one or more locations; the user must choose a new password at first sign-in.

To add another Pi 3 B+ and TV, install the same OS and ZIP, choose a unique hostname, and run `sudo bash install.sh display`, then reboot. Its TV shows a six-digit code. On the server admin page, find **Connected TV displays**, choose **Pair display**, enter the code, and select what that TV should play. Repeat for every additional TV. All Pis must be on the same LAN with device-to-device traffic and mDNS allowed.

For uploads, choose/drop files and wait for **saved on Pi**. Successful uploads join the saved playlist by default. Arrange them and press **Save & show playlist**. The installer includes iPhone HEIC photo conversion; HEVC videos must first be exported as H.264.

**Away access:** install Tailscale on the Pi using its official instructions, run `sudo bash setup-remote.sh`, and follow the sign-in prompts. Install Tailscale on your phone/computer and use the HTTPS address the script prints. Your application password is still required. Do not open router ports.

**Security maintenance:** daily at 9:00 a.m. America/Chicago, with missed runs caught up after startup. Automatic reboot is disabled. The dashboard shows update status. For another timezone, set `RANCH_TIMEZONE` as described in README.md.

Read **README.md** for certificate handling, recovery, supported media, remote-access setup, backups, and removal. Read **VALIDATION.md** before leaving the display unattended.

**Forgot your admin password?** Open the Pi's local IPv4 HTTPS address on the same local network, tap **Forgot password? Reset using the TV**, and request a QR. Scan the TV within five minutes, then set a new password. Existing sessions are signed out. This requires the updated installer and does not work through Tailscale.
# Automatic updates

Install this release once with `sudo bash install.sh server` on the server and `sudo bash install.sh display` on display nodes, then reboot. Each Pi remembers its role. It checks the GitHub ZIP two minutes after startup and daily at 9 AM (America/Chicago by default). Pi security updates also run at 9 AM; both jobs run one at a time. Missed Pi maintenance runs after startup. Settings, pairing credentials, passwords and uploads are retained; no automatic reboot occurs. Replace `Pizza-Ranch-Kiosk.zip` in the GitHub repository to publish a new application release.

Check scheduling with `systemctl list-timers 'pizza-ranch*'`. The management dashboard shows the most recent Pi maintenance and application update results.
