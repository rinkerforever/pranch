# Install on your Raspberry Pi 3 B+

**Windows example:** with Python 3.11+ installed, open PowerShell in the extracted folder and run `powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-Demo.ps1`. It opens a local management demo; use admin / pranch initially. Press Ctrl+C to stop. Pi installation steps follow below.

1. Install **Raspberry Pi OS 32-bit Desktop with labwc** (Bookworm or newer), connect the TV, and connect the Pi to your network. The installer also accepts 64-bit Desktop; it does not install or convert the OS.
2. Copy `Pizza-Ranch-Kiosk.zip` to the Pi and extract it.
3. Open a terminal in the extracted `pizza-ranch` folder and run:

   ```bash
   sudo bash install.sh
   sudo reboot
   ```

4. Scan the QR on the TV using a phone on the same network. The QR contains only the login address. Local HTTPS uses a self-signed certificate; verify its fingerprint using the installer output before accepting the browser warning.
5. Log in with **admin / pranch** and change the password. The QR setup screen disappears.
6. Choose **Menu**, **Ads**, **Funzone Ads**, or **Uploaded Media**, then press **Show on screen**.

For uploads, choose/drop files, add them to the playlist, arrange them, and press **Save playlist**. Select Uploaded Media to play the loop.

**Away access:** install Tailscale on the Pi using its official instructions, run `sudo bash setup-remote.sh`, and follow the sign-in prompts. Install Tailscale on your phone/computer and use the HTTPS address the script prints. Your application password is still required. Do not open router ports.

**Security maintenance:** daily at 4:00 a.m. America/Chicago, with up to 15 minutes of scheduling variation. Automatic reboot is disabled. The dashboard shows update status. For another timezone, set `RANCH_TIMEZONE` as described in README.md.

Read **README.md** for certificate handling, recovery, supported media, remote-access setup, backups, and removal. Read **VALIDATION.md** before leaving the display unattended.
