"""Generate fallback PR app icons. Replace SOURCE with supplied art when available."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'ranch' / 'static' / 'icons'


def icon(size, maskable=False):
    image = Image.new('RGB', (size, size), '#9e3125')
    draw = ImageDraw.Draw(image)
    margin = int(size * (0.19 if maskable else 0.10))
    draw.rounded_rectangle((margin, margin, size-margin, size-margin),
                           radius=int(size*.16), fill='#fff8e8', outline='#e6c679',
                           width=max(2, int(size*.018)))
    font = ImageFont.load_default(size=int(size*.31))
    draw.text((size/2, size*.47), 'PR', font=font, anchor='mm', fill='#9e3125', stroke_width=max(1,int(size*.004)))
    small = ImageFont.load_default(size=int(size*.055))
    draw.text((size/2, size*.70), 'MEDIA', font=small, anchor='mm', fill='#4a392d')
    return image


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    icon(180).save(OUTPUT / 'apple-touch-icon.png', optimize=True)
    icon(192).save(OUTPUT / 'icon-192.png', optimize=True)
    icon(512).save(OUTPUT / 'icon-512.png', optimize=True)
    icon(512, maskable=True).save(OUTPUT / 'icon-maskable-512.png', optimize=True)


if __name__ == '__main__':
    main()
