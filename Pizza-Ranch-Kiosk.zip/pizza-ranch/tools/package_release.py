"""Create a source-only release; never include credentials, media or a venv."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['README.md', 'QUICKSTART.md', 'PLAN.md', 'VALIDATION.md', 'requirements.txt',
         'install.sh', 'setup-remote.sh', 'uninstall.sh', 'Start-Demo.ps1']


def main():
    archive = ROOT / 'Pizza-Ranch-Kiosk.zip'
    candidates = [ROOT / name for name in FILES]
    for folder in ['ranch', 'deploy', 'tests', 'tools']:
        candidates.extend(p for p in (ROOT / folder).rglob('*') if p.is_file()
                          and '__pycache__' not in p.parts and p.suffix != '.pyc')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
        for file in sorted(candidates):
            output.write(file, 'pizza-ranch/' + file.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as output:
        assert output.testzip() is None
        assert all('/data/' not in name and '/demo-data/' not in name and '/.venv/' not in name and '/build/' not in name
                   for name in output.namelist())
    checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
    (ROOT / 'Pizza-Ranch-Kiosk.sha256').write_text(f'{checksum}  {archive.name}\n')
    print(f'{archive.name}: {len(candidates)} files, {archive.stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
