#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 || -z "${SUDO_USER:-}" || "$SUDO_USER" == root ]]; then
  echo 'Run from your Pi desktop account: sudo bash install.sh server|display|cloud-display' >&2; exit 1
fi
role="${1:-server}"
case "$role" in server|display|cloud-display) ;; *) echo 'Choose install role: server, display, or cloud-display' >&2; exit 1;; esac
# Check the installed package architecture, not the kernel: a 32-bit OS can
# run an aarch64 kernel on a Pi 3 B+.
os_arch="$(dpkg --print-architecture)"
case "$os_arch" in
  armhf|arm64) ;;
  *) echo 'Use Raspberry Pi OS Desktop: 32-bit (armhf) or 64-bit (arm64).' >&2; exit 1 ;;
esac
if ! command -v labwc >/dev/null || ! command -v raspi-config >/dev/null; then
  echo 'Install Raspberry Pi OS Desktop with labwc first (32-bit or 64-bit, not Lite).' >&2; exit 1
fi
echo "Installing for Raspberry Pi OS package architecture: $os_arch"
desktop_user="$SUDO_USER"
desktop_home="$(getent passwd "$desktop_user" | cut -d: -f6)"
if [[ -z "$desktop_home" || "$desktop_home" != /home/* ]]; then
  echo 'Expected a desktop user with a home under /home.' >&2; exit 1
fi
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ "$source_dir" == /opt/pizza-ranch ]]; then
  echo 'Run installer from an extracted release folder, not /opt/pizza-ranch.' >&2; exit 1
fi
export DEBIAN_FRONTEND=noninteractive
if [[ "${RANCH_MAINTENANCE_LOCKED:-}" != 1 ]]; then
  exec 9>/run/lock/pizza-ranch-maintenance.lock
  flock 9
fi
apt-get update
firefox_candidate="$(apt-cache policy firefox | awk '/Candidate:/ {print $2; exit}')"
browser_package=firefox
if [[ -z "$firefox_candidate" || "$firefox_candidate" == '(none)' ]]; then
  browser_package=firefox-esr
fi
apt-get install -y python3 python3-flask python3-waitress python3-pil python3-qrcode \
  "$browser_package" ffmpeg libheif-examples util-linux iproute2 nginx openssl rsync unattended-upgrades avahi-daemon avahi-utils ca-certificates
getent group ranch >/dev/null || groupadd --system ranch
getent group ranch-control >/dev/null || groupadd --system ranch-control
id ranch >/dev/null 2>&1 || useradd --system --gid ranch --home-dir /var/lib/pizza-ranch --shell /usr/sbin/nologin ranch
usermod -a -G ranch-control ranch
usermod -a -G ranch-control "$desktop_user"
install -d -o root -g root -m 755 /opt/pizza-ranch
# Copy only shipped application directories; never copy user data or .git.
rsync -a --delete "$source_dir/ranch/" /opt/pizza-ranch/ranch/
rsync -a --delete "$source_dir/deploy/" /opt/pizza-ranch/deploy/
install -m 755 "$source_dir/install.sh" /opt/pizza-ranch/install.sh
chown -R root:root /opt/pizza-ranch
chmod -R go-w /opt/pizza-ranch
install -d -o ranch -g ranch -m 700 /var/lib/pizza-ranch
install -d -o root -g root -m 755 /var/lib/pizza-ranch-maintenance
install -d -o root -g root -m 755 /etc/pizza-ranch
install -d -o root -g ranch -m 770 /var/lib/pizza-ranch-update-requests
printf '%s\n' "$desktop_user" > /etc/pizza-ranch/desktop-user
printf '%s\n' "$role" > /etc/pizza-ranch/install-role
chmod 644 /etc/pizza-ranch/desktop-user
chmod 644 /etc/pizza-ranch/install-role
if [[ ! -e /etc/pizza-ranch/device-token ]]; then
  openssl rand -hex 32 > /etc/pizza-ranch/device-token
fi
chown root:ranch-control /etc/pizza-ranch/device-token
chmod 640 /etc/pizza-ranch/device-token
if [[ ! -e /etc/pizza-ranch/app.env ]]; then
  cat > /etc/pizza-ranch/app.env <<'ENV'
RANCH_DATA=/var/lib/pizza-ranch
RANCH_DEVICE_TOKEN_FILE=/etc/pizza-ranch/device-token
ENV
fi
chown root:ranch /etc/pizza-ranch/app.env
chmod 640 /etc/pizza-ranch/app.env
if ! grep -q '^RANCH_MANUAL_UPDATES=' /etc/pizza-ranch/app.env; then
  printf '\nRANCH_MANUAL_UPDATES=1\n' >> /etc/pizza-ranch/app.env
fi
if [[ "$role" == server ]]; then
  install -d -o root -g ranch -m 750 /etc/pizza-ranch/tls
  if [[ ! -e /etc/pizza-ranch/tls/ca.key || ! -e /etc/pizza-ranch/tls/ca.crt ]]; then
    if [[ -e /etc/pizza-ranch/tls/server.crt ]]; then
      cp -a /etc/pizza-ranch/tls/server.crt /etc/pizza-ranch/tls/server.crt.pre-local-ca
      cp -a /etc/pizza-ranch/tls/server.key /etc/pizza-ranch/tls/server.key.pre-local-ca
    fi
    openssl req -x509 -newkey rsa:3072 -nodes -days 3650 \
      -keyout /etc/pizza-ranch/tls/ca.key -out /etc/pizza-ranch/tls/ca.crt \
      -subj "/CN=Pizza Ranch Local Display CA" \
      -addext 'basicConstraints=critical,CA:TRUE,pathlen:0' \
      -addext 'keyUsage=critical,keyCertSign,cRLSign' \
      -addext 'subjectKeyIdentifier=hash'
  fi
  if [[ ! -e /etc/pizza-ranch/tls/server.crt ]] || \
      ! openssl verify -CAfile /etc/pizza-ranch/tls/ca.crt /etc/pizza-ranch/tls/server.crt >/dev/null 2>&1; then
    lan_ip="$(hostname -I | awk '{print $1}')"
    san="DNS:$(hostname),DNS:$(hostname).local,DNS:pizza-ranch.local,IP:127.0.0.1"
    if [[ "$lan_ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then san="$san,IP:$lan_ip"; fi
    openssl req -newkey rsa:2048 -nodes \
      -keyout /etc/pizza-ranch/tls/server.key -out /etc/pizza-ranch/tls/server.csr \
      -subj "/CN=$(hostname).local"
    cat > /etc/pizza-ranch/tls/server-ext.cnf <<EOF
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=$san
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
EOF
    openssl x509 -req -days 825 -sha256 \
      -in /etc/pizza-ranch/tls/server.csr \
      -CA /etc/pizza-ranch/tls/ca.crt -CAkey /etc/pizza-ranch/tls/ca.key -CAcreateserial \
      -extfile /etc/pizza-ranch/tls/server-ext.cnf -out /etc/pizza-ranch/tls/server.crt
    rm -f /etc/pizza-ranch/tls/server.csr /etc/pizza-ranch/tls/server-ext.cnf
  fi
  chown root:root /etc/pizza-ranch/tls/ca.key /etc/pizza-ranch/tls/server.key
  chown root:ranch /etc/pizza-ranch/tls/ca.crt /etc/pizza-ranch/tls/server.crt
  chmod 600 /etc/pizza-ranch/tls/ca.key /etc/pizza-ranch/tls/server.key
  chmod 644 /etc/pizza-ranch/tls/ca.crt /etc/pizza-ranch/tls/server.crt
  install -m 644 /opt/pizza-ranch/deploy/nginx.conf /etc/nginx/conf.d/pizza-ranch.conf
  nginx -t
fi
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-updates.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-updates.timer /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-app-updates.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-app-updates.timer /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-app-updates.path /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-node.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-cloud-node.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-cloud.service /etc/systemd/system/
install -d -m 755 /etc/systemd/user
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-kiosk.service /etc/systemd/user/
install -m 644 /opt/pizza-ranch/deploy/52pizza-ranch-unattended /etc/apt/apt.conf.d/52pizza-ranch-unattended
# Preserve existing autostart contents and keep our addition idempotent.
install -d -o "$desktop_user" -g "$(id -gn "$desktop_user")" "$desktop_home/.config/labwc"
autostart="$desktop_home/.config/labwc/autostart"
if [[ -f "$autostart" && ! -f "$autostart.pre-pizza-ranch" ]]; then cp -a "$autostart" "$autostart.pre-pizza-ranch"; fi
touch "$autostart"
if ! grep -qF '/opt/pizza-ranch/deploy/start-kiosk.sh' "$autostart"; then
  printf '\n# Pizza Ranch kiosk\n/bin/sh /opt/pizza-ranch/deploy/start-kiosk.sh &\n' >> "$autostart"
fi
chown "$desktop_user:$(id -gn "$desktop_user")" "$autostart"
raspi-config nonint do_boot_behaviour B4
raspi-config nonint do_blanking 1
if [[ "${RANCH_AUTO_UPDATE:-}" != 1 ]]; then
  timedatectl set-timezone "${RANCH_TIMEZONE:-America/Chicago}"
fi
systemctl daemon-reload
systemctl enable --now pizza-ranch-updates.timer avahi-daemon
systemctl enable --now pizza-ranch-app-updates.timer
systemctl restart pizza-ranch-updates.timer
if [[ "$role" == server ]]; then
  install -d -m 755 /etc/avahi/services
  install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-controller.service.xml /etc/avahi/services/pizza-ranch-controller.service
  systemctl disable --now pizza-ranch-node.service 2>/dev/null || true
  systemctl disable --now pizza-ranch-cloud-node.service 2>/dev/null || true
  systemctl enable --now pizza-ranch.service nginx pizza-ranch-app-updates.path
  systemctl enable --now pizza-ranch-cloud.service
  systemctl restart pizza-ranch.service avahi-daemon
  systemctl reload nginx
else
  install -d -o ranch -g ranch -m 700 /var/lib/pizza-ranch-node
  install -d -o ranch -g ranch -m 700 /var/lib/pizza-ranch-node/media
  cat > /etc/pizza-ranch/node.env <<'ENV'
RANCH_NODE_DATA=/var/lib/pizza-ranch-node
RANCH_DEVICE_TOKEN_FILE=/etc/pizza-ranch/device-token
ENV
  chown root:ranch /etc/pizza-ranch/node.env
  chmod 640 /etc/pizza-ranch/node.env
  rm -f /etc/avahi/services/pizza-ranch-controller.service
  systemctl disable --now pizza-ranch.service pizza-ranch-cloud.service nginx 2>/dev/null || true
  if [[ "$role" == cloud-display ]]; then
    systemctl disable --now pizza-ranch-node.service 2>/dev/null || true
    systemctl enable --now pizza-ranch-cloud-node.service pizza-ranch-app-updates.path
    systemctl restart pizza-ranch-cloud-node.service avahi-daemon
  else
    systemctl disable --now pizza-ranch-cloud-node.service pizza-ranch-app-updates.path 2>/dev/null || true
    systemctl enable --now pizza-ranch-node.service
    systemctl restart pizza-ranch-node.service avahi-daemon
  fi
fi
if [[ "${RANCH_AUTO_UPDATE:-}" == 1 ]]; then
  desktop_uid="$(id -u "$desktop_user")"
  if [[ -S "/run/user/$desktop_uid/bus" ]]; then
    runuser -u "$desktop_user" -- env XDG_RUNTIME_DIR="/run/user/$desktop_uid" \
      DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$desktop_uid/bus" systemctl --user daemon-reload
    runuser -u "$desktop_user" -- env XDG_RUNTIME_DIR="/run/user/$desktop_uid" \
      DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$desktop_uid/bus" systemctl --user try-restart pizza-ranch-kiosk.service
  fi
fi
echo
echo 'Installed. Confirm the timezone below, then reboot to start the kiosk.'
timedatectl show -p Timezone --value
if [[ "$role" == server ]]; then
  echo "Server management: https://$(hostname).local:8443"
  echo 'Initial login: admin / pranch. A new password is required.'
  echo "Local certificate setup: http://$(hostname).local:8083/trust"
  echo 'Install and trust the local CA once on each phone/computer, then use HTTPS.'
  openssl x509 -in /etc/pizza-ranch/tls/ca.crt -noout -fingerprint -sha256
elif [[ "$role" == display ]]; then
  echo 'Display node installed. After reboot, use the code on its TV to pair it in the server admin page.'
else
  echo 'Cloud display installed. After reboot, scan the QR code on the TV and approve it in the cloud controller.'
fi
