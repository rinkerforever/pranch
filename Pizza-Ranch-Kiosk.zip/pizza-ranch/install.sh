#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 || -z "${SUDO_USER:-}" || "$SUDO_USER" == root ]]; then
  echo 'Run from your Pi desktop account: sudo bash install.sh' >&2; exit 1
fi
# Check the installed package architecture, not the kernel: a 32-bit OS can
# run an aarch64 kernel on a Pi 3 B+.
os_arch="$(dpkg --print-architecture)"
case "$os_arch" in
  armhf|arm64) ;;
  *) echo 'Use Raspberry Pi OS Desktop: 32-bit (armhf) or 64-bit (arm64).' >&2; exit 1 ;;
esac
if ! command -v labwc >/dev/null || ! command -v raspi-config >/dev/null; then
  echo 'Install Raspberry Pi OS Desktop with labwc first (32-bit or 64-bit, not Lite).' >&2; exit 1
fi
echo "Installing for Raspberry Pi OS package architecture: $os_arch"
desktop_user="$SUDO_USER"
desktop_home="$(getent passwd "$desktop_user" | cut -d: -f6)"
if [[ -z "$desktop_home" || "$desktop_home" != /home/* ]]; then
  echo 'Expected a desktop user with a home under /home.' >&2; exit 1
fi
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ "$source_dir" == /opt/pizza-ranch ]]; then
  echo 'Run installer from an extracted release folder, not /opt/pizza-ranch.' >&2; exit 1
fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-flask python3-waitress python3-pil python3-qrcode \
  chromium ffmpeg nginx openssl rsync unattended-upgrades avahi-daemon ca-certificates
getent group ranch >/dev/null || groupadd --system ranch
getent group ranch-control >/dev/null || groupadd --system ranch-control
id ranch >/dev/null 2>&1 || useradd --system --gid ranch --home-dir /var/lib/pizza-ranch --shell /usr/sbin/nologin ranch
usermod -a -G ranch-control ranch
usermod -a -G ranch-control "$desktop_user"
install -d -o root -g root -m 755 /opt/pizza-ranch
# Copy only shipped application directories; never copy user data or .git.
rsync -a --delete "$source_dir/ranch/" /opt/pizza-ranch/ranch/
rsync -a --delete "$source_dir/deploy/" /opt/pizza-ranch/deploy/
chown -R root:root /opt/pizza-ranch
chmod -R go-w /opt/pizza-ranch
install -d -o ranch -g ranch -m 700 /var/lib/pizza-ranch
install -d -o root -g root -m 755 /var/lib/pizza-ranch-maintenance
install -d -o root -g root -m 755 /etc/pizza-ranch
if [[ ! -e /etc/pizza-ranch/device-token ]]; then
  openssl rand -hex 32 > /etc/pizza-ranch/device-token
fi
chown root:ranch-control /etc/pizza-ranch/device-token
chmod 640 /etc/pizza-ranch/device-token
if [[ ! -e /etc/pizza-ranch/app.env ]]; then
  cat > /etc/pizza-ranch/app.env <<'ENV'
RANCH_DATA=/var/lib/pizza-ranch
RANCH_DEVICE_TOKEN_FILE=/etc/pizza-ranch/device-token
ENV
fi
chown root:ranch /etc/pizza-ranch/app.env
chmod 640 /etc/pizza-ranch/app.env
install -d -o root -g root -m 700 /etc/pizza-ranch/tls
if [[ ! -e /etc/pizza-ranch/tls/server.key ]]; then
  lan_ip="$(hostname -I | awk '{print $1}')"
  san="DNS:$(hostname),DNS:$(hostname).local,DNS:pizza-ranch.local,IP:127.0.0.1"
  if [[ "$lan_ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then san="$san,IP:$lan_ip"; fi
  openssl req -x509 -newkey rsa:2048 -nodes -days 365 \
    -keyout /etc/pizza-ranch/tls/server.key -out /etc/pizza-ranch/tls/server.crt \
    -subj "/CN=$(hostname).local" -addext "subjectAltName=$san"
fi
chmod 600 /etc/pizza-ranch/tls/server.key
install -m 644 /opt/pizza-ranch/deploy/nginx.conf /etc/nginx/conf.d/pizza-ranch.conf
nginx -t
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-updates.service /etc/systemd/system/
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-updates.timer /etc/systemd/system/
install -d -m 755 /etc/systemd/user
install -m 644 /opt/pizza-ranch/deploy/pizza-ranch-kiosk.service /etc/systemd/user/
install -m 644 /opt/pizza-ranch/deploy/52pizza-ranch-unattended /etc/apt/apt.conf.d/52pizza-ranch-unattended
# Preserve existing autostart contents and keep our addition idempotent.
install -d -o "$desktop_user" -g "$(id -gn "$desktop_user")" "$desktop_home/.config/labwc"
autostart="$desktop_home/.config/labwc/autostart"
if [[ -f "$autostart" && ! -f "$autostart.pre-pizza-ranch" ]]; then cp -a "$autostart" "$autostart.pre-pizza-ranch"; fi
touch "$autostart"
if ! grep -qF '/opt/pizza-ranch/deploy/start-kiosk.sh' "$autostart"; then
  printf '\n# Pizza Ranch kiosk\n/bin/sh /opt/pizza-ranch/deploy/start-kiosk.sh &\n' >> "$autostart"
fi
chown "$desktop_user:$(id -gn "$desktop_user")" "$autostart"
raspi-config nonint do_boot_behaviour B4
raspi-config nonint do_blanking 1
timedatectl set-timezone "${RANCH_TIMEZONE:-America/Chicago}"
systemctl daemon-reload
systemctl enable --now pizza-ranch.service pizza-ranch-updates.timer avahi-daemon nginx
systemctl restart pizza-ranch.service
systemctl reload nginx
echo
echo 'Installed. Confirm the timezone below, then reboot to start the kiosk.'
timedatectl show -p Timezone --value
echo "Local management: https://$(hostname).local:8443"
echo 'Initial login: admin / pranch. A new password is required.'
echo 'Local HTTPS uses a self-signed certificate. See README for certificate and Tailscale setup.'
openssl x509 -in /etc/pizza-ranch/tls/server.crt -noout -fingerprint -sha256
